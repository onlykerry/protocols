// Declare the FileIO references
NTSTATUS OpenFile(PWCHAR filename, BOOLEAN read, PHANDLE phandle);
NTSTATUS CloseFile(HANDLE handle);
unsigned __int64 GetFileSize(HANDLE handle);
NTSTATUS ReadFile(HANDLE handle, PVOID buffer, ULONG nbytes, PULONG pnumread);
NTSTATUS WriteFile(HANDLE handle, PVOID buffer, ULONG nbytes, PULONG pnumwritten);

