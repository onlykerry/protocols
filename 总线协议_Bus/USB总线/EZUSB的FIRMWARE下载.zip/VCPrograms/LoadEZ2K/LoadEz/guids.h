// guids.h -- WMI Guids for LoadEz driver
// Copyright (C) 1999. 2000 by Walter Oney
// All rights reserved

#ifndef GUIDS_H
#define GUIDS_H

// {320660A2-7CC4-11D4-BFD8-00207812F5D5}
DEFINE_GUID(GUID_INTERFACE_LOADEZ, 0x320660a2L, 0x7cc4, 0x11d4, 0xbf, 0xd8, 0x00, 0x20, 0x78, 0x12, 0xf5, 0xd5);

#endif
