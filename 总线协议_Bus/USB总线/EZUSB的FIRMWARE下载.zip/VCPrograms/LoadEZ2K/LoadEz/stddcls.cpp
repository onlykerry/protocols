// stddcls.cpp -- Precompiled header stub for WDM driver
// Copyright (C) 1999, 2000 by Walter Oney
// All rights reserved

#include "stddcls.h"
