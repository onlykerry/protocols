
/*
** HID MOUSE DESCRIPTOR DECLARATIONS
*/

const char hid_report_desc_table[] = 
{

 0x05, 0x01, /*usage page (generic desktop) */
 0x09, 0x02, /*usage (mouse) */
 0xA1, 0x01, /*collection (application) */
 0x05, 0x09, /*usage page (buttons) */
 0x19, 0x01, /*usage minimum (1) */
 0x29, 0x03, /*usage maximum (3) */
 0x15, 0x00, /*logical minimum (0) */
 0x25, 0x01, /*logical maximum (1) */
 0x95, 0x03, /*report count (3 bytes) */
 0x75, 0x01, /*report size (1) */
 0x81, 0x02, /*input (3 button bits) */
 0x95, 0x01, /*report count (1) */
 0x75, 0x05, /*report size (5) */
 0x81, 0x03, /*input (constant 5 bit padding) */
 0x05, 0x01, /*usage page (generic desktop) */
 0x09, 0x01, /*pointer*/
 0xA1, 0x00, /*linked*/
 0x09, 0x30, /*X*/
 0x09, 0x31, /*Y*/
 0x15, 0x81, /*logical minimum (-127) */
 0x25, 0x7F, /*logical maximum (127) */
 0x75, 0x08, /*report size (8) */
 0x95, 0x02, /*report count (2) */
 0x81, 0x06, /*input (2 position bytes X & Y) */
 0xC0,		 /*end collection*/
 0x09,0x38,  /*wheel*/
 0x95,0x01,	 /*wheel size = 1 byte*/
 0x81,0x06,  /*variable data bit field with relative position*/
 0x09,0x3c,  /*motion wakeup*/
 0x15,0x00,  /*0 no movement*/
 0x25,0x01,  /*1 movement*/
 0x75,0x01,  /*1st bit represents movement*/
 0x95,0x01,  /*1 report*/
 0xb1,0x22,  /*	Variable Data Bit Field with  absolute positioning and no preferred state*/
 0x95,0x07,  /*	7 reports for reversing, upper 7 bits of byte 3*/
 0xb1,0x01,  /*Constant Array Bit Field with absolute positioning*/
 0xC0        /* end collection, end collection */
 
 };

const char Endpoint_Descriptor[] = 
{
 0x07, 		/* descriptor length (7 bytes) */
 0x05, 		/* descriptor type (ENDPOINT) */
 0x81, 		/* endpoint address (IN endpoint, endpoint 1) */
 0x03, 		/* endpoint attributes (interrupt) */
 0x04, 0x00, /* maximum packet size (4 bytes) */
 0x0A  		/* polling interval (10ms) */
};

const char Class_Descriptor[] = 
{
 0x09, 		/* descriptor size (9 bytes) */
 0x21, 		/* descriptor type (HID) */
 0x10, 0x01,/* class specification (1.10) */
 0x00, 		/* hardware target country */
 0x01, 		/* number of hid class desriptors to follow (1) */
 0x22, 		/* report descriptor type (2) */
 sizeof(hid_report_desc_table),
 0x00
};

const char Interface_Descriptor[] = 
{
 0x09, 		/* length of descriptor (9 bytes) */
 0x04, 		/* descriptor type (INTERFACE) */
 0x00, 		/* interface number (0) */
 0x00, 		/* alternate setting (0) */
 0x01, 		/* number of endpoints (1) */
 0x03, 		/* interface class (3..defined by USB spec) */
 0x01, 		/* interface sub-class (1..defined by USB spec) */
 0x02, 		/* interface protocol (2..defined by USB spec) */
 0x00  		/* interface string index (not supported) */
};

const char config_desc_table[] = 
{
 0x09, 		/* length of descriptor (9 bytes) */
 0x02, 		/* descriptor type (CONFIGURATION) */
 0x22, 0x00,/* total length of descriptor (33 bytes) */
 0x01, 		/* number of interfaces to configure (1) */
 0x01, 		/* configuration value (1) */
 0x04, 		/* configuration string index (4) */
 0xA0, 		/* configuration attributes (bus powered, remote wakeup) */
 0x64 		/* maximum power (set at 100, change this value for your specific optics)*/
};

const char device_desc_table[] = 
{
 0x12, 		/* size of descriptor (18 bytes) */
 0x01, 		/* descriptor type (device descriptor) */
 0x10, 0x01,/* USB spec release (ver 1.1) */
 0x00, 		/* class code (each interface specifies class information) */
 0x00, 		/* device sub-class (must be set to 0 because class code is 0) */
 0x00, 		/* device protocol (no class specific protocol) */
 0x08, 		/* maximum packet size (8 bytes) */
 0xb4, 0x04,/* vendor ID (note reference design vendor ID) */
 0x70, 0x63,/* product ID (reference design USB mouse product ID) */
 0x01, 0x00,/* device release number */
 0x01, 		/* index of manufacturer string (1) */
 0x02, 		/* index of product string (2) */
 0x00, 		/* index of serial number string (not supported = 0x00) */
 0x01 		/* number of configurations (1) */
};
const char get_interface_status_table[] = 
{
 0x00, 0x00 /* always return both bytes zero */
};

/* String Descriptors */
const char USBStringLanguageDescription[] = 
{
 0x04, 		/* Length */
 0x03, 		/* Type (3=string) */
 0x09, 		/* Language: English */
 0x04 		/* Sub-language: Default */
};

const char USBStringDescription1[] = 
{
	44,3,'C',0,'y',0,'p',0,'r',0,'e',0,'s',0,'s',0,' ',0,'S',0,'e',0,'m',0,'i',0,'c',0,'o',0,'n',0,
	'd',0,'u',0,'c',0,'t',0,'o',0,'r',0
};

const char USBStringDescription2[] = 
{
	66,3, 'C',0,'y',0,'p',0,'r',0,'e',0,'s',0,'s',0,' ',0,'C',0,'Y',0,'7',0,'C',0,
	'6',0,'3',0,'7',0,'x',0,'x',0,' ',0,'U',0,'S',0,'B',0,' ',0,'M',0,'o',0,'u',0,'s',0,'e',0,' ',0,'v',0,
	'?',0,'.',0,'?',0,'?',0
};


/* NOTE: This is not implemented and is only here as a  	*/
/* demonstration of how to add a serial number string.  	*/
/* The serial number must be unique for every device or  	*/
/* else it may not enumerate properly.						*/

const char USBStringDescription3[] = 
{
 0x10,0x03,'0',0,'1',0,'2',0,'3',0,'4',0,'5',0,'6',0
};


const char USBStringDescription4[] = 
{
 0x14,
 0x03,
 'H',0,'I',0,'D',0,' ',0,'M',0,'o',0,'u',0,'s',0,'e',0
};

const char USBStringDescription5[] = 
{
 0x32,
 0x03,
 'E',0,'n',0,'d',0,'P',0,'o',0,'i',0,'n',0,'t',0,'1',0,' ',0,'I',0,
 'n',0,'t',0,'e',0,'r',0,'r',0,'u',0,'p',0,'t',0,'P',0,'i',0,'p',0,'e',0 
};

