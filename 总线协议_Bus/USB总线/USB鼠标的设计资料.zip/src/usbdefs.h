#define CONFIGURED                      0x01 /* configuration status values */
#define UNCONFIGURED                    0x00       

#define USB_GET_STATUS                  0x00 /*bRequestTypes*/
#define USB_CLEAR_FEATURE               0x01
#define USB_SET_FEATURE                 0x03
#define USB_SET_ADDRESS                 0x05
#define USB_GET_DESCRIPTOR              0x06
#define USB_SET_DESCRIPTOR              0x07
#define USB_GET_CONFIGURATION           0x08
#define USB_SET_CONFIGURATION           0x09
#define USB_GET_INTERFACE               0x0A
#define USB_SET_INTERFACE               0x0B
#define USB_SYNCH_FRAME                 0x0C

#define HOST_TO_DEVICE                  0b00000000
#define DEVICE_TO_HOST                  0b10000000
#define STANDARD                        0b00000000
#define CLASS                           0b00100000
#define VENDOR                          0b01000000
#define DEVICE                          0b00000000
#define INTERFACE                       0b00000001
#define ENDPOINT                        0b00000010
#define OTHER                           0b00000011

/* standard descriptor types */
#define USB_DEVICE                      0x01
#define USB_CONFIGURATION               0x02
#define USB_STRING                      0x03
#define USB_INTERFACE                   0x04
#define USB_ENDPOINT                    0x05

#define DISABLE_REMOTE_WAKEUP           0x00 /* bit[1] = 0 */
#define ENABLE_REMOTE_WAKEUP            0x02 /* bit[1] = 1 */

/* standard feature selectors */
#define USB_ENDPOINT_STALL              0x00 /* recipient endpoint */
#define USB_DEVICE_REMOTE_WAKEUP        0x01 /* recipient device */

/* from HID Class v1.0 Draft #4 
 * class specific descriptor types from section 7.1 Standard R ests
 ***/
#define USB_HID                         0x21
#define USB_REPORT                      0x22
#define USB_PHYSICAL                    0x23

/* class specific request codes from section 7.2 Class Specific R ests */
#define USB_GET_REPORT                  0x01
#define USB_GET_IDLE                    0x02
#define USB_GET_PROTOCOL                0x03
#define USB_SET_REPORT                  0x09
#define USB_SET_IDLE                    0x0A
#define USB_SET_PROTOCOL                0x0B

#define BOOT_PROTOCOL 0
#define REPORT_PROTOCOL 1
