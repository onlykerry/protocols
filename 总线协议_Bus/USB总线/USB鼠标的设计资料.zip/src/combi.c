/*
**
** FILE: combi.c
**
**
** purpose: USB firmware for Cypress USB/PS2 mouse reference design
**			   
**
** revision history:
** 6/27/00  bth : modified ps2 scaling algorithm
** 7/11/00  sea : modified ps2 resolution constants and 
**					ps2_send() start bit inhibit response
**
*/



#pragma option INSTRUCTIONTIMING			//needed for Cypress debugger to work properly
#pragma option f0							//do not insert page breaks in listing file 
#pragma option REGSAVEOFF;					//do not automatically save AC and IX in interrupts
#pragma option NOINIT;
#define DEBUG 


#include "chip.h"
#include "usbdefs.h"
#include "ps2defs.h"

#define BIT0 1
#define BIT1 2
#define BIT2 4
#define BIT3 8
#define BIT4 0x10
#define BIT5 0x20
#define BIT6 0x40
#define BIT7 0x80


//*************************************************************************************************
//USER_DEFINES
/*
**
** the following defines can be changed to accomodate different I/O pinouts.  It is assumed that
** all 6 quadrature inputs (optics) are connected to the same port.
**
*/

#define OPTICS_PORT				PORT0				//optics port
#define OPTICS_MASK				0x3f				//mask of all optics inputs
/*
** for each set of x,y, and z optics, define a macro that will move the corresponding 2 quadrature bits
** into bit1 and bit0.  For instance, in the reference design
** the y- quadrature inputs are at bits 3 and 2, so the macro shifts the bits by 2 and
** masks them.
*/

#define GET_X_OPTICS(x) ((x >> 0) & 0x3)			//no shift necessary					
#define GET_Y_OPTICS(x) ((x >> 2) & 0x3)			//shift bits [3:2] into [1:0]
#define GET_Z_OPTICS(x) ((x >> 4) & 0x3)			//shift bits [5:4] into [1:0]


/*
** define each switch's port and bit position
*/
#define LEFT_SWITCH_PORT		PORT0
#define LEFT_SWITCH_MASK		BIT7
#define RIGHT_SWITCH_PORT		PORT1
#define RIGHT_SWITCH_MASK		BIT0
#define MIDDLE_SWITCH_PORT		PORT1
#define MIDDLE_SWITCH_MASK		BIT1


/*
**define masks for the port pin functions.  This information is used to establish the mode
**settings for the GPIO pins
**
*/
#define PORT0_OPTICS_MASK		0b00111111			//optics pins [5:0] on port 0
#define PORT1_OPTICS_MASK		0b00000000			//no optics on port 1
#define PORT0_LED_MASK		    0b01000000			//led drive at pin [6] on port 0
#define PORT1_LED_MASK			0b00000000			//no led drive on port 1
#define PORT0_SWITCH_MASK		0b10000000			//switch input at pin [7] on port 0
#define PORT1_SWITCH_MASK		0b00000011			//switch inputs at [1:0] on port 1




//comment the following lines if you do not want PS2 resolution and scaling commands to be implemented 
//in the code.
#define ENABLE_RESOLUTION
#define ENABLE_SCALING
//END OF USER DEFINES
//*************************************************************************************************





//*************************************************************************************************
//COMMON DECLARATIONS USED BY BOTH INTERFACES
#include "macros.h"								//include macro definitions

/*
** define port data and mode initial values for the 3 operating states -- normal, suspend, and suspend with remote
** wakeup -- based on the masks provided by the user
*/
/*
**normal operating mode
*/
#define PORT0_INIT				PORT0_SWITCH_MASK
#define PORT1_INIT				PORT1_SWITCH_MASK
#define PORT0_MODE1_INIT		PORT0_SWITCH_MASK
#define PORT1_MODE1_INIT		PORT1_SWITCH_MASK
#define PORT0_MODE0_INIT		PORT0_LED_MASK
#define PORT1_MODE0_INIT		PORT1_LED_MASK

/*
** suspend mode (no remote wakeup)
*/


#define PORT0_SUSPEND					PORT0_LED_MASK
#define PORT1_SUSPEND					PORT1_LED_MASK
#define PORT0_MODE1_SUSPEND				PORT0_LED_MASK
#define PORT1_MODE1_SUSPEND				PORT1_LED_MASK
#define PORT0_MODE0_SUSPEND				PORT0_SWITCH_MASK
#define PORT1_MODE0_SUSPEND				PORT1_SWITCH_MASK
/*
** remote wakeup
*/
#define PORT0_RW						(PORT0_LED_MASK | PORT0_SWITCH_MASK)
#define PORT1_RW						(PORT1_LED_MASK | PORT1_SWITCH_MASK)
#define PORT0_MODE1_RW					(PORT0_SWITCH_MASK | PORT0_LED_MASK)
#define PORT1_MODE1_RW					(PORT1_SWITCH_MASK | PORT1_LED_MASK)
#define PORT0_MODE0_RW					0
#define PORT1_MODE0_RW					0


#define LEFT_SWITCH_ASSERTED		(!(LEFT_SWITCH_PORT & LEFT_SWITCH_MASK))
#define MIDDLE_SWITCH_ASSERTED		(!(MIDDLE_SWITCH_PORT & MIDDLE_SWITCH_MASK))
#define RIGHT_SWITCH_ASSERTED		(!(RIGHT_SWITCH_PORT & RIGHT_SWITCH_MASK))


/*
** switches are debounced in a routine that is called every 4 msec.  10
** successive stable samples are required for a switch change to be reported.
*/
#define DEBOUNCE_COUNT				10		  //10 identical samples must be taken to recognize switch changes





/*
** define a structure containing variables updated in the 1-msec interrupt
*/

typedef struct
{
	char b1msCounter;				//incremented inside 1msec interrupt for general timing
	char b1msFlags;					//flag set inside 1msec interrupt
}ONE_MSEC_STATUS;
#define ONE_MSEC_FLAG 1


/*
** Quadrature inputs are sampled inside the 128 usec interrupt and placed in a queue for later
** processing in the main loop.
**
*/
typedef struct
{
	char near *headP;					//head of queue
	char near *tailP;					//tail of queue
	char bLen;							//length of queue
}QUEUE_STRUCT;


/*
** current state of each quadrature pair is stored to compare with the next sample.
**
*/
 
typedef struct
{
	char bXstate;						//current state of X optics
	char bYstate;						//current state of Y optics
	char bZstate;						//current state of Z optics
			
}OPTICS_STATE;



/*
** the order of the bytes in this structure is important! These bytes are in the
** proper order for a packet returned to a USB host in response to a Get_Report command.
*/
typedef struct
{
	char bChange;						//set to 1 if mouse state has changed
	char bButtons;						//current state of mouse buttons
	signed char bXcount;						//current accumulation of X counts
	signed char bYcount;						//current accumulation of Y counts
	signed char bZcount;						//current accumulation of Z counts
}MOUSE_STATE;



/*
** global variables used by both USB and PS2 interfaces
*/

QUEUE_STRUCT		OpticsQueue;		//optics queue		

ONE_MSEC_STATUS		MsecStatus;			//status of 1msec interrupt
OPTICS_STATE		Optics;				//current state of optics
MOUSE_STATE			Mouse;				//current state of mouse (buttons, x,y,z)
char bLastButtons;
char bDebounceCount;


char bOpticsArray[16];					//16-byte array used for optics queue data


const signed char quad_table[] = 
/*
;***
; Quadrature state table. This table assists processing of quadrature state
; transitions. The table index is calculated as:
;       [(last_state)*4 + current_state],
; and the table entry at that point is 1, 0 or -1 indicating increment, hold
; or decrement the count, respectively.
;***
*/
{
	0,					//;State 0 => state 0 (NoChange)
	1,					//;        => state 1 (Increment)
	0xff,				//;        => state 2 (Decrement)
	0,					//;        => state 3 (Fault)
	
	0xff,				//;State 1 => state 0 (Decrement)
	0,					//;       => state 1  (NoChange)
	0,					//;       => state 2  (Fault)
	1,    				//;       => state 3  (Increment)
	
	1,					//;State 2 => state 0 (Increment)
	0,					//;       => state 1  (Fault)
	0,					//;     => state 2    (NoChange)
	0xff,				//;       => state 3  (Decrement)
	
	0,					//;State 3 => state 0 (Fault)
	0xff,				//;       => state 1  (Decrement)
	1,					//;       => state 2  (Increment)
	0					//;      => state 3   (NoChange)
};

const signed char z_quad_table[] = 
/*
;***
; Quadrature state table. This table assists processing of quadrature state
; transitions. The table index is calculated as:
;       [(last_state)*4 + current_state],
; and the table entry at that point is 1, 0 or -1 indicating increment, hold
; or decrement the count, respectively.
;***
*/
{
	0,					//;State 0 => state 0 (NoChange)
	0,					//;        => state 1 (NoChange)
	0,		  			//;        => state 2 (NoChange)
	0,					//;        => state 3 (Fault)
	
	0,				//;State 1 => state 0 (NoChange)
	0,					//;       => state 1 (NoChange)
	0,					//;       => state 2 (NoChange)
	1,    				//;       => state 3 (Increment)
	
	1,					//;State 2 => state 0 (Increment)
	0,					//;       => state 1 (Fault)
	0,					//;     => state 2 (NoChange)
	0xff,				//;       => state 3 (Decrement)
	
	0,					//;State 3 => state 0 (Fault)
	0xff,				//;       => state 1 (Decrement)
	0,					//;       => state 2 (NoChange)
	0					//;      => state 3 (NoChange)
};
/*
** function prototypes for shared functions
*/
void main(void);
void ClearRam(void);
void Delay(char delay);
//void delay(void);

//*************************************************************************************************
//USB DECLARATIONS 

#include "usb_desc.h"						//include usb descriptors



#define SET_EP0_MODE(x) EP_A0_MODE = x		//set mode register for EP0


/*
** define a structure that will maintain the parameters of multibyte data that is returned
** to the host in response to successive IN commands on endpoint 0 (descriptors, status, reports, etc).
*/
typedef struct
{
	char bLength;							//length of data remaining to be returned		
	far char *p;							//pointer to the data
    char dummy;								//padding -- compiler bug doesn't allocate enough space for a far *
}TRANSMIT_STRUCT;


/*
** define a structure that contains the current USB device status
*/
typedef struct
{
	char bConfiguration;					//configured or not
	char bRemoteWakeup;						//remote wakeup enabled or not
	char bDeviceStatus;						//spare, do not remove! this byte is a placeholder
											//for the 2nd byte of device status.
	char bEP1Stall;							//endpoint 1 stalled or not
	char bEPStatus;							//spare, do not remove! this byte is a placeholder
											//for the 2nd byte of device status
	char bAddress;							//current address
	char bProtocol;							//boot protocol or report protocol
}DEVICE_STATUS;


/*
** define a structure for mouse transmit status
*/

typedef struct
{
	char bIdlePeriod;						//current idle period setting
	char bIdleCounter;						//counter for idle period
}
MOUSE_STATUS;




MOUSE_STATUS		MouseStatus;			//status of mouse
TRANSMIT_STRUCT		XmtBuff;				//EP0 transmit buffer parameters

DEVICE_STATUS		DeviceStatus;			//device status
char				bSuspendCounter;		//counter for keeping track of suspend interval

//declare the following registers global. They are used by ISRs to avoid compiler issues.
char byte_count;
char byte_count1;
char bWakeupCount;


/*
** USB function prototypes
*/
void UsbReInitialize(void);
void MouseTask(void);
void Suspend(void);
void usbmain(void);
void HandleSetup(void);
void HandleIn(void);
void USB_control_read(void);
char LoadEP0Fifo(void);
void ClearRemoteWakeup(void);
void SetRemoteWakeup(void);
void SetConfiguration(void);
void SetAddress(void);
void ClearEndpointStall(void);
void SetEndpointStall(void);
void GetDeviceStatus(void);
void GetDescriptor(void);
void GetInterfaceStatus(void);
void GetEndpointStatus(void);
void SetIdle(void);
void SetProtocol(void);
void GetReport(void);
void GetIdle(void);
void GetProtocol(void);
void GetConfiguration(void);
void USB_Stall_In_Out(void);
char BusInactive(void);



//*************************************************************************************************
//PS2 DECLARATIONS 


/*
** define a structure that contains all mouse parameters that can be set via host commands
*/
typedef struct
{
	char bReportRate;								
	char bReportInterval;							
	char bScale;
	char bStream;
	char bResolution;
	char bEnabled;
	char bZmouse;
	char bWrap;
}MOUSEPARMS;

/*
** define a structure to hold messages to be sent back to the host.  This can be either a mouse packet
** or a response to a command (device id, BAT response, etc).
*/
typedef struct
{
	char bMsgBuff[5];						//array of bytes
	char bMsgLen;							//initial length of message
	char bXmtLen;							//length of bytes remaining to send
}PS2_XMT_STRUCT;


int16 bBatDelay;							//bat delay, in msec.

char ConsecutiveSetSamples;					//keeps track of number of consecutive set-sample commands
											//received from the host (for enabling z-mice)
char  bIntervalCount;						//interval count, in msec, for reporting mouse packets

MOUSEPARMS  MouseParms;						//mouse parameters
PS2_XMT_STRUCT Ps2Xmt;						//transmit buffer
char ksc_delay;								//storage for assembly routines
char ps2_temp0;								//storage for assembly routines




/*
** function prototypes for PS2 routines
*/

void ps2BAT(void);
void ps2_send(char data);
char ps2_receive(void);
void Reset(void);
void Resend(void);
void SetDefault(void);
void Disable(void);
void Enable(void);
char SetSampleRate(char p);
void ReadDeviceType(void);
void SetRemoteMode(void);
void SetWrapMode(void);
void ReadData(void);
void SetStreamMode(void);
void StatusRequest(void);
char SetResolution(char p);
void SetScaling(void);
void ResetScaling(void);
char GetByte ( void);
void ProcessCommand(char p);
void SendMouseData(void);
void Put(char p);
void PutMsgBuff(void);
void SendMouseData(void);
void ps2main(void);
void PutNextByte(void);
void ReInitialize(void);
void ResetInterval(void);
void Ps2MouseTask(void);


/*
**
** FUNCTION:		ClearRam
**
** PURPOSE:			Clears all RAM except data and program stacks.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		Written in assembler so that only X and A are used ( no variables
**					that might be cleared as a result of this function executing)
**
*/

void ClearRam(void)
{
    #asm 
    mov     X,REGISTER_SIZE - 1
    mov     A,0
lp:
    mov     [X + REGISTER_START],A
    dec     X
    jnc     lp
    #endasm
    return;
    }


/*
**
** FUNCTION:		IsUsbInterface
**
** PURPOSE:			Determines whether a USB or PS/2 host is connected upstream.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		This function performs the following algorithm:

					1) Wake up and delay 50mS. Initialize the PS2 BAT delay counter.

					2) For a period of 2mS, poll the SCLK and SDATA lines every 10uS.
					   If we get 4 samples in a row with non-zero data on either line, 
					   detect PS2. If the 2mS expires, go to (3).

					3) Enable USB pull up resistor and delay 500uS. 
					   Poll the SCLK and SDATA lines indefinitely 
					   until a non-zero condition exists on either line. 
					   During this polling period, we begin to count down the PS2 BAT delay.  
					   If SCLK(D+) is sampled high, detect PS2. If SDATA(D-) 
					   is sampled high, go to (4).

					4) Disable the USB connect resistor and Delay 100uS.  
						if D+ and D- are both 0, detect  USB, else detect PS2.
*/

char 	IsUsbInterface(void)
{

	char temp;
	char samples = 4;
     bBatDelay = (500 - 50);								//initialize BAT delay to 500 msec
	temp = MsecStatus.b1msCounter+50;					    //wait 50 msec
  														    
	while (temp != MsecStatus.b1msCounter)
		RESET_COP();
	temp = MsecStatus.b1msCounter+2;
	while (temp != MsecStatus.b1msCounter)					//for 2 msec, sample clock and data
	{
		if ((PORT2 & (PS2_CLOCK_BIT | PS2_DATA_BIT)) && (!--samples))
				return(0);									//4  consecutive samples of either clock or data high, it's ps2
		samples = 4;					
	}

	USB_STATUS = (VREG_ENABLE_MASK | FORCE_NEG_OPEN_POS_OPEN);//enable USB pullup 
	Delay(250);												//and delay 250 usec
	while (1)												//wait forever
	{
		RESET_COP();
		if (MsecStatus.b1msFlags & ONE_MSEC_FLAG)
		{
			if (bBatDelay)									//if a msec expires, decrease bat delay
				bBatDelay--;
			MsecStatus.b1msFlags &= ~ONE_MSEC_FLAG;
		}
		if (PORT2 & PS2_CLOCK_BIT)							
			return(0);										//clock bit high it's ps2
		if (PORT2 & PS2_DATA_BIT)							//data bit high, quit the loop
			break;
	}
	USB_STATUS = FORCE_NEG_OPEN_POS_OPEN;					//disable USB pullup 
    Delay(100);  
	return(!(PORT2 & (PS2_CLOCK_BIT | PS2_DATA_BIT)));		//if both clock and data go low, it's usb
}


/*
**
** FUNCTION:		MY_RESET_ISR
**
** PURPOSE:			Reset ISR, vectored to during power-up or watchdog reset.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		This function performs the following initialization:
**					
**					1)disables interrupts;
**					2)resets the watchdog;
**					3)initializes data stack pointer;
**					4)clears ram;
**					5)initializes port I/O;
*					6)enables 1msec interrupt;
**					7)jumps to main loop
**					
**
*/

void MY_RESET_ISR(void)
{
    DI();											//disable ints
	RESET_COP();									//reset watchdog

	/*
	** use assembler to initialize data stack
	*/
#asm (mov A,RAM_START + STACK_SIZE-1)			        
#asm (swap A,dsp)
      ClearRam();
	USB_STATUS = FORCE_NEG_OPEN_POS_OPEN;						//drive D+,D- to Hi-Z
	PORT0_MODE1 = PORT0_MODE1_INIT;								//set up port modes
	PORT0_MODE0 = PORT0_MODE0_INIT;								//
	PORT1_MODE0 = PORT1_MODE0_INIT ;							//
	PORT1_MODE1 = PORT1_MODE1_INIT;								//
	PORT0 = PORT0_INIT;											//set up initial values
	PORT1 = PORT1_INIT;											//
	PORT0IE = PORT0_INIT;										//set up for GPIO interrupts on switch inputs
	PORT1IE = PORT1_INIT;										//
	PORT0IP = ~PORT0_INIT;										//set up for negative edges interrupts switch inputs
	PORT1IP = ~PORT1_INIT;
	GLOBAL_INTERRUPT = MILLISECOND_ENABLE; 						//enable all pertinent interrupts
	EI();
    #asm (jmp main)
 }


/*
**
** FUNCTION:		main
**
** PURPOSE:			determines interface (usb or ps2) and dispatches to appropriate code.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		
**					
**
*/

 void main(void)
 {
    if (IsUsbInterface())								//if it is USB
    {
          UsbReInitialize();							//initialize USB variables
          usbmain();									//and go to usbmain
	}
	ps2main();											//else straight to ps2
}


/*
**
** FUNCTION:		ProcessOptics
**
** PURPOSE:			Extracts optics data from the queue, and accumulates X,Y, and Z counts
**					based on the state data of each quadrature pair.
** PARAMETERS:		none
**
** DESCRIPTION:		This routine is called from the main loop to process the optical data that has
**					accumulated during successive 128 usec interrupts. For each byte in the optics queue,
**					it extracts the X,Y,and Z state data, and uses the state data from the previous sample
**					to increment/decrement/hold the corresponding count data.	
**					
**
*/

void ProcessOptics(void)
{   
	char temp;
    char temp1;
      if (OpticsQueue.bLen > 16)								//somehow the queue overflowed
      {
		  DI();													//this should never happen, but if so
		  OpticsQueue.headP =									//reset the queue pointers and quit
		  OpticsQueue.tailP = bOpticsArray;
		  OpticsQueue.bLen = 0;
		  EI();
		  return;
      }
	while (OpticsQueue.bLen)
	{
		temp = GET_X_OPTICS(*OpticsQueue.tailP);				//get X quadrature inputs into [1:0]
		temp1 = temp;											//save temporarily
		temp |= Optics.bXstate;									//or in with previous state 
		Optics.bXstate = temp1 << 2;							//shift X inputs into [3:2] and save for next pass
		temp1 = Mouse.bXcount;
		Mouse.bXcount += quad_table[temp];						//use quadrature lookup to inc/dec xcount
		if ((unsigned char) Mouse.bXcount == 0x80)								//if overflow in either direction
			Mouse.bXcount = temp1;								//restore old count
																
		temp = GET_Y_OPTICS(*OpticsQueue.tailP);				//repeat for Y.....
		temp1 = temp;
		temp |= Optics.bYstate;
		Optics.bYstate = temp1 << 2;
		temp1 = Mouse.bYcount;
		Mouse.bYcount -= quad_table[temp];						//note, y counts need to be negated for proper direction
		if ((unsigned char) Mouse.bYcount == 0x80)
			Mouse.bYcount = temp1;

		temp = GET_Z_OPTICS(*OpticsQueue.tailP);				//repeat for Z....
		temp1 = temp;
		temp |= Optics.bZstate;
		Optics.bZstate = temp1 << 2;
		temp1 = Mouse.bZcount;
		Mouse.bZcount += z_quad_table[temp];
		if ((unsigned char) Mouse.bZcount == 0x80)
			Mouse.bZcount = temp1;

		*OpticsQueue.tailP++;									//manage queue pointers
 		if (OpticsQueue.tailP == &bOpticsArray[16])				//wrap them if necessary
			OpticsQueue.tailP = bOpticsArray;
		OpticsQueue.bLen--;
	}
}


/*
**
** FUNCTION:		MICROSECONDx128_ISR
**
** PURPOSE:			128 usec ISR.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		
**					This ISR samples the mouse optics and places the sample in a queue for
**					later processing by the main loop. This is done to minimize the execution time
**					of this ISR, which can interrupt during the time ps/2 bits are being clocked
**					to the host.  The timing of the ps/2 clocking is critical (20 us margin),
**					so the corresponding execution time of this ISR must be kept to less than 20 us.
**					
**
*/

void MICROSECONDx128_ISR(void)
{
	PUSHA();
	PUSHX();
	*OpticsQueue.headP++ = OPTICS_PORT;							//sample optical data
	OpticsQueue.bLen++;											//manage queue pointers and length
	if (OpticsQueue.headP == &bOpticsArray[16])					//wrap pointers if necessary
		OpticsQueue.headP = bOpticsArray;
	POPX();
	POPA();
}


/*
**
** FUNCTION:		MILLISECOND_ISR
**
** PURPOSE:			1 msec ISR.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		
**					This ISR maintains the 1msec counter variable,
**					and sets a flag indicating a 1msec interrupt has occurred. The main loop uses
**					these variables for timing purposes.
*/

void MILLISECOND_ISR(void)
{
    PUSHA();										//save A
    RESET_COP();
	MsecStatus.b1msFlags |= ONE_MSEC_FLAG;			//set flag for main loop
	MsecStatus.b1msCounter++;					    //increment 1msec counter
    POPA();
	return;
}


/*
**
** FUNCTION:		DebounceButtons
**
** PURPOSE:			Debounces the mouse switch inputs  
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine should be called at regular intervals from the main loop
**					to debounce the mouse switch inputs.  It maintains a count of the number
**					of successive identical samples of the switch inputs, and returns a 1
**					if the switch inputs have changed have been stable for the debounce interval.
*/

char GetButtons(void)
{
	char bButtons = 0;


	if (LEFT_SWITCH_ASSERTED)						//format an internal copy of the switches
		bButtons |= BIT0;							//this happens to be the USB format!
	if (RIGHT_SWITCH_ASSERTED)
		bButtons |= BIT1;
	/*
	** if Zwheel is enabled in either USB or PS2 mode, report the middle switch
	*/
	if ((MouseParms.bZmouse || DeviceStatus.bProtocol) && (MIDDLE_SWITCH_ASSERTED))
		bButtons |= BIT2;
	return(bButtons);
}

char DebounceButtons(void)
{
    char bButtons;
	bButtons = GetButtons();
 	if (bButtons == bLastButtons)				    //if same as last sample
	{
		  if (bDebounceCount && !--bDebounceCount)  //and debounce interval just expired
		  {
			  Mouse.bButtons = bLastButtons;			//record new buttons
			  return(1);							//and flag that a button change occurred
		  }
		  return(0);								//else no change yet occurred
	}
	bLastButtons = bButtons;						//buttons aren't stable, reset debounce count
	bDebounceCount = DEBOUNCE_COUNT;				//
	return(0);
}


/*
**
** FUNCTION:		USB_BUS_RESET_ISR
**
** PURPOSE:			Bus Reset ISR, vectored to during USB bus reset.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		This function performs the following initialization:
**					
**					1)disables interrupts;
**					2)resets the watchdog;
**					3)initialized data stack pointer and program stack pointer;
**					4 clears ram;
**					5)makes a call to initialize system variables;
**					6)enables device to respond at address 0;
**					7)jumps to main loop
**					
**
*/

void USB_BUS_RESET_ISR(void)
{

    DI();
	RESET_COP();						//tickle watchdog
										//initialize stacks using assembler
#asm (mov A,RAM_START + STACK_SIZE-1)			        
#asm (swap A,dsp)
#asm (mov A,0)
#asm (mov psp,a)
	ClearRam();
	UsbReInitialize();						//reinitialize all system variables

	USB_DEVICE_A = 0x80;  // enable endpoint zero response at address 0
	EP_A0_MODE = USB_MODE_STALL_IN_OUT;
										//and make the leap to the main loop
#asm(jmp usbmain)							
}


/*
**
** FUNCTION:		WAKEUP_ISR
**
** PURPOSE:			ISR for wakeup interrupt.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		The wakeup ISR increments a global counter which is used to "tune" the
**					frequency of the occurrence of the ISR itself (See routine TuneWakeup).
**
*/

void WAKEUP_ISR(void)
{
	bWakeupCount++;
}


/*
**
** FUNCTION:		GPIO_ISR
**
** PURPOSE:			ISR for wakeup interrupt. does nothing except returns  
**
** PARAMETERS:		none
**
** DESCRIPTION:	
**
*/

void GPIO_ISR(void)
{
	
}


/*
**
** FUNCTION:		USB_A_EP0_ISR
**
** PURPOSE:			Endpoint 0 Interrupt Service Routine.  
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					this routine is entered upon receiving an endpoint 0 interrupt.
**					EP0 interrupts occur during the Setup, data , and status phases of a
**					setup transaction.  This ISR dispatches the proper routine to handle
**					one of these phases. The interrupt will remain active until the
**					phase in question is completely handled.
*/

void USB_A_EP0_ISR(void)
{
	PUSHA();												//save A and X,they'll get wasted
	PUSHX();
	if (EP_A0_MODE & (1 << ACKNOWLEDGE))					//if this packet was acknowledged,
	{
		if (EP_A0_MODE & SETUP_RECEIVED_MASK)				//if a setup was received,
		{
			DeviceStatus.bAddress &= ~0x80;					//clear the address flag
			HandleSetup();									//and handle it
		}
		else if (EP_A0_MODE & IN_RECEIVED_MASK)				//if an in was received,
		{
			HandleIn();										//handle it
			if (DeviceStatus.bAddress & 0x80)		        //if the address flag was set during the setup
															//phase preceding this IN,
				  USB_DEVICE_A = DeviceStatus.bAddress;		//enable the new address
			DeviceStatus.bAddress &= ~0x80;					//and clear the new address flag
		}
	}
	POPX();
	POPA();
	return;
}


/*
**
** FUNCTION:		USB_A_EP1_ISR
**
** PURPOSE:			Endpoint 1 ISR.  
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					this routine is entered upon receiving an endpoint 1 interrupt.	
**					If the ACK bit is sent, indicating that a valid mouse packet was just
**					transmitted to the host, the SIE is set to NAK ins, and the
**					datatoggle bit is flipped for the next transaction.
*/

void USB_A_EP1_ISR(void)
{
	PUSHA();
	if (EP_A1_MODE & ( 1 << ACKNOWLEDGE))
	{
		EP_A1_MODE = USB_MODE_NAK_IN;
		EP_A1_COUNTER ^= DATATOGGLE;
	}
	POPA();
	return;
}


/*
**
** FUNCTION:		TuneWakeup
**
** PURPOSE:			to tune the wakeup ISR  
**
** PARAMETERS:		none
**
** DESCRIPTION:	    The wakeup interrupt period is variable by a factor of 5 due to operating and process
**					conditions.  The period has a prescaler which adjusts the period by a factor of two.
**					This routine is called at regular intervals to tune the wakeup ISR to occur at the
**					rate at which this routine is called, to within a factor of 2.  In other words, if
**					this routine is called every 256 msec, it will tune the wakeup ISR to occur at a rate
**					between 128-256 msec.
**					
**

*/

void TuneWakeup(void)
{
	char temp;
	temp = CLOCK_CONFIGURATION & TWAKEUP_MASK;				//get the current wakeup prescale value
	if ((bWakeupCount > 2) && (temp != TWAKEUP_MAX))			//if more than two wakeup ISRs occurred since
															//the last time this routine was called, and we
															//are not at the maximum prescale value already,
															//increment the prescaler to slow down the ISR interval
		temp += TWAKEUP_2;
	if ((!bWakeupCount) && (temp))							//if no wakeup ISRs occurred, and we are not
															//at the minimum prescale value,
															//decrement the prescaler to speed up the ISR interval
		temp -= TWAKEUP_2;
    CLOCK_CONFIGURATION = PRECISION_USB_CLOCKING | temp;
	bWakeupCount = 0;
}


/*
**
** FUNCTION:		usbmain
**
** PURPOSE:			USB main processing loop 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					main spins in an infinite loop waiting for an event that needs servicing.
**					Main is entered from either the power-on reset or the usb bus reset. Both
**					of these reset routines insures that all USB variables have been initialized
**					prior to calling usbmain.
*/

void usbmain(void)

{
   EI();
   while (1)
    {
		//clear watchdog timer
		RESET_COP();	
		ProcessOptics();											//empty the optics queue
		if (MsecStatus.b1msFlags & ONE_MSEC_FLAG)					//if 1 msec has elapsed
		{
			if (!MsecStatus.b1msCounter)							//every 256 msec tune the wakeup ISR
				TuneWakeup();
			if (DeviceStatus.bConfiguration && 
				(!(MsecStatus.b1msCounter & 3)))					//if we're configured, and if 4 msec has elapsed....
					MouseTask();									//go handle mouse stuff
			if (BusInactive())										//if the bus has gone inactive
			    Suspend();											//suspend us
			MsecStatus.b1msFlags &= ~ONE_MSEC_FLAG;	
		}
	}
}


/*
**
** FUNCTION:		Reinitialize
**
** PURPOSE:			Reinitializes system RAM and USB engine  
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine initializes all USB variables to their
**					default states, and resets USB engine controls to their initial values. RAM
**					has been cleared prior to entry.
*/

void UsbReInitialize(void)
{
	DI();														//disable ints
	RESET_COP();												//reset watchdog
    CLOCK_CONFIGURATION = PRECISION_USB_CLOCKING | TWAKEUP_64 ;	//set up precision clocking, /64 wakeup prescaler
																//this will set the initial wakeup time anywhere
																//from 64 - 5*64 msec.  
		OpticsQueue.headP = bOpticsArray;						//initialize queue pointers
	OpticsQueue.tailP = bOpticsArray;
	DeviceStatus.bProtocol = REPORT_PROTOCOL;					//start in report protocol
	USB_STATUS = VREG_ENABLE_MASK | NOT_FORCING;
	PROCESSOR_STATUS &= ~(WATCHDOG_RESET_MASK 					//clear source of reset
		| POWER_ON_RESET_MASK | USB_BUS_RESET_MASK);
	GLOBAL_INTERRUPT = MILLISECOND_ENABLE 						//enable all pertinent interrupts
		| BUS_RESET_ENABLE  | MICROSECOND_ENABLE | WAKEUP_ENABLE;
	USB_DEVICE_A = 0;											//reset device address
	EP_A0_MODE = USB_MODE_DISABLE;								//disable endpoints from responding
	EP_A1_MODE = USB_MODE_DISABLE;
	EP_A2_MODE = USB_MODE_DISABLE;
	ENDPOINT_INTERRUPT = (EPA0_ENABLE | EPA1_ENABLE);			//turn on endpoint interrupts
	return;
}


/*
**
** FUNCTION:		MouseMoved
**
** PURPOSE:			returns a 1 if the mouse's X,Y, or Z counts indicate movement.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		This routine will return a 1 if the accumulated X,Y, or Z counts are nonzero
**					.
**					 
*/

char MouseMoved(void)
{
	if (Mouse.bXcount || Mouse.bYcount)
	         return(1);
	if((DeviceStatus.bProtocol == REPORT_PROTOCOL)		//if Z wheel enabled, nonzero Z count requires a transmission
		&& Mouse.bZcount)
		return(1);
	return(0);
}
     

/*
**
** FUNCTION:		MouseTask
**
** PURPOSE:			Handles mouse data transmission.  
**
** PARAMETERS:		none
**
** DESCRIPTION:		This routine is called every 4 msec from the main loop. It
**					maintains the idle counter, which determines the rate at which mouse packets
**					are sent to the host in the absence of a state change in the mouse itself.
**					It also sends a mouse packet if either of X,Y, or Z counts or the buttons have
**					changed state.
**					 
*/

void MouseTask(void)
{
	Mouse.bChange |= DebounceButtons();				//keep track of button changes
	/*
	** if the idle period is nonzero, and the decremented counter rolls to zero,
	** set the change flag so we will send a packet regardless.
	*/
	if (MouseStatus.bIdlePeriod && !--MouseStatus.bIdleCounter)
	{
		MouseStatus.bIdleCounter = MouseStatus.bIdlePeriod;
		Mouse.bChange = 1;
	}
   	if ((EP_A1_MODE & USB_MODE_MASK) == USB_MODE_NAK_IN)     //we are NAKing, so it's ok to transmit a new package
	{
		Mouse.bChange |= MouseMoved();
		if (Mouse.bChange)										 //ok-transmission definitely required
		{

			ENDPOINT_A1_FIFO[0] = Mouse.bButtons;				 //load mouse data into fifo
			ENDPOINT_A1_FIFO[1] = Mouse.bXcount;
				  Mouse.bXcount = 0;  
			ENDPOINT_A1_FIFO[2] = Mouse.bYcount;
			Mouse.bYcount = 0;
			ENDPOINT_A1_FIFO[3] = Mouse.bZcount;
			Mouse.bZcount = 0;
			if (DeviceStatus.bProtocol == REPORT_PROTOCOL)		  //if report protocol, include z counts in length
				EP_A1_COUNTER = (EP_A1_COUNTER & DATATOGGLE) | 4;
			else
				EP_A1_COUNTER = (EP_A1_COUNTER & DATATOGGLE) | 3; //else omit it

			EP_A1_MODE = USB_MODE_ACK_IN;						  //flip mode to ack the in with the data
			MouseStatus.bIdleCounter = MouseStatus.bIdlePeriod;	  //and reset the idle period.
			Mouse.bChange = 0;								  //clear the flag
		}
	}
}


/*
**
** FUNCTION:		BusInactive
**
** PURPOSE:			Tests for upstream activity  
**
** PARAMETERS:		none
**
** DESCRIPTION:	    This routine should be called every msec from the main loop.
**					it maintains an internal count of the successive samples of the USB status register
**					in which no bus activity was recorded.  When this count exceeds 3 (msec), the
**					routine returns 1, indicating that bus activity has deceased
**					
*/

char BusInactive(void)
{
	if  (!(USB_STATUS & BUS_ACTIVITY_MASK))				//if no bus activity indicated in the status reg,
	    return(++bSuspendCounter == 3);					//return 0 if the counter has elapsed
	USB_STATUS = VREG_ENABLE_MASK;						//reset the flag (always write bit 4 to a 0 in this reg)
	bSuspendCounter = 0;
	return(0);
}


/*
**
** FUNCTION:		Suspend
**
** PURPOSE:			puts the chip into suspend  
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine handles the entrance/exit from suspend. If the mouse is configured for
**					remote wakeup, the bus reset, wakeup, and gpio interrupts are enabled.  The optical
**					inputs are sampled once.  The code then enters a loop in which the chip is suspended,
**					and will wake at least as often as the wakeup ISR, but perhaps due to a GPIO or bus
**					reset interrupt. Each time the chip wakes up, the  led drive is reenabled, and the
**					switches and optical inputs are sampled to see if a change occured, and bus activity
**					is monitored. Any of these conditions will cause the firmware to exit the loop.
**
**					if the device is not enabled for remote wakeup, all ports are put into the hi-Z state,
**					only the bus reset interrupt is enabled,and the part is suspended. 
**
**					if the resume was due to bus activity, the firmware returns to the main loop.
**					if the resume was due to mouse movement or a button press, a K state is driven upstream
**					for 14 msec prior to returning to the main loop.
*/

void Suspend(void)
{
	char Optics;
	char temp = 10;
	if (!DeviceStatus.bRemoteWakeup)	
	{
		
		GLOBAL_INTERRUPT = BUS_RESET_ENABLE;				//enable bus reset ISR only
		PORT0_MODE0 = PORT0_MODE0_SUSPEND;																	
		PORT1_MODE0 = PORT1_MODE0_SUSPEND;									
		PORT0_MODE1 = PORT0_MODE1_SUSPEND;																	
		PORT1_MODE1 = PORT1_MODE1_SUSPEND;
		PORT0 = PORT0_SUSPEND;
		PORT1 = PORT1_SUSPEND;
		PROCESSOR_STATUS |= 0x8;							//suspend 
		#asm(nop);
		RESET_COP();
		PORT0_MODE0 = PORT0_MODE0_INIT;						//re-init port modes									
		PORT1_MODE0 = PORT1_MODE0_INIT;
		PORT0_MODE1 = PORT0_MODE1_INIT;									
		PORT1_MODE1 = PORT1_MODE1_INIT;
		PORT0 = PORT0_INIT;
		PORT1 = PORT1_INIT;
	}
	else
	{
		//enable gpio, wakeup, and bus reset ISRs
		GLOBAL_INTERRUPT = BUS_RESET_ENABLE | GPIO_ENABLE | WAKEUP_ENABLE ;
		Optics = OPTICS_PORT;									//sample the optics port
		while (1)
		{														
			PORT0_MODE0 = PORT0_MODE0_RW;						//set ports to remote wakeup configuration																
			PORT1_MODE0 = PORT1_MODE0_RW;									
			PORT0_MODE1 = PORT0_MODE1_RW;																	
			PORT1_MODE1 = PORT1_MODE1_RW;
			PORT0 = PORT0_RW;
			PORT1 = PORT1_RW;
			PROCESSOR_STATUS |= 0x8;							//suspend (wakeup timer will wake us up)
			#asm(nop);
			PORT0_MODE0 = PORT0_MODE0_INIT;						//re-init port modes									
			PORT1_MODE0 = PORT1_MODE0_INIT;
			PORT0_MODE1 = PORT0_MODE1_INIT;									
			PORT1_MODE1 = PORT1_MODE1_INIT;
			PORT0 = PORT0_INIT;
			PORT1 = PORT1_INIT;
			RESET_COP();
			if (USB_STATUS & BUS_ACTIVITY_MASK)					//if wakeup due to bus activity (including bus reset), get out 
																//of this loop
				break;
			if (GetButtons() != Mouse.bButtons)					//if mouse buttons switches different, get out
				break;
			Delay(20);											//wait some more time for optic led to come on
			if ((OPTICS_PORT ^ Optics) & OPTICS_MASK)			//if optics have changed, get out
				break;
		}  
	}
	GLOBAL_INTERRUPT = MILLISECOND_ENABLE 						//reenable all interrupts used in main loop
		| BUS_RESET_ENABLE  | MICROSECOND_ENABLE | WAKEUP_ENABLE;
	temp = MsecStatus.b1msCounter + 5;							//wait 5 msec
	while (temp != MsecStatus.b1msCounter)
	{
		RESET_COP();
 		if (USB_STATUS & BUS_ACTIVITY_MASK)				    //if bus activity is present, get out now
			return;
	}
	USB_STATUS = VREG_ENABLE_MASK | FORCE_J;			    //otherwise force resume upstream for 14 msec
	USB_STATUS = VREG_ENABLE_MASK | FORCE_K;
 	temp = MsecStatus.b1msCounter +	14;						//		
	while (temp != MsecStatus.b1msCounter)
		RESET_COP();
	USB_STATUS = VREG_ENABLE_MASK | NOT_FORCING;		    //switch to nonforcing
	bSuspendCounter = 0;
	return;
}


/*
**
** FUNCTION:		HandleIn
**
** PURPOSE:			Services In packets 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever an IN packet has come in on endpoint 0.
**					it processes the packet.
**					
*/

void HandleIn(void)

{
	//an ACKed IN occurs either in the case of the status phase of a control write,
	//or the data in phase of a control read.  The only thing we are expecting is the
	//data in phase -- there are no control writes to the mouse
	if ((EP_A0_MODE & USB_MODE_MASK) != USB_MODE_NAK_IN_STATUS_OUT )
	{
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);					//we weren't expecting this!!
		return;
	}
	byte_count = EP_A0_COUNTER;									//unlock the counter register by reading it
	byte_count = 0;												//zero the byte count
	if (XmtBuff.bLength)										//if we've stuff to send,
	    	byte_count = LoadEP0Fifo();			//load it into fifo
			//account for the bytes we will send this pass
	//load up the counter
	EP_A0_COUNTER = (EP_A0_COUNTER & DATATOGGLE) ^ DATATOGGLE;
	EP_A0_COUNTER |= byte_count;
	//and set the ep mode to ack the next IN with the data.
	EP_A0_MODE = USB_MODE_ACK_IN_STATUS_OUT;

}


/*
**
** FUNCTION:		USB_control_read
**
** PURPOSE:			Prepares the SIE for the first IN after a SETUP requesting data
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is called after a SETUP has been received that is requesting
**					a data response from the mouse. Upon entry, XmtBuff has been initialized to
**					point to the data buffer that needs to be tranmsitted.  USB_control_read
**					adjusts the length of the data to be returned if the host requested less
**					data than the actual length of the buffer.  It then loads the FIFO with the
**					first chunck of data and prepares the SIE to ACK with the data.
**					
*/

void USB_control_read(void)

{
	//if the host requested less data than is actually available, use that length instead

	if ((!ENDPOINT_A0_FIFO[USB_wLengthHi]) && (ENDPOINT_A0_FIFO[USB_wLength] < XmtBuff.bLength))
		XmtBuff.bLength = ENDPOINT_A0_FIFO[USB_wLength];
	byte_count = 0;
	if (XmtBuff.bLength)
		byte_count = LoadEP0Fifo();							//data to send. Load FIFO with first chunck
	EP_A0_COUNTER =  DATATOGGLE | byte_count;				//set up counter
	EP_A0_MODE = USB_MODE_ACK_IN_STATUS_OUT;				//and set up SIE to ACK with the data
}


/*
**
** FUNCTION:		LoadEP0Fifo
**
** PURPOSE:			loads EP0 fifo with available data 
**
** PARAMETERS:		bLength -- length of data available to load
**
** DESCRIPTION:	 
**					This routine loads the fifo with data pointed to by XmtBuff.  It
**					returns the length of data actually loaded into the FIFO.
**					
*/

char LoadEP0Fifo(void)
{

	byte_count1 = 0;

	while (byte_count1 < 8)									//FIF0 is only 8 bytes long
	{
		ENDPOINT_A0_FIFO[byte_count1++] = *(XmtBuff.p);		//move data into FIFO
		XmtBuff.p++;
		if (!--XmtBuff.bLength)								//if we have exhausted the data, quit
			break;
	}
	return(byte_count1);										//returns the number of bytes loaded
}


/*
**
** FUNCTION:		SetConfiguration
**
** PURPOSE:			Implements the Set Configuration Command
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered Set Configuration request has been received from the host.
**					
*/

void SetConfiguration(void)
{
    if ( (ENDPOINT_A0_FIFO[USB_bmRequestType] == (HOST_TO_DEVICE | STANDARD | DEVICE)) &&
		 ((ENDPOINT_A0_FIFO[USB_wValue] == UNCONFIGURED) || (ENDPOINT_A0_FIFO[USB_wValue] == CONFIGURED) ))
    {
        DeviceStatus.bConfiguration = ENDPOINT_A0_FIFO[USB_wValue];			//set the configuration 
        DeviceStatus.bEP1Stall = 0;											//and clear EP1 stall	
        EP_A1_COUNTER &= ~DATATOGGLE;										//clear EP1's data toggle
        if(DeviceStatus.bConfiguration == UNCONFIGURED)
			EP_A1_MODE = USB_MODE_DISABLE;									//not configured -- disable EP1 from responding
        else
 			EP_A1_MODE = USB_MODE_NAK_IN;									//configured -- NAK traffic on EP1
        SET_EP0_MODE(USB_MODE_STATUS_ONLY);	
 
    }
    else
	//something was awry with the command, stall
    SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
}


/*
**
** FUNCTION:		SetAddress
**
** PURPOSE:			Implements Set Address command 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever a SETUP request to set the address has been received.
**					The address change cannot actually take place until the ensuing status-in is received
**					from the host -- so we just save the address and set a flag to indicate that a new
**					address was just received.  The code that handles INs will recognize this and set the address
**					properly.
**			
**					
*/

void SetAddress(void)
{
	if (ENDPOINT_A0_FIFO[USB_bmRequestType] != HOST_TO_DEVICE | STANDARD | DEVICE)
	{
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
	}
	else
	{
	    DeviceStatus.bAddress = 0x80 | ENDPOINT_A0_FIFO[USB_wValue];  //save address away, we can't actually use it yet
		SET_EP0_MODE(USB_MODE_STATUS_ONLY);
	}

}
											

/*
**
** FUNCTION:		ClearFeature
**
** PURPOSE:			Handles Clear Feature requests
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine checks for either a clear-remote-wakeup request,
**					or a clear-endpoint-stall request on endpoint 1 -- the only two valid clear
**					feature requests for this device.
**					
*/

void ClearFeature(void)
{

	if ((ENDPOINT_A0_FIFO[USB_bmRequestType] ==(HOST_TO_DEVICE | STANDARD | DEVICE))
		&& (ENDPOINT_A0_FIFO[USB_wValue] == USB_DEVICE_REMOTE_WAKEUP ) &&
		   ( !ENDPOINT_A0_FIFO[USB_wValueHi]))
		{
			DeviceStatus.bRemoteWakeup = DISABLE_REMOTE_WAKEUP; /* disable remote wakeup */
			SET_EP0_MODE(USB_MODE_STATUS_ONLY);
			return;
		}
	if ((ENDPOINT_A0_FIFO[USB_bmRequestType] == (HOST_TO_DEVICE | STANDARD | ENDPOINT)) &&
		   (DeviceStatus.bConfiguration == CONFIGURED) &&
		(!ENDPOINT_A0_FIFO[USB_wValueHi]) &&
		(ENDPOINT_A0_FIFO[USB_wIndex] == 0x81)&&	
		(ENDPOINT_A0_FIFO[USB_wValue] == USB_ENDPOINT_STALL)) 
		{																/*ep1 stall request*/
			DeviceStatus.bEP1Stall = 0;									/* not stalled */
			EP_A1_COUNTER &= ~DATATOGGLE;								/* clear data 0/1 bit */
			EP_A1_MODE = USB_MODE_NAK_IN_OUT;							//nak anything on endpoint 1 until ready
			SET_EP0_MODE(USB_MODE_STATUS_ONLY);
			return;
	   }
	SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
 	return;
}


/*
**
** FUNCTION:		SetFeature
**
**
**
** PURPOSE:			Handles Set Feature requests 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine checks for either a set-remote-wakeup request,
**					or a set-endpoint-stall request on endpoint 1 -- the only two valid set
**					feature requests for this device.
**					
*/

void SetFeature(void)
{
	if ( (ENDPOINT_A0_FIFO[USB_bmRequestType] == (HOST_TO_DEVICE | STANDARD | DEVICE)) &&
		( ENDPOINT_A0_FIFO[USB_wValue] == USB_DEVICE_REMOTE_WAKEUP ) &&
		 ( !ENDPOINT_A0_FIFO[USB_wValueHi]))
		{
 			DeviceStatus.bRemoteWakeup = ENABLE_REMOTE_WAKEUP; /* set remote wakeup */
			SET_EP0_MODE(USB_MODE_STATUS_ONLY);
			return;
		}
	if ( (ENDPOINT_A0_FIFO[USB_bmRequestType] == (HOST_TO_DEVICE | STANDARD | ENDPOINT)) &&
		(DeviceStatus.bConfiguration == CONFIGURED) &&
			(!ENDPOINT_A0_FIFO[USB_wValueHi]) &&
			(ENDPOINT_A0_FIFO[USB_wIndex] == 0x81) && 
			(ENDPOINT_A0_FIFO[USB_wValue] == USB_ENDPOINT_STALL)) 
		{
			DeviceStatus.bEP1Stall = 1;								//mark endpoint as stalled
			EP_A1_MODE = USB_MODE_STALL_IN_OUT;						//stall traffic on endpoint 1
			SET_EP0_MODE(USB_MODE_STATUS_ONLY);
			return;
		}
	//command not valid
    SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
	return;
}


/*
**
** FUNCTION:		GetDescriptor
**
** PURPOSE:			Gets the requested descriptor 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered when a Get Descriptor request is received.
**					It decodes the descriptor request and initializes XmtBuff to the
**					proper descriptor, then initiates the transfer by calling USB_control_read
**					
**					
*/

void GetDescriptor(void)
{
 	if ( (ENDPOINT_A0_FIFO[USB_bmRequestType] != (DEVICE_TO_HOST | STANDARD | DEVICE)) && 
		 (ENDPOINT_A0_FIFO[USB_bmRequestType] != (DEVICE_TO_HOST | STANDARD | INTERFACE)) &&
		 (ENDPOINT_A0_FIFO[USB_bmRequestType] != (DEVICE_TO_HOST | STANDARD | ENDPOINT)))		
	{
			 SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
			return;
	}
    switch (ENDPOINT_A0_FIFO[USB_wValueHi]) 
    {
		//decode descriptor request
        case USB_DEVICE :
            XmtBuff.bLength = device_desc_table[0];
            XmtBuff.p = device_desc_table;
            break;
        case USB_CONFIGURATION :
            XmtBuff.bLength = sizeof(config_desc_table) + 
							sizeof(Interface_Descriptor) + 
							sizeof(Class_Descriptor) + 
							sizeof(Endpoint_Descriptor);
            XmtBuff.p=config_desc_table;
            break;
        case USB_STRING :
            switch(ENDPOINT_A0_FIFO[USB_wValue])
            {
            case 0x00 :
                XmtBuff.bLength = sizeof(USBStringLanguageDescription);
                XmtBuff.p=USBStringLanguageDescription;
                break;
            case 0x01 :
                XmtBuff.bLength = sizeof(USBStringDescription1);
                XmtBuff.p=USBStringDescription1;
               break;
            case 0x02 :
                XmtBuff.bLength = sizeof(USBStringDescription2);
                XmtBuff.p=USBStringDescription2;
               break;
            case 0x03 :
                XmtBuff.bLength = sizeof(USBStringDescription3);
                XmtBuff.p=USBStringDescription3;
                break;
            case 0x04 :
                XmtBuff.bLength = sizeof(USBStringDescription4);
                XmtBuff.p=USBStringDescription4;
                break;
            case 0x05 :
                XmtBuff.bLength = sizeof(USBStringDescription5);
                XmtBuff.p=USBStringDescription5;
                break;
           default       :
                SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
                return;
            }
            break;
        case USB_HID :
            XmtBuff.bLength = sizeof(Class_Descriptor);
            XmtBuff.p=Class_Descriptor;
            break;
        case USB_REPORT :
            XmtBuff.bLength = sizeof(hid_report_desc_table); 
            XmtBuff.p=hid_report_desc_table;
            break;
        default :
			//not a recognizable request, stall
            SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
            return;
    }
	//initiate the transfer
    USB_control_read();
}


/*
**
** FUNCTION:		GetStatus
**
** PURPOSE:			Implements a Get Status request 
**
** PARAMETERS:		none
**
** DESCRIPTION:	    This routine checks for either a request to get the device
**					status, the interface status, or the endpoint status,
**					sets up XmtBuff to point to the appropriate status, and
**					calls USB_control_read to initiate the transfer.
**					
**					
**					
*/

void GetStatus(void)
{
	switch (ENDPOINT_A0_FIFO[USB_bmRequestType])
	{
     case (DEVICE_TO_HOST | STANDARD | DEVICE):
      	XmtBuff.bLength = 2;										//send 2 bytes
		XmtBuff.p = &DeviceStatus.bRemoteWakeup;					//point at remote wakeup status
		break;
	case (DEVICE_TO_HOST | STANDARD | INTERFACE):
		XmtBuff.bLength = sizeof(get_interface_status_table);		//point at interface status
		XmtBuff.p=get_interface_status_table;
		break;
	case (DEVICE_TO_HOST | STANDARD | ENDPOINT):
	    XmtBuff.bLength = 2;										//send two bytes 
		XmtBuff.p = &DeviceStatus.bEP1Stall;						//point at endpoint stall status
		break;
	default:
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);						//bogus request, complain
		return;
	}
 	USB_control_read();												//initiate transfer
 }


/*
**
** FUNCTION:		SetIdle
**
** PURPOSE:			implements a request to set the idle period
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever a Set Idle request is received.
**					See the HID spec for the rules on setting idle periods.				
*/

void SetIdle(void)

{
	if ( ((ENDPOINT_A0_FIFO[USB_bmRequestType] !=  (HOST_TO_DEVICE | CLASS    | INTERFACE)) &&
		(ENDPOINT_A0_FIFO[USB_bmRequestType] !=  (HOST_TO_DEVICE | CLASS    | ENDPOINT)))  ||
		(ENDPOINT_A0_FIFO[USB_wIndex]) || (ENDPOINT_A0_FIFO[USB_wIndexHi]))
	{
		//request not valid, stall
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
		return;
	}
	if (!MouseStatus.bIdlePeriod)
	{
		//current idle setting is off. set both the new period and the counter
		MouseStatus.bIdlePeriod = ENDPOINT_A0_FIFO[USB_wValueHi];
		MouseStatus.bIdleCounter = MouseStatus.bIdlePeriod;
		SET_EP0_MODE(USB_MODE_STATUS_ONLY);
		return;
	}

	if (MouseStatus.bIdleCounter <= 2)
	{
		// counter for current idle period is nearly expiring.  leave it alone,
		//but set new idle period
		MouseStatus.bIdlePeriod = ENDPOINT_A0_FIFO[USB_wValueHi];
		SET_EP0_MODE(USB_MODE_STATUS_ONLY);
		return;
	}
	if ( ENDPOINT_A0_FIFO[USB_wValueHi] > MouseStatus.bIdleCounter)
	{
		//new period is shorter than the old one.  Force current idle period to expire soon,
		//and set new idle period
	      MouseStatus.bIdlePeriod = ENDPOINT_A0_FIFO[USB_wValueHi];
		MouseStatus.bIdleCounter = 1;
	}
	else
	{
		//new period is longer than old one. set new idle period, and adjust current period
		//to be equal to the new period, minus the counts that have already expired for the old one
		 MouseStatus.bIdlePeriod  = ENDPOINT_A0_FIFO[USB_wValueHi];
		MouseStatus.bIdleCounter = ENDPOINT_A0_FIFO[USB_wValueHi] - MouseStatus.bIdlePeriod;
	}
	SET_EP0_MODE(USB_MODE_STATUS_ONLY);
	return;
}


/*
**
** FUNCTION:		SetProtocol
**
** PURPOSE:			Implements the set-protocol request 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever an Set Protocol request is received
**					
*/

void SetProtocol(void)
{

	if (((ENDPOINT_A0_FIFO[USB_bmRequestType] !=  (HOST_TO_DEVICE | CLASS | INTERFACE)) &&
		(ENDPOINT_A0_FIFO[USB_bmRequestType] !=  (HOST_TO_DEVICE | CLASS | ENDPOINT))) ||
	    (ENDPOINT_A0_FIFO[USB_wIndex]) || 
		(ENDPOINT_A0_FIFO[USB_wIndexHi]) ||
		(ENDPOINT_A0_FIFO[USB_wValue] > REPORT_PROTOCOL))
		//invalid request, stall
        SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
    else
    {
        DeviceStatus.bProtocol = ENDPOINT_A0_FIFO[USB_wValue];		//set the new protocol
        SET_EP0_MODE(USB_MODE_STATUS_ONLY);										//acknowledge
    }
}


/*
**
** FUNCTION:		GetReport
**
** PURPOSE:			Implements the GetReport request 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever a request to get a report is received.
**					The most recent mouse data report is in the EP1 fifo.
**					
*/

void GetReport(void)
{

	if (ENDPOINT_A0_FIFO[USB_bmRequestType] !=  (DEVICE_TO_HOST | CLASS  | INTERFACE)) 
	{
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
		return;
	}
	//depending upon the current protocol, either send a 3 or 4-byte mouse packet
	//
    XmtBuff.bLength = (DeviceStatus.bProtocol == REPORT_PROTOCOL ? 4 : 3);	
    XmtBuff.p = &Mouse.bButtons;
    USB_control_read();
}


/*
**
** FUNCTION:		GetIdle
**
** PURPOSE:			Implements the Get Idle Request 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever a Get Idle request is received.
**					
**					
*/

void GetIdle(void)
{

	if (ENDPOINT_A0_FIFO[USB_bmRequestType] !=  (DEVICE_TO_HOST | CLASS | INTERFACE)) 
	{
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
		return;
	}
    XmtBuff.bLength = 1;								//idle is 1-byte long
    XmtBuff.p=&MouseStatus.bIdlePeriod;					//point at it
    USB_control_read();									//initiate transfer
}


/*
**
** FUNCTION:		GetProtocol
**
** PURPOSE:			Implements the Get Protocol Request 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever a Get Protocol request is received
**					
*/

void GetProtocol(void)
{

	if (ENDPOINT_A0_FIFO[USB_bmRequestType] !=  (DEVICE_TO_HOST | CLASS    | INTERFACE)) 
	{
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
		return;
	}
    XmtBuff.bLength = 1;								//set length of protocol
    XmtBuff.p=&DeviceStatus.bProtocol;					//aim XmtBuff at it
    USB_control_read();									//initiate transfer
}


/*
**
** FUNCTION:		GetConfiguration
**
** PURPOSE:			Implements the Get Configuration command
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever a Get Configuration Request is received.
**					
*/

void GetConfiguration(void)
{
 	if (ENDPOINT_A0_FIFO[USB_bmRequestType] != DEVICE_TO_HOST | STANDARD | DEVICE)
	{
		SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
		return;
	}
	XmtBuff.bLength = 1;								//configuration is 1-byte long
    XmtBuff.p=&DeviceStatus.bConfiguration;				//point at it
    USB_control_read();									//initiate transfer
}


/*
**
** FUNCTION:		USB_Stall_In_Out
**
** PURPOSE:			sets the SIE mode to stall IN/OUT packets on endpoint 0
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					
**					
*/

void USB_Stall_In_Out(void)
{
    SET_EP0_MODE(USB_MODE_STALL_IN_OUT);
}



#pragma memory ORG @ 0x880

const void (* StandardFunctionTable[])(void)= 
{
   GetStatus,ClearFeature,USB_Stall_In_Out,SetFeature,
   USB_Stall_In_Out,SetAddress,GetDescriptor,USB_Stall_In_Out,
   GetConfiguration,SetConfiguration,GetStatus
};
/*
** define a lookup table of function pointers to class requests
*/
const void (* ClassFunctionTable[])(void)= 
{
  USB_Stall_In_Out, GetReport, GetIdle,GetProtocol,
  USB_Stall_In_Out, USB_Stall_In_Out, USB_Stall_In_Out,USB_Stall_In_Out,
  USB_Stall_In_Out, USB_Stall_In_Out, SetIdle,SetProtocol
};


/*
**
** FUNCTION:		HandleSetup
**
** PURPOSE:			Services Setup packets 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					This routine is entered whenever an SETUP packet has come in on endpoint 0.
**					it performss some preliminary validation on the packet, then
**					parses the packet and calls the appropriate routine to handle the packet.
**					
*/

void HandleSetup(void)

{
	EP_A0_MODE = USB_MODE_NAK_IN_OUT;						//unlock mode register
	/*
	** Setups are always 10 bytes, with DATAVALID = 1 and DATATOGGLE = 0
	*/
	if ( (EP_A0_COUNTER & (DATAVALID | DATATOGGLE | COUNT_MASK)) ==
		  (DATAVALID | 10))
	{
		if (ENDPOINT_A0_FIFO[USB_bmRequestType] & CLASS)
		{	
								
			if (ENDPOINT_A0_FIFO[USB_bRequest] <= USB_SET_PROTOCOL)				//class request, use class table
			{
				(*ClassFunctionTable[ENDPOINT_A0_FIFO[USB_bRequest]])();
				return;
			}
		}
		else
		{
			if (ENDPOINT_A0_FIFO[USB_bRequest] <= USB_GET_INTERFACE)			//standard request, use standard table
			{
				(*StandardFunctionTable[ENDPOINT_A0_FIFO[USB_bRequest]])();
				return;
			}
		}
	}
	SET_EP0_MODE(USB_MODE_STALL_IN_OUT);										//invalid request, stall
}


//**************************************************************************************8
//PS2 routines

/*
**
** FUNCTION:		ps2main
**
** PURPOSE:			main processing loop for PS/2 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					ps2main spins in an infinite loop waiting for an event that needs servicing.
*/

void ps2main(void)
{

	char bInputByte;			//storage for byte received from host
    ReInitialize();				//reinitialize all ps2 variables to default states
    SetDefault();				//set the host-settable parameters to the default states
	EI();						//enable interrupts
	ps2BAT();					//send the BAT code
	/*
	** only now can we enable the 128 usec interrupt, which will start filling the optics queue
	** with data.  ProcessOptics must be called at regular intervals from this point on, to prevent
	** the optics queue from overflowing.
	*/
	GLOBAL_INTERRUPT = MILLISECOND_ENABLE | MICROSECOND_ENABLE;
	while (1)
	{
		RESET_COP();									//always tickle watchdog
		ProcessOptics();								//empty optics queue
		bInputByte = GetByte();							//see if host has sent us anything
		if (!(CC.C))									//if carry is clear, a byte indeed arrived)
		{
			ProcessCommand(bInputByte);					//so go handle it
			continue;
		}
		if (Ps2Xmt.bXmtLen)								//anything to send?
		{
			PutNextByte();								//send a byte.
			continue;
		}

		if (MsecStatus.b1msFlags & ONE_MSEC_FLAG)		//1 msec expired?
		{	
			MsecStatus.b1msFlags &= ~ONE_MSEC_FLAG;
			Ps2MouseTask();								//do mouse stuff
   		}
	}
}


/*
**
** FUNCTION:		Ps2MouseTask
**
** PURPOSE:			handles ps2 mouse data packet management 
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					
*/

void Ps2MouseTask(void)
{
	if (!(MsecStatus.b1msCounter & 3))						//4 msec expired?
		Mouse.bChange |= DebounceButtons();					//yes, debounce switches
	if (!--bIntervalCount)									//if the mouse interval counter has expired,
	{
		ResetInterval();									//reset the interval
		if (MouseParms.bStream && MouseParms.bEnabled)

			SendMouseData();								//if the mouse is enabled and in stream mode, send a packet
	}
}


/*
**
** FUNCTION:		Reinitialize
**
** PURPOSE:			Reinitializes ps2 variables to their default states  
**
** PARAMETERS:		none
**
** DESCRIPTION:	 
**					
*/

void ReInitialize(void)
{
	DI();											//disable ints
	USB_STATUS = (PS2_PULLUP_MASK | PS2_INTERRUPT_MODE_MASK |FORCE_NEG_OPEN_POS_OPEN);
	RESET_COP();									//reset watchdog
	ClearRam();
	OpticsQueue.headP = bOpticsArray;
	OpticsQueue.tailP = bOpticsArray;
	PROCESSOR_STATUS &= ~(WATCHDOG_RESET_MASK		            //clear source of reset
		| POWER_ON_RESET_MASK | USB_BUS_RESET_MASK);
	USB_DEVICE_A = 0;											//reset device address
	EP_A0_MODE = USB_MODE_DISABLE;								//disable endpoints from responding
	EP_A1_MODE = USB_MODE_DISABLE;
	EP_A2_MODE = USB_MODE_DISABLE;
	GLOBAL_INTERRUPT = MILLISECOND_ENABLE;						//enable only 1msec interrupt
	return;
}


/*
**
** FUNCTION:		ResetInterval
**
** PURPOSE:			Resets the mouse report interval
**
** PARAMETERS:		none
**
** DESCRIPTION:		This routine resets the mouse's report interval to the value last
**					sent by the host.  The report interval is counted down in the main loop
**					to provide a time base for sending mouse data packets.
**					
*/

void ResetInterval(void)
{
	bIntervalCount = MouseParms.bReportInterval;
}


/*
**
** FUNCTION:	GetByte		
**
** PURPOSE:		tries to get a byte from the host	
**	
** PARAMETERS:		
**
** DESCRIPTION:	GetByte checks to see if the host is requesting-to-send data, and if so,
**				clocks in a data byte from the host.  It returns the received byte 
**				and implicitly sets the carry to 0 if the reception occurred without errors.
**				GetByte turns off the 1msec interrupt during ps2 clocking so as not to
**				impose the potential for clock jitter due to that interrupt.
**					
**					
*/

char GetByte (void)
{
    char dummy;
	if (HOST_RTS)	                        				//host not requesting to send
	{
		GLOBAL_INTERRUPT = MICROSECOND_ENABLE;				//shut off msec interrupt
		dummy = ps2_receive();								//get data. ps2_receive sets the carry
															//to 1 if there was a problem in reception.
															
		GLOBAL_INTERRUPT = MILLISECOND_ENABLE | MICROSECOND_ENABLE;
		return(dummy);										//return data (and carry bit too)
	}
	CC.C = 1;												//couldn't get data, so set carry to one and exit
	return(0);
}


/*
**
** FUNCTION: ps2BAT		
**
** PURPOSE:	 delays for 500 msec, then sends the AA 00 initialization string	
**	
** PARAMETERS: none		
**
** DESCRIPTION:	 
**					
**					
*/

void ps2BAT(void)
{
	while (bBatDelay--)									//count down number of msec in bBatDelay
	{
		while (!(MsecStatus.b1msFlags & ONE_MSEC_FLAG))	//eat up a msec
			RESET_COP();
		MsecStatus.b1msFlags &= ~ONE_MSEC_FLAG;
	}
	Ps2Xmt.bMsgBuff[0] = 0xAA;							//send AA 00 to host
	Ps2Xmt.bMsgBuff[1] = 00;
	Ps2Xmt.bMsgLen = 2;
	Ps2Xmt.bXmtLen = 2;
}


/*
**
** FUNCTION:	PutNextByte		
**
** PURPOSE:		attempts to send  the next byte in the transmit queue to the host
**	
** PARAMETERS:  none		
**
** DESCRIPTION:	This routine sends the next byte  of the message buffer to the host.
**					
**					
*/

void PutNextByte(void)
{
	if (HOST_RTS || HOST_INHIBIT)								//host is requesting to send data, quit
		return;
	GLOBAL_INTERRUPT = MICROSECOND_ENABLE;
	ps2_send(Ps2Xmt.bMsgBuff[Ps2Xmt.bMsgLen-Ps2Xmt.bXmtLen]);							//send the byte
	GLOBAL_INTERRUPT = MILLISECOND_ENABLE | MICROSECOND_ENABLE;
	if (!CC.C)
		Ps2Xmt.bXmtLen--;
}


/*
**
** FUNCTION:	Put	
**
** PURPOSE:		sends a byte to the host
**	
** PARAMETERS:	data -- byte to send	
**
** DESCRIPTION:	Put attempts to send a byte to the host. It is called to send an ACK, ERROR, or RESEND
**				to the host. In accordance with the IBM spec, these responses are not held for retransmission
**				in the event that the  host requests to send a byte before we can send the response itself.
**				Thus, this routine waits for host inhibit to go away, then sends the byte.  If the host
**				requests-to-send before this happens, it simply returns without sending the byte.
**					
**					
*/

void Put(char data)
{
	if(HOST_RTS)
		return;

	while (!HOST_RTS)
	{
		//we could sit in this loop for a long time, if the host is inhibiting us.  This is ok.
		//the 128 us interrupt is running and the optics queue might overflow, but that will
		//be fixed up upon return to the main loop (see code in ProcessOptics).  This is harmless --
		//the mouse is supposed to be disabled by the host prior to executing commands, so
		//we aren't required to be accumulating samples at this point, anyway.
		if (!HOST_INHIBIT)
		{
			GLOBAL_INTERRUPT = MICROSECOND_ENABLE;
			ps2_send(data);							//send the byte
			GLOBAL_INTERRUPT = MILLISECOND_ENABLE | MICROSECOND_ENABLE;
			return;									//ps2_send will set carry for us
		}
		RESET_COP();
	}
}


/*
**
** FUNCTION:	Reset		
**
** PURPOSE:		executes a reset 	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 Reset simply gets into a loop waiting for the watchdog to perform a reset.
**					
**					
*/

void Reset(void)
{
     GLOBAL_INTERRUPT = 0;
	while (1);									//death by watchdog
}


/*
**
** FUNCTION:	Resend		
**
** PURPOSE:		Resends the last  transmission from the mouse	
**	
** PARAMETERS:	None	
**
** DESCRIPTION:	A copy of the  last  transmission is always left intact in the message buffer.
**				To resend it , we simply need to reset the message length.
**					
**					
*/

void Resend(void)
{
	Ps2Xmt.bXmtLen = Ps2Xmt.bMsgLen;

}


/*
**
** FUNCTION:	SetDefault	
**
** PURPOSE:		Sets the mouse parameters to the default settings
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void SetDefault(void)
{
	MouseParms.bReportRate = 100;						//100 reports per second
	MouseParms.bReportInterval = 10;					//is equal to a report every 10 msec
	MouseParms.bScale = SC_1_1;							//1-to-1 scaling
	MouseParms.bStream = 1;								//stream mode on
	MouseParms.bResolution = RES_4MM;					//4 MM resolution
	MouseParms.bEnabled = 0;							//not enabled
	MouseParms.bZmouse = 0;								//z-wheel off.
}


/*
**
** FUNCTION:	Disable		
**
** PURPOSE:		Disables the mouse	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void Disable(void)
{
	MouseParms.bEnabled = 0;					//disable mouse
}


/*
**
** FUNCTION: Enable		
**
** PURPOSE:	 Enables the mouse	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void Enable(void)
{
	MouseParms.bEnabled = 1;					//enable mouse
}


/*
**
** FUNCTION: SetSampleRateAck		
**
** PURPOSE:	 Set Sample Rate is a two byte command -- the 2nd byte being the sample rate itself.
**			 This routine is called after reception of the first byte, and so does nothing
**			 by itself	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void SetSampleRateAck(void)
{
	//return
}


/*
**
** FUNCTION:	SetSampleRate		
**
** PURPOSE:		verifies and sets the sample rate for the mouse		
**	
** PARAMETERS:	bRate: Sample Rate	
**
** DESCRIPTION:	 
**					
**					
*/

const char Rates[] = {10,20,40,60,80,100,200};				//table of acceptable report rates
const char Intervals[] = {100,50,25,17,13,10,5};			//table of intervals corresponding to each rate.
															//i.e., report rate of 10/sec translates
															//to a 100 msec interval between reports	
#define NUM_RATES 7
char SetSampleRate(char bRate)
{
	char i;
															//check the rate to see if it is valid
	for (i = 0; i < NUM_RATES; i++)
	{
		if (bRate == Rates[i])
		{
			MouseParms.bReportRate = bRate;					//valid rate found -- save it
			MouseParms.bReportInterval = Intervals[i];		//and its corresponding interval
			ResetInterval();								//reset the interval now
			return(PS2_ACK);								//return ACK
		}
	}
	return(PS2_RESEND);										//invalid -- return RESEND
}


/*
**
** FUNCTION: ReadDeviceType		
**
** PURPOSE:	 Returns the device type	
**	
** PARAMETERS: none		
**
** DESCRIPTION:	 
**					
**					
*/

void ReadDeviceType(void)
{
	Ps2Xmt.bMsgBuff[0] = (MouseParms.bZmouse? 3 : 0);		//if we are a z-mouse, return 3, otherwize 0
	Ps2Xmt.bMsgLen = 1;
	Ps2Xmt.bXmtLen = 1;										//send the id	
}


/*
**
** FUNCTION: SetRemoteMode		
**
** PURPOSE:	 Sets mode to remote	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void SetRemoteMode(void)
{
	MouseParms.bStream = 0;						//turn off streaming
}


/*
**
** FUNCTION: ResetWrapMode		
**
** PURPOSE:	 Resets the Wrap mode	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 According to the IBM spec, if stream mode is enabled,
**				 the mouse is disabled when the wrap mode is reset. 
**					
**					
*/

void ResetWrapMode(void)
{
	MouseParms.bWrap = 0;
	if (MouseParms.bStream)						//stream mode enabled,
		MouseParms.bEnabled = 0;				//so disable mouse
}


/*
**
** FUNCTION: SetWrapMode		
**
** PURPOSE:	  Enables the wrap mode	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void SetWrapMode(void)
{
	MouseParms.bWrap = 1;
}


/*
**
** FUNCTION: SetStreamMode 		
**
** PURPOSE:	 Sets stream mode on	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void SetStreamMode(void)
{
	MouseParms.bStream = 1;						//enable stream mode
	ResetInterval();							//reset the interval
}


/*
**
** FUNCTION: ReadData		
**
** PURPOSE:	 Sends a mouse packet in response to a host read_data command	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void ReadData(void)
{
	Mouse.bChange = 1;					//this'll force SendMouseData to actually send a packet
	SendMouseData();					//send the mouse packet
	ResetInterval();					//reset the interval
}


/*
**
** FUNCTION: ApplyResolution		
**
** PURPOSE:	 adjusts the mouse output according to the current resolution setting	
**	
** PARAMETERS:	value -- current mouse count	
**
** DESCRIPTION:	 This routine scales the mouse output by right-shifting the mouse counts
**				 to achieve a /2 for each resolution factor
**					
**					
*/

char ApplyResolution(signed char value)
{
	char i;

#ifdef ENABLE_RESOLUTION
	i = MouseParms.bResolution;
#else
	i = RES_8MM;						//resolution is disabled, force resolution to max
#endif
//	if (i == RES_8MM)					//if at maximum resolution, force counts of +1 and -1 to
										//zero to prevent jitter
//	{
//	    if  ((value < 2) && (value > -2))
//		return(0);
//	}
	i = RES_8MM - i;					//i = number of times to right shift for proper resolution
	while (i--)
		value >>= 1;
	return(value);
}


/*
**
** FUNCTION: ApplyScaling		
**
** PURPOSE:	 adjuststhe mouse output according to the current scale	
**	
** PARAMETERS:	value -- current mouse count	
**
** DESCRIPTION:	 This routine scales the mouse output according to the following
**				  algorithm:
**				  -3 <= N <= 3	: return (N)
**				  N = 4			: return (6)
**				  N = 5:		: return (9)
**				  N >= 6		: return (2*N)
**					
**					
*/

char ApplyScaling(signed char value)
{

#ifdef ENABLE_SCALING
	if (!MouseParms.bScale)						//if 1-1 scaling, return the value
		return(value);

	if ((value <= 3 ) && (value >= -3))			//if between -3 and 3, return the value 
		return(value);
	if (value == 4) return(6);
	if (value == -4) return(-6);
	if (value == 5) return(9);
	if (value == -5)return(-9);
	if (value >= 64)							//if shifting will produce an overflow, return max counts
		return(127);
	if (value <= -64)
		return(-127);
	return(value << 1);
#else
	return(value);

#endif
}


/*
**
** FUNCTION: SendMouseData		
**
** PURPOSE:	 Sends a mouse packet	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 formats a mouse packet according to the IBM spec and sends it to the host
**					
**					
*/

void SendMouseData(void)
{
	char x;
	char y;
	char temp;

	x = ApplyResolution(Mouse.bXcount);		  			//apply scaling and resolution
	y = ApplyResolution(-Mouse.bYcount);										
	x  = ApplyScaling(x);
	y = ApplyScaling(y);
	if (!Mouse.bChange)								   //
	{
													   //look for a reason to send the packet
		Mouse.bChange = (x || y);
		if (MouseParms.bZmouse && Mouse.bZcount)
			Mouse.bChange |= 1;
		if (!Mouse.bChange)
			return;
	}
	temp=Mouse.bButtons & 0x7;							//buttons are properly formatted
	temp |= BIT3;
	if (x & BIT7)										//move sign bits for X and Y
		temp |= BIT4;
	if (y & BIT7)
		temp |= BIT5;
	Ps2Xmt.bMsgBuff[0] = temp;
	Ps2Xmt.bMsgBuff[1] = x;								//include X,Y, and Z info
	Ps2Xmt.bMsgBuff[2] = y;								//Z counts must be negated
	Ps2Xmt.bMsgBuff[3] = -Mouse.bZcount;
	Mouse.bXcount = Mouse.bYcount = Mouse.bZcount = 0;	//clear accumulated counts
	Mouse.bChange = 0;
	if (MouseParms.bZmouse)								//if Z mouse enabled, set length of msg to 4.
		Ps2Xmt.bMsgLen = 4;
	else
		Ps2Xmt.bMsgLen = 3;
	Ps2Xmt.bXmtLen = Ps2Xmt.bMsgLen;					//send the buffer
}


/*
**
** FUNCTION: StatusRequest		
**
** PURPOSE:	 Sends a Status response to the host	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void StatusRequest(void)
{
	char temp=0;
	if (Mouse.bButtons & RIGHT_BUTTON)					//format a status response according to IBM spec
		temp |= BIT0;
	if (Mouse.bButtons & LEFT_BUTTON)
		temp |= BIT2;
	if (MouseParms.bScale == SC_2_1)
		temp |= BIT4;
	if (MouseParms.bEnabled)
		temp |= BIT5;
	if (!MouseParms.bStream)
		temp |= BIT6;
	Ps2Xmt.bMsgBuff[0] = temp;
	Ps2Xmt.bMsgBuff[1] = MouseParms.bResolution;
	Ps2Xmt.bMsgBuff[2] = MouseParms.bReportRate; 
	Ps2Xmt.bMsgLen = 3;
	Ps2Xmt.bXmtLen = Ps2Xmt.bMsgLen;
	return;
}


/*
**
** FUNCTION: SetResolutionAck		
**
** PURPOSE:	 Set Resolution is a two byte command -- the 2nd byte being the resolution itself.
**			 This routine is called after reception of the first byte, and so does nothing
**			 by itself	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void SetResolutionAck(void)
{
}


/*
**
** FUNCTION: SetResolution		
**
** PURPOSE:	 Sets the resolution	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

char SetResolution(char bRes)

{
	switch (bRes)
	{
	case RES_1MM:									//only 4 valid resolutions accepted
	case RES_2MM:
	case RES_4MM:
	case RES_8MM:
		MouseParms.bResolution = bRes;				
		return(PS2_ACK);
	default:
	}
	return(PS2_RESEND);								//
}


/*
**
** FUNCTION: SetScaling		
**
** PURPOSE:	 Sets scaling to 2-to-1	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void SetScaling(void)
{
	MouseParms.bScale = SC_2_1;
}


/*
**
** FUNCTION: ResetScaling		
**
** PURPOSE:	 Sets scaling to 1-to-1	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 
**					
**					
*/

void ResetScaling(void)
{
	MouseParms.bScale = SC_1_1;
}


/*
**
** FUNCTION: CheckZmouse		
**
** PURPOSE:	 Checks to see if proper sequence of commands has been issued
**			 to enable the Z wheel of the mouse.  
**	
** PARAMETERS:	bRate:	
**
** DESCRIPTION:	The Z-wheel is enabled if the 3 following
**				 set-sample rate commands are received:
**				set sample rate 200
**			    set sample rate 100
**				set sample rate 80
**
**				This function is called whenever a set sample rate parameter is received.
**				it maintains a sequence counter which advances each time a rate is received
**				that matches the above sequence.  If the sequence is completed, the
**				z-wheel is enabled.
**					
*/

#define NUM_SET_SAMPLES 3
const char RateSequence[] = {200,100,80};

void CheckZmouse(char bRate)
{
	if (bRate == RateSequence[0])								//any time we get the first rate in the sequence,
		ConsecutiveSetSamples = 0;								//force ourselves to start at the beginning.
	if (bRate == RateSequence[ConsecutiveSetSamples])
	{
																//sequence is valid
		if (++ConsecutiveSetSamples < NUM_SET_SAMPLES)			//advance to next one
			return;
		MouseParms.bZmouse = 1;									//done, enable Zmouse
	}
	ConsecutiveSetSamples = 0;									//reset sequence
}


/*
** define a lookup table of function pointers to standard requests
*/

#pragma memory ORG @ 0xc80
const void (* CommandTable[])(void)= 
{
   ResetScaling,SetScaling,SetResolutionAck,StatusRequest,
   SetStreamMode,SendMouseData,ResetWrapMode,SetWrapMode,
   SetRemoteMode,ReadDeviceType,SetSampleRateAck,Enable,
   Disable,SetDefault,Resend,Reset
 };


/*
**
** FUNCTION: ProcessCommand		
**
** PURPOSE:	 This routine dispatches the received ps/2 command byte to the proper handler	
**	
** PARAMETERS:	bCommand -- command byte received from host
**
** DESCRIPTION:	 ProcessCommand
**					
**					
*/
//define a table of valid commands.  When commands are received, this table will be searched
//for a command match, and the resulting index used to access the proper function to process the command.

const unsigned  char ValidCommands[] =
	{PS2_RESET_SCALING_CMD,PS2_SET_SCALING_2_1_CMD,PS2_SET_RESOLUTION_CMD,	PS2_STATUS_REQUEST_CMD,
	PS2_SET_STREAM_MODE_CMD,PS2_READ_DATA_CMD,PS2_RESET_WRAP_MODE_CMD,PS2_SET_WRAP_MODE_CMD,
	PS2_SET_REMOTE_MODE_CMD,PS2_READ_DEVICE_TYPE_CMD,PS2_SET_SAMPLE_RATE_CMD,PS2_ENABLE_CMD,
	PS2_DISABLE_CMD,PS2_SET_DEFAULT_CMD,PS2_RESEND_CMD,PS2_RESET_CMD};


void ProcessCommand(char bCommand)
{
	char i;
	static char bErrors;
	static char bLastValidCommand;
	
	if (MouseParms.bWrap)								//check for wrap (echo) mode
	{
														//we're in wrap mode.
		bLastValidCommand = 0;							//always clear bLastValidCommand
		if ((bCommand != PS2_RESET_CMD) &&				//these two commands get us out of echo mode
			(bCommand != PS2_RESET_WRAP_MODE_CMD))
		{
			Put(bCommand);								//simply send what we received
			return;
		}
	}


	
	switch (bLastValidCommand)							//otherwise,
	{
	
	case PS2_SET_SAMPLE_RATE_CMD:						//last command byte  was set sample rate, so this must be
		if ((SetSampleRate(bCommand)) == PS2_ACK)		//the rate itself. if the rate is valid,
		{
			Put(PS2_ACK);								//ack it
			bLastValidCommand = 0;						//reset bLastValidCommand
			bErrors = 0;								//clear the error count
			CheckZmouse(bCommand);						//check for z-mouse enabling
			return;										//and return
		}
		break;											

	case PS2_SET_RESOLUTION_CMD:
		if ((SetResolution(bCommand)) == PS2_ACK)		//last command was set resolution, so this must be
		{												//the resolution.  if the resolution was valid,
			Put(PS2_ACK);								//ack it
			bLastValidCommand = 0;						//reset bLastValidCommand
			bErrors = 0;
			return;										//and return
		}
		break;

	default:
		Ps2Xmt.bXmtLen = 0;								//clean out the message buffer now.
														//we want to abort whatever we were sending when
														//receiving a new command.
		if (bCommand != PS2_SET_SAMPLE_RATE_CMD)		//if the command is not set sample rate, reset
			ConsecutiveSetSamples = 0;					//the count of consecutive set sample rate commands received.
														//this is to keep track of commands that enable the
														//wheel of the mouse.

		for (i = 0; i < sizeof(ValidCommands); i++)		//finally, look to see if this command is valid
		{
			if (bCommand == ValidCommands[i])
			{
				Put(PS2_ACK);							//this command is a valid one, so ack it
				bLastValidCommand = bCommand;			//save it
				bErrors = 0;
				(*CommandTable[i])();					//and execute function to process it.
				return;
			}
		}
		break;
	}
														//if we get here, the command was not recognized
	if (++bErrors == 2)									
	{
														//two errors in a row! return error
		Put(PS2_ERROR);
		bErrors = 0;
		bLastValidCommand = 0;
		return;
	}
														//one error, return a resend.
	Put(PS2_RESEND);
	return;
}


/*
**
** FUNCTION: ps2_send, ps2_receive		
**
** PURPOSE:	to clock bytes to/from the host using ps2 clocking specifications	
**	
** PARAMETERS:		
**
** DESCRIPTION:	 These routines are written in assembler to precisely control the number of
**				execution cycles required for the appropriate ps2 timing.
**					
**					
*/

#asm
 EXPAND
 OPT
XMT_CLK_LOW_TIME:           equ 35				;these are usec delays, which in addition to the delays
XMT_CLK_HIGH_TIME:          equ 11				;associated with code execution, are used to achieve
RCV_CLK_LOW_TIME:           equ 35				;ps/2 clock low and high times of between 30-50 usec.
RCV_CLK_HIGH_TIME:          equ 21				;These delays must include "room" for the occurrence
												;of the 128 usec interrupt which can extend the
												;execution time of the loops by the execution time of the
												;interrupt itself.
 
;ps2 clock, data bits are D+ and D-
;ps2 clock, data bits are D+ and D-


DPH_DMH:                     equ     7
DPH_DML:                     equ     5
DPL_DMH:                     equ     6
DPL_DML:                     equ     4


CLKH_DATAH:                  equ     DPH_DMH
CLKL_DATAH:                  equ     DPL_DMH
CLKH_DATAL:                  equ     DPH_DML
CLKL_DATAL:                  equ     DPL_DML



;this entry is for C callers.  The push isn't necessary but for the pop at the end of
;the delay routine (It also makes the delays equal)
Delay:
    push A
delay:
	;we got here with a fixed delay caused by the  push A,mov, A, and
	;call, equal to 10+8+5 = 23 cycles.  At the end of the routine we
	;incur another 8+5 due to the  pop and return. This gives 36 cycles
    ;of delay, or  3 us.   
    mov [ksc_delay],A  

    ;now eat up the rest of the us in this loop.

XPAGEOFF
loop:						;1us per revolution through this loop
	dec	[ksc_delay]
	jnz	loop
XPAGEON
	  pop A
      ret

;
;the following state table defines the next state for the clock-data pair
;to clock out a given bit.  This table is used  when D+ and D- are used to drive
;the ps2 clock and data lines 
;
XPAGEOFF
drive_table:
        db          0,0,0,0,CLKH_DATAL,CLKL_DATAL,CLKH_DATAH,CLKL_DATAH
XPAGEON

ps2_send:
    push    A                                   ;save our data byte                    
    push    X                                   ;save X register

    mov     X,A                                 ;save data byte momentarily in X
                  
    DELAY   50                                  ;delay a bit time between bytes
 
?l1:                                            ;some PC's.
    call    send_0                              ;clock out start bit

	jnc		?send_start_bit_success

	; if we are being inhibited and the host is not
	; requesting to send, then continue to try to 
	; send the start bit

?send_inhibit_wait:
	iowr	WATCHDOG							; reset the watchdog
	READ_PS2_CLOCK_DATA							; read the PS/2 bits
	and		A, (PS2_CLOCK_BIT | PS2_DATA_BIT)	; if CLK=low (inhibit) and DATA=high
	cmp		A, PS2_DATA_BIT						; then wait until host releases clock
	jz		?send_inhibit_wait
	cmp		A, PS2_CLOCK_BIT					; if host is requesting to send, then
	jz		?error								; quit with error

	jmp		?l1									; else try to send start bit again

?send_start_bit_success:
    mov     A,1
    mov     [ps2_temp0],A                       ;keep track of parity
    mov     A,X                                 ;get back our data byte
    mov     X,8                                 ;count 8 bits
?l2:
    asr     A                                   ;shift bit to send into carry
    jc      ?one                                ;if carry is zero
    call    send_0                              ;send a zero
    jc      ?error                               ;problem, quit now
    jmp     ?next                               ;
?one:                                           ;else
    call    send_1                              ;  send a 1
    jc      ?error                               ;  problem, quit now
    inc     [ps2_temp0]                         ;  keep track of parity
?next:                                          ;
    dec     X                                   ;decrement counter
    jz      ?parity                             ;if at zero do parity
    jnc     ?l2                                 ;if -1, exit

?stopbit:
    call    send_1                              ;clock out stop bit  
    CLEARC
    or A,0
    jmp     ?exit

?parity:
    mov     A,[ps2_temp0]                      ;now send parity too
    jmp     ?l2
?exit:
    WRITE_PS2_CLOCK_DATA CLKH_DATAH
     	jmp	?exit1

?error:
 
    WRITE_PS2_CLOCK_DATA CLKH_DATAH
    SETC  
?exit1:
    pop     X
    pop A
    ret                                        ;return

 
;========================================================================
; FUNCTION: send_0,send_1
;
; Sends bit out the ps2 port
;
;
; Returns: 
;   C= 0 if transmission was successful
;   C= 1 if not
;
;========================================================================


send_1:
    push    A
    mov     A,CLKH_DATAH                        ;start with clock high, data high
    jmp     clock
send_0:
    push    A
    mov     A,CLKH_DATAL                        ;start with clock high, data low

clock:
    push    A
    
    READ_PS2_CLOCK_DATA
    and     A,PS2_CLOCK_BIT            
    pop     A    
    jnz     l2
    SETC
    pop     A                                          ;should be high
    ret
l2:   
    WRITE_ACC_PS2_CLOCK_DATA
    DELAY    5 
    ASSERT_PS2_CLOCK
   DELAY    XMT_CLK_LOW_TIME                       ;delay as per spec
    DEASSERT_PS2_CLOCK
   DELAY    XMT_CLK_HIGH_TIME                      ;wait as per spec
   CLEARC
    pop    A
    ret


;========================================================================
; FUNCTION: getbit
;
; Receives  a bit
;
;
; Returns: 
;   C = state of bit clocked in
;
;========================================================================
getbit:
    push    A                               ;push A
    READ_PS2_CLOCK_DATA
    and     A,PS2_CLOCK_BIT
    jz      ?error
    WRITE_PS2_CLOCK_DATA CLKL_DATAH
    DELAY    RCV_CLK_LOW_TIME 
    WRITE_PS2_CLOCK_DATA CLKH_DATAH         ;wait 35 usec
    DELAY    15                             ;wait 5 usec 
    READ_PS2_CLOCK_DATA
    DELAY    11
    										;XMT_CLK_HIGH_TIME              ;wait 
    and     A,  PS2_DATA_BIT                ;mask off all but data bit
    jz      ?low                            ;if data bit high,
    SETC                                    ;set the carry
?low:
    pop     A                               ;pop acc and rotate carry into msb
    rrc     A
    CLEARC                                  ;clear carry indicating success
    ret                                     ;return
?error:
    pop     A
    SETC
    ret
    


;========================================================================
; FUNCTION: ps2_receive
;
; Receives a byte 
;
;
; Returns: 
;   C= 0 if reception was successful
;   C= 1 if not
;
;========================================================================



ps2_receive:
    push    X                                   ;save X, we'll wipe it out

    mov     X,18                                ;do the following 18 times:
?wait:                                          ;
    DELAY   7                                   ;kill time for 7 us
    READ_PS2_CLOCK_DATA
    and     A,PS2_DATA_BIT                      ;make sure data bit low
    jnz      ?exitearly                         ;out now if not
    dec     X                                   ;wait again
    jnz     ?wait                               ;
                                                ;above loop consumes approx 180 us.

?start:
    

    DELAY    5                                  ;wait prior to anything
    mov     X,8                                 ;count 9 bits (8 data, 1 parity)
    mov     A,0                                 ;clear parity count
    mov     [ps2_temp0],A

?l1:
    call    getbit
    jc      ?inhibit                            ;if not inhibiting
    cmp     A,80h                               ;see if msbit = 1
    jc      ?next                               ;yup,
    inc     [ps2_temp0]                         ;increment parity count
?next:
    dec     X                                   ;decrement counter
    jc      ?done                               ;if at -1, done    
    jnz     ?l1    
    push    A                                   ;else save partial result
    jmp     ?l1

?inhibit:                                       ;we were inhibited in
    dec     X                                   ;the middle of getting stuff,
    jc     ?done                               ;adjust stack appropriately
    push    A
?done:
    
    ;arrive here with data byte on the stack and the received parity bit in the msb
    ;of the accumulator. the calculated parity bit is in the lsb of ps2_temp0.
    ;if we arrived here due to host inhibit, both parity and data byte are
    ;garbage but that's ok -- we'll abort out of this routine anyway.
    mov     A,[ps2_temp0]                        ;
    and     A,1
    mov     X,A
                                                 ;X should be 1 if ok

    call    getbit                               ;get stop bit
    jc     ?error                                ;if no problem getting it
    rlc     a                           
    jc     ?ack                                 ;if it's not a 1
    mov     X,0                                  ;X= 0 indicates an error

?badstop:                                       ;
    call    getbit                              ;keep looking for it
    jc      ?error
    rlc     a
    jnc    ?badstop

?ack:
                                                ;arrive here with x = 0 if no errors
    call    send_0                              ;send a 0 to ack the transaction
    mov     A,X
    cmp     A,0
    jz     ?error1


?exit:
    WRITE_PS2_CLOCK_DATA CLKH_DATAH
	jmp	?exit1

?error1:
    WRITE_PS2_CLOCK_DATA CLKH_DATAH
	SETC                                         ;set carry indicating a problem
?exit1:
    pop     A                                    ;pop result into ACC  
    pop     X                                    ;restore X
    ret
 ?exitearly:
    SETC
    pop     X
    ret
#endasm


