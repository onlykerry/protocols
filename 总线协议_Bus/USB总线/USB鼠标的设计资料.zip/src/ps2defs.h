

/*
** ps2 commands
*/


#define PS2_RESET_CMD				0xff
#define PS2_RESEND_CMD				0xfe
#define PS2_SET_DEFAULT_CMD			0xf6
#define PS2_DISABLE_CMD				0xf5
#define PS2_ENABLE_CMD				0xf4
#define PS2_SET_SAMPLE_RATE_CMD		0xf3
#define PS2_READ_DEVICE_TYPE_CMD	0xf2
#define PS2_SET_REMOTE_MODE_CMD		0xf0
#define PS2_SET_WRAP_MODE_CMD		0xee
#define PS2_RESET_WRAP_MODE_CMD		0xec
#define PS2_READ_DATA_CMD			0xeb
#define PS2_SET_STREAM_MODE_CMD		0xea
#define PS2_STATUS_REQUEST_CMD		0xe9
#define PS2_SET_RESOLUTION_CMD		0xe8
#define PS2_SET_SCALING_2_1_CMD		0xe7
#define PS2_RESET_SCALING_CMD		0xe6




#define PS2_CLOCK_BIT				(1 << 5)			//clock bit can be read as bit 5 of port 2
#define PS2_DATA_BIT				(1 << 4)			//data bit can be read as bit 4 of port 2


#define SC_1_1						0					//scaling constants 
#define SC_2_1						1			
#define RES_1MM						0					//resolution constants
#define RES_2MM						1
#define RES_4MM						2
#define RES_8MM						3
#define PS2_RESEND					0xFE				//misc. responses to host
#define PS2_ACK						0xFA
#define PS2_ERROR					0xFC
#define RIGHT_BUTTON				1					//button positions
#define LEFT_BUTTON					2
#define MIDDLE_BUTTON				4




#define HOST_RTS ((PORT2 & (PS2_CLOCK_BIT | PS2_DATA_BIT)) == PS2_CLOCK_BIT)
#define HOST_INHIBIT (!(PORT2 & PS2_CLOCK_BIT))
