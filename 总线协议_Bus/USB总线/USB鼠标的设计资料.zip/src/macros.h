#asm

;define special macros for manipulating PS2 clock and data.
;


    MACRO READ_PS2_CLOCK_DATA
    iord    PORT2    
    ENDM

    MACRO WRITE_PS2_CLOCK_DATA VALUE
    mov     A,(VALUE | a0h) 
    iowr    USB_STATUS
    ENDM
    MACRO WRITE_ACC_PS2_CLOCK_DATA 
    or    A,a0h
    iowr    USB_STATUS
    and    A,07h
    ENDM

    MACRO   ASSERT_PS2_CLOCK 
    index   drive_table                  
    or      A,a0h       
    iowr    USB_STATUS              
    and    A,07h
    ENDM
 
    MACRO   DEASSERT_PS2_CLOCK 
    index   drive_table
    or      A,a0h
    iowr    USB_STATUS
    and     A,07h              
    ENDM

 
 
    ;delay macro is the front-end for a call to the delay subroutine
    ;The fixed overhead of the macro plus the subroutine is 3 us,
    ;so this technique is good for delays of 4us or greater.
    ;

    MACRO DELAY US
    push    A
    mov     A, (US-3)
    call    delay
    ENDM
;

    ;clear carry
    MACRO CLEARC 
    or    A,0
    ENDM

    MACRO SETC 
    cpl 
    cpl
    ENDM
    
    
   ;set carry
    MACRO CARRY
    push    A
    mov     A, (US-3)
    call    delay
     ENDM

#endasm

