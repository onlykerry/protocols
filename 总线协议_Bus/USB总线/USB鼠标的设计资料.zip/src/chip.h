/***

HEADER FOR CYPRESS 637XX 

***/

#ifndef __CYC_H
#define __CYC_H

#pragma has BCPU;

registera  AC;
registerx  IX;
registercc CC; /* CC.Z : Zero Flag, CC.C : Carry Flag */

#define ENDPOINT_A2_FIFO_SIZE  0x08
#define ENDPOINT_A2_ADDRESS    0xE8
unsigned char ENDPOINT_A2_FIFO[ENDPOINT_A2_FIFO_SIZE] @  ENDPOINT_A2_ADDRESS;
#define ENDPOINT_A1_FIFO_SIZE  0x08
#define ENDPOINT_A1_ADDRESS    0xF0
unsigned char ENDPOINT_A1_FIFO[ENDPOINT_A1_FIFO_SIZE] @  ENDPOINT_A1_ADDRESS;
#define ENDPOINT_A0_FIFO_SIZE  0x08
#define ENDPOINT_A0_ADDRESS    0xF8
unsigned char ENDPOINT_A0_FIFO[ENDPOINT_A0_FIFO_SIZE] @  ENDPOINT_A0_ADDRESS;
#define USB_FIFO_SIZE           0x18


#define RAM_SIZE                0x100 /* 0x00 - 0xff */
#define RAM_START               0x00
#ifndef STACK_SIZE
#define STACK_SIZE              0x30
#endif /* STACK_SIZE */

#define STACK_START             RAM_START
#define REGISTER_START          RAM_START+STACK_SIZE
#define REGISTER_SIZE           RAM_SIZE-USB_FIFO_SIZE-STACK_SIZE
#define SPAD_SIZE               4

#pragma memory RAM [REGISTER_SIZE] @ REGISTER_START;

#ifndef NOLOCAL
#pragma memory LOCAL[0] @ REGISTER_START+REGISTER_SIZE-SPAD_SIZE;
#endif /* NOLOCAL */

#pragma memory STACK[ STACK_SIZE +1 ] @ RAM_START;

#define ROM_SIZE     0x1800 					/* 6K bytes */
#define ROM_START    0x0020 					/* after interrupt vectors */
#define ROM_RESERVED 32
#pragma memory ROM[ROM_SIZE-ROM_RESERVED-ROM_START] @ ROM_START;

#define USB_bmRequestType  0
#define USB_bRequest       1
#define USB_wValue         2
#define USB_wValueHi       3
#define USB_wIndex         4
#define USB_wIndexHi       5
#define USB_wLength        6
#define USB_wLengthHi      7

#pragma vector MY_RESET_ISR			@ 0x0000; 	/* reset vector 			*/
#pragma vector USB_BUS_RESET_ISR	@ 0x0002; 	/* usb reset isr			*/
#pragma vector MICROSECONDx128_ISR	@ 0x0004; 	/* 128us interrupt 			*/
#pragma vector MILLISECOND_ISR		@ 0x0006; 	/* 1.024ms interrupt 		*/
#pragma vector USB_A_EP0_ISR		@ 0x0008; 	/* endpoint 0 interrupt 	*/
#pragma vector USB_A_EP1_ISR		@ 0x000A; 	/* endpoint 1 interrupt 	*/
#pragma vector USB_A_EP2_ISR		@ 0x000C; 	/* endpoint 2 interrupt 	*/
#pragma vector USB_SPI_ISR			@ 0x000E; 	/* spi interrupt 			*/
#pragma vector USB_CAPA_ISR			@ 0x0010; 	/* capture timer a interrupt*/
#pragma vector USB_CAPB_ISR			@ 0x0012; 	/* capture timer b interrupt*/
#pragma vector GPIO_ISR				@ 0x0014; 	/* GPIO interrupt 			*/
#pragma vector WAKEUP_ISR			@ 0x0016; 	/* wakeup timer interrupt 	*/

#pragma portrw PROCESSOR_STATUS  @ 0xff; 		/* processor status and control */
#define IRQ_PENDING    7
#define WATCHDOG_RESET 6
#define USB_RESET      5
#define POWERON_RESET  4
#define SUSPEND        3
#define INTERRUPT_MASK 2
#define SINGLE_STEP    1
#define RUN            0

#pragma portrw CLOCK_CONFIGURATION @0xf8;
#define PRECISION_USB_CLOCKING (1 << 2)
#define TWAKEUP_MASK (7 << 4)
#define TWAKEUP_2   (1 << 4)
#define TWAKEUP_64 ( 6 << 4)
#define TWAKEUP_MAX (7 << 4)
#define TWAKEUP_MIN  0
#pragma portrw PORT0 @ 0x00; 					/*  GPIO data port 0 */
#pragma portrw PORT1 @ 0x01; 					/*  GPIO data port 1 */
#pragma portrw PORT2 @ 0x02; 					/* aux port*/
#pragma portw PORT0IE @ 0x04; 					/* Interrupt enable for Port 0 */
#pragma portw PORT1IE @ 0x05; 					/* Interrupt enable for Port 1 */
#pragma portw PORT0IP @ 0x06; 					/* Interrupt polarity for Port 0 */
#pragma portw PORT1IP @ 0x07; 					/* Interrupt polarity for Port 1 */

#pragma portrw PORT0_MODE0 @ 0x0A;
#pragma portrw PORT0_MODE1 @ 0x0B;

#pragma portrw PORT1_MODE0 @ 0x0C;
#pragma portrw PORT1_MODE1 @ 0x0D;





#pragma portrw USB_DEVICE_A   @ 0x10; 			/* USB device address 		*/ 
#pragma portrw EP_A0_COUNTER  @ 0x11; 			/* endpoint 0 counter 		*/
#pragma portrw EP_A0_MODE     @ 0x12; 			/* endpoint 0 configuration */
#pragma portrw EP_A1_COUNTER  @ 0x13; 			/* endpoint 1 counter 		*/
#pragma portrw EP_A1_MODE     @ 0x14; 			/* endpoint 1 configuration */
#pragma portrw EP_A2_COUNTER  @ 0x15; 			/* endpoint 2 counter 		*/
#pragma portrw EP_A2_MODE     @ 0x16; 			/* endpoint 2 configuration */

#define DEVICE_ADDRESS_ENABLE 7 				/* bit 7 of USB_DEVICE*/

#define SETUP_RECEIVED 7
#define IN_RECEIVED    6
#define OUT_RECEIVED   5
#define ACKNOWLEDGE    4
#define USB_MODE_DISABLE           0b0000
#define USB_MODE_NAK_IN_OUT        0b0001 
#define USB_MODE_STATUS_OUT        0b0010
#define USB_MODE_STALL_IN_OUT      0b0011
#define USB_MODE_IGNORE_IN_OUT     0b0100
#define USB_MODE_ISOCHRONOUS_OUT   0b0101
#define USB_MODE_STATUS_ONLY       0b0110
#define USB_MODE_ISOCHRONOUS_IN    0b0111 
#define USB_MODE_NAK_OUT           0b1000
#define USB_MODE_ACK_OUT           0b1001
#define USB_MODE_NAK_OUT_STATUS_IN 0b1010
#define USB_MODE_ACK_OUT_STATUS_IN 0b1011
#define USB_MODE_NAK_IN            0b1100
#define USB_MODE_ACK_IN            0b1101
#define USB_MODE_NAK_IN_STATUS_OUT 0b1110
#define USB_MODE_ACK_IN_STATUS_OUT 0b1111
#define USB_MODE_MASK              0b1111

#pragma portrw GLOBAL_INTERRUPT @ 0x20; 		/* Global interrupt enable */
#define DISABLE_INTERRUPTS		0b00000000
#define WAKEUP_ENABLE			0b10000000
#define GPIO_ENABLE				0b01000000
#define I2C_ENABLE				0b00001000
#define MILLISECOND_ENABLE		0b00000100
#define MICROSECOND_ENABLE		0b00000010
#define USB_BUS_RESET_ENABLE	0b00000001

#pragma portrw ENDPOINT_INTERRUPT @ 0x21; 		/* USB endpoint interrupt enable */
#define EPA2_ENABLE 0b00100
#define EPA1_ENABLE 0b00010
#define EPA0_ENABLE 0b00001

#pragma portr  TIMER @ 0x24; 					/* lower eight bits of timer */
#pragma portr  TIMER_LSB @ 0x24; 				/* lower eight bits of timer */
#pragma portr  TIMER_MSB @ 0x25; 				/* upper six bits of timer */

#pragma portrw WATCHDOG @ 0x26; 				/* watchdog timer */




#pragma portrw USB_STATUS @ 0x1F; 				/*  USB upstream status and control */
#define VREG_ENABLE_MASK (1 << 6)
#define PS2_PULLUP_MASK (1 << 7)
#define PS2_INTERRUPT_MODE_MASK (1 << 5)
#define BUS_ACTIVITY_MASK (1 << 3)
#define BUS_ACTIVITY 3
#define NOT_FORCING             0b000
#define FORCE_K                 0b001
#define FORCE_J                 0b010
#define FORCE_SE0               0b011
#define FORCE_NEG_LOW_POS_OPEN  0b101
#define FORCE_NEG_OPEN_POS_LOW  0b110
#define FORCE_NEG_OPEN_POS_OPEN 0b111

#define PUSHA() #asm( push a )
#define PUSHX() #asm( push x )
    
#define POPA() #asm( pop a )
#define POPX() #asm( pop x )
#define SWAP(A,DEST) #asm( swap A,DEST)

#define RLC() #asm( rlc)
#define RRC() #asm( rrc)
#define ASL() #asm( asl a)
#define ASR() #asm( asr a)
#define HALT() #asm( halt);
#define RESET_COP() WATCHDOG=AC

//make some handy defines to augment those supplied by ByteCraft in chip.h

#define ADDRESS_ENABLE_BIT			0x80
#define ACK_RECEIVED_MASK			(1 << ACKNOWLEDGE)
#define SETUP_RECEIVED_MASK			(1 << SETUP_RECEIVED)
#define IN_RECEIVED_MASK			(1 << IN_RECEIVED)
#define OUT_RECEIVED_MASK			(1 << OUT_RECEIVED)
#define DATATOGGLE 0x80

#define WATCHDOG_RESET_MASK			(1 << WATCHDOG_RESET)
#define USB_BUS_RESET_MASK			(1 << USB_RESET)
#define POWER_ON_RESET_MASK			(1 << POWERON_RESET)
#define BUS_RESET_ENABLE			1
#define DATAVALID					0x40
#define COUNT_MASK					0x0F
#define DATATOGGLE					0x80

#define __BIG_ENDIAN 				/* most significant byte is stored in small address */

#endif /* __CYC_H */
