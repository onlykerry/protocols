*** Cypress CY7C63723 Encore C-Combi Mouse Reference Design Readme ***

This design package includes reference materials for creating a
USB - PS/2 combination mouse that auto-detects the interface and
configures itself to operate on the appropriate bus.

Documentation

docs - Designing a low cost CY7C63723 combination mouse.pdf - application note for this design
	 - schematic.pdf - mouse schematic

Firmware Source Files

src - chip.c - include file that defines CY7C63723 constants
	- combi.c - main source file
	- combi.hex - Intel hex file for programming a CY7C63723 microcontroller
	- combi.lst - output listing from c-compiler for use with the CYDB debugger
	- macros.h - defines macros used in combi.c
	- ps2defs.h - defines PS/2 interface constants
	- usb_desc.h - defines the USB descriptors
	- usbdefs.h - defines USB interface constants