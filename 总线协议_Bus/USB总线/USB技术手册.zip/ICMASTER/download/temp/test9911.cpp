///////////////////////////////////////////////////////////////
// HW9911 evaluation board software Rev. 1.0
// program by Liu Ding, Bei Jing HEAD Elec.
// this is the main program for the HW9911 USB device evaluation board
// it illustrate the basical read/write process of HW9911
// by three examples:
// 1. write datas to ram on the evaluation board
// 2. read the datas from the ram on the board
// 3. send datas through RS-232 serial prot on the board
// 
// the whole project are build with MSVC 6.0
// and tested on windows 98 platform.
//
// notes: you can use hyper terminal to reaceive datas form RS232 port
//
// this software are designed by Liu Ding
// if you meet any problems, pls contact by email:
// hugehard@263.net
// or contact HEAD Co. by Tel 86-10-87312497
// or by fax: 86-10-87312495
///////////////////////////////////////////////////////////////

#include "hwdll.h"
#include "stdafx.h"
#include <stdio.h>
#include <windows.h>
#include <memory.h>
#include <DEVIOCTL.H>
#include <stdlib.h>
#include <conio.h>
#include "hw9911.h"
#include "test9911.h"


int main()
{
	int hOpen=FALSE;
	int hCommandLength=32;
	int hDataLength=64;
	int i,VertAddr=0,HorAddr=0;
	int addr,TotalLen;
	USC StAddrH=0,StAddrL=0;
	USC DataLenH,DataLenL;
	USC *hDataBuffer,*hCommandBuffer;
	USC ch1=0x61;
	HANDLE hDeviceHandle;
	
	printf("************************************************\n");
	printf("*******HW9911 USB DEVELOPMENT BOARD*************\n");
	printf("************************************************\n\n");
	printf("now press any key to open board\n");
	getch();

/********* call hDeviceOpen in hwdll.dll to open the board***/
//hOpenDevice ˵��:
// BOOL hOpenDevice(HANDLE *DeviceHandle)
// ���ã����豸
// ����˵����
// DeviceHandle���豸���
// ����ֵ��
// �豸�򿪳ɹ����� TRUE��ʧ���򷵻�FALSE
	if( (hOpen = hOpenDevice( &hDeviceHandle ))==FALSE)
	{
		printf("can't open device\n");
		printf("press any key to exit\n");
		getch();
		return 0;
	}
	else 
		printf("\nCongratulations! device opened!\n\n");

/******  build and send command **********/
	printf("how many bytes do you want to access?");
	scanf("%x",&TotalLen);
	while(TotalLen > 0x7fff)
	{
		printf("pls input a hex data less than 08000\n");
		scanf("%x",&TotalLen);
	}
	DataLenH=(USC)(TotalLen/0x100);		//data length high bytes
	DataLenL=(USC)(TotalLen%0x100);		//data length low bytes

	printf("************************************************\n");
	printf("now program will write datas to ram on board\n");
	printf("total bytes of datas is %x\n",TotalLen);
	printf("press any key to continue\n\n");
	getch();
/*****************************************************************
      now will build a write command packet    
        with the first byte is 'w'.
		and the following bytes are:
		start ram address byte high, start ram address byte low,
		datalength byte high, data length byte low.
		this packet will send to device through WritePipe1,
		which is endpoint 2 of HW9911.
		when the device receive this command packet,
		it will write TotalLen bytes data to Ram on the board
******************************************************************/


	hCommandBuffer=(USC *)malloc(hCommandLength);
	hDataBuffer=(USC *)malloc(hDataLength);
	hCommandBuffer[0] = 'w';	//read command
	hCommandBuffer[1] = StAddrH;	
	hCommandBuffer[2] = StAddrL;	
	hCommandBuffer[3] = DataLenH;
	hCommandBuffer[4] = DataLenL;	

/* call hUSBIO() in hwdll.dll to send command packet to device*/
// hUSBIO ˵��:
// BOOL hOpenDevice(HANDLE *DeviceHandle,
//					unsigned char *IOBuffer,
//					int BufferLength,
//					int PipeNumber,
//					int Action)
// ���ã��豸��д
// ����˵����
// DeviceHandle���豸���
// IOBuffer: ָ��Ҫ���͵�����ָ��
// BufferLength: ���ݰ�����
// ���ڷ��ͻ���1��2�ͽ��ջ���1��2��BufferLength����С�ڻ����32
// ���ڷ��ͻ���3�ͽ��ջ���3��BufferLength����С�ڻ����64
// PipeNumber: ͨ����
//		���ͻ���1��PipeNumber=0;
//		���ջ���1��PipeNumber=1;
//		���ͻ���3��PipeNumber=2;
//		���ջ���3��PipeNumber=3;
// Action: ��д��־��TRUE�������豸�����ݵ�����
//					 FALSE�����������������ݵ��豸		
//		�������ջ��棬Action����ΪFALSE
//		�������ͻ��棬Action����ΪTRUE
// ����ֵ��
// �����ɹ�����TRUE��ʧ�ܷ���FALSE

	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			hCommandLength,
			hWritePipe1,
			FALSE) == TRUE)
	{
		printf("command 'w' writed to board\n");
		printf("now press any key to write datas to ram\n");
		getch();
	}
	else
		printf("data can't write to device\n");

/******** write ram data to board **********/

	printf("      ");
	for(VertAddr=0;VertAddr<=0xf;VertAddr++)
		printf("%02x ",VertAddr);
		printf("\n");
	addr=0;
	while (addr<TotalLen)
	{
		if (addr+hDataLength > TotalLen)
			hDataLength = TotalLen-addr;
		for(i=0;i<hDataLength;i++)
		{
			hDataBuffer[i]=ch1++;
			if (ch1 > 0x80) 
				ch1 = 0x61;
		}
/* call hUSBIO to write datas to write pipe3, which
   is endoint 6 of HW9911*/

		if (	hUSBIO(	&hDeviceHandle,
				hDataBuffer,
				hDataLength,
				hWritePipe3,	
				FALSE) == TRUE)		//FALSE means Write operate
		{
			for(i=0;i<hDataLength;i++)
			{
/* print format control   */		
				if(i % 16 == 0) 
				{
					printf("\n%04x ",HorAddr);
					HorAddr=HorAddr+16;
				}
				printf("%02x ",(USC)hDataBuffer[i]);
			}
			addr=addr+hDataLength;
		}
		else
		{
			printf("can't write to board\n");
			exit(0);
		}
	}
	printf("\n\nTotal%x bytes write to ram OK\n\n",TotalLen);


/*****************************************************************
      now will build a read command packet    
        with the first byte is 'R'.
		and the following bytes are:
		start ram address byte high, start ram address byte low,
		datalength byte high, data length byte low.
		this packet will send to device through WritePipe1,
		which is endpoint 2 of HW9911.
		when the device receive this command packet,
		it will read TotalLen bytes data from Ram on the board
******************************************************************/

	printf("************************************************\n");
	printf("now program will read datas from ram on board\n");
	printf("total bytes of datas is %x\n",TotalLen);
	printf("press any key to continue\n\n");
	getch();
	hDataLength=64;
	hCommandBuffer[0] = 'r';	//read command
	hCommandBuffer[1] = StAddrH;	
	hCommandBuffer[2] = StAddrL;	
	hCommandBuffer[3] = DataLenH;
	hCommandBuffer[4] = DataLenL;	
/*  call hUSBIO to send packet   */
	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			hCommandLength,
			hWritePipe1,
			FALSE) == TRUE)
	{
		printf("command 'r' writed to board\n");
		printf("now press any key to read datas from ram\n\n");
		getch();
	}
	else
		printf("data can't write to device\n");

/******** read ram data form board **********/
	printf("      ");
	for(VertAddr=0;VertAddr<=0xf;VertAddr++)
		printf("%02x ",VertAddr);
		printf("\n");
	addr=0;
	HorAddr=0;
	while (addr<TotalLen)
	{
		if (addr+hDataLength > TotalLen)
			hDataLength = TotalLen-addr;
/* call hUSBIO to read datas from board  */
		if (	hUSBIO(	&hDeviceHandle,
				hDataBuffer,
				hDataLength,
				hReadPipe3,
				TRUE) == TRUE)			//TRUE means Read Operate
		{
			for(i=0;i<hDataLength;i++)
			{
/*   print format control   */
				if(i % 16 == 0) 
				{
					printf("\n%04x ",HorAddr);
					HorAddr=HorAddr+16;
				}
				printf("%02x ",(USC)hDataBuffer[i]);
			}
			addr=addr+hDataLength;
		}
		else
		{
			printf("can't read from board\n");
			exit(0);
		}
	}
	printf("\n\n");
	printf("%x bytes read from ram OK\n\n",TotalLen);

/*****************************************************/
/*      process rs232 test                           */
/*     the first byte in this packet is command 's'  */
/*     and the following 2 bytes are used to set     */
/*     the baud rate of 8051						 */
/*     they will be write to TH1 and TL1 respectively*/
/*     the following bytes are datas will be         */
/*     send through RS232 serial poart				 */
/*****************************************************/
	printf("\npress any key to process RS232 Test\n");
	getch();
	
	USC TH1,TL1;
	char hStr[30];
	TH1=(USC)(BD9600/0x100);
	TL1=(USC)(BD9600%0x100);
	hCommandBuffer[0] = 's';	//read command
	hCommandBuffer[1] = TH1;	
	hCommandBuffer[2] = TL1;	//start address is 0x0000

	strcpy(hStr, "Hi, dear HW9911 consumers! ");
	printf("Hi, dear HW9911 consumers! ");
	memcpy(&(hCommandBuffer[3]),hStr,27);

	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			30,
			hWritePipe1,
			FALSE) == FALSE)
	{
			printf("can't write datas to RS232\n");
			exit(0);
	}

	strcpy(hStr, "I'm HW9911 Evaluation Board, ");
	printf("I'm HW9911 Evaluation Board, ");
	memcpy(&(hCommandBuffer[3]),hStr,29);
	
	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			32,
			hWritePipe1,
			FALSE) == FALSE)
	{
			printf("can't write datas to RS232\n");
			exit(0);
	}

	strcpy(hStr, "thanks for purchasing me, ");
	printf("thanks for purchasing me, ");
	memcpy(&(hCommandBuffer[3]),hStr,26);
	
	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			29,
			hWritePipe1,
			FALSE) == FALSE)
	{
			printf("can't write datas to RS232\n");
			exit(0);
	}
	
	strcpy(hStr, "If you meet some problems, ");
	printf(hStr, "If you meet some problems, ");
	memcpy(&(hCommandBuffer[3]),hStr,27);
	
	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			30,
			hWritePipe1,
			FALSE) == FALSE)
	{
			printf("can't write datas to RS232\n");
			exit(0);
	}

	strcpy(hStr, "pls contact my designer ");
	printf("pls contact my designer ");
	memcpy(&(hCommandBuffer[3]),hStr,24);
	
	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			27,
			hWritePipe1,
			FALSE) == FALSE)
	{
			printf("can't write datas to RS232\n");
			exit(0);
	}

	strcpy(hStr, "by email: hugehard@263.net.");
	printf("by email: hugehard@263.net.\n");
	memcpy(&(hCommandBuffer[3]),hStr,27);
	
	if (	hUSBIO(	&hDeviceHandle,
			hCommandBuffer,
			30,
			hWritePipe1,
			FALSE) == FALSE)
	{
			printf("can't write datas to RS232\n");
			exit(0);
	}
/********* call hDeviceOpen in hwdll.dll to open the board***/
// hCloseDevice ˵��:
// BOOL hCloseDevice(HANDLE *DeviceHandle)
// ���ã��ر��豸
// ����˵����
// DeviceHandle���豸���
// ����ֵ��
// �豸�رճɹ����� TRUE��ʧ���򷵻�FALSE
	if( (hOpen = hCloseDevice( &hDeviceHandle ))==FALSE)
	{
		printf("can't open device\n");
		printf("press any key to exit\n");
		getch();
		return 0;
	}
	else 
		printf("device closed\n");

	printf("press any key to exit the program\n");
	free(hDataBuffer);
	free(hCommandBuffer);
	getch();
	return 0;
}
