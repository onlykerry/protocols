/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 2001				*
 *									*
 *	File name: Display_1263.c					*
 *	  This is TCM-A1263 module display functions program.		*
 *									*
 *									*
 *	Revision history						*
 *		2001-Jun-5 		Catherine Ni	Start.		*
 *    									*
 ************************************************************************/

/*----------------------------------------------------------------------------------------
This program define TCM-A1263:

	Text & Graphic mode:
	Total pages:		160 	(   page 0: up side 	to     page 159:    down side)
	Columns in each page:	120	( Column 0: left side 	to  Column 119: right side)
	Bits in each column:	8 bits 	(   R:D7~D5    G: D4~D2     B: D1~D0    )
	Dot Matrix mode:
	Total resolution:
	X:	120 dots;	Y:	160 dots
	 (0,0) left-up corner to (119,159) right-down corner
-----------------------------------------------------------------------------------------*/

#include "include\common.h"
#include "include\io.h"
#include "include\bcu.h"
#include "include\int.h"
#include "include\8timer.h"
#include "include\16timer.h"
#include "include\ad.h"
#include "include\osc.h"
#include "include\presc.h"
#include "math.h"

/* =================== micro define ===============*/

//LCD Port Address

#define LCD_Command	0x0200000
#define LCD_Data	0x0200001

/* =================== declares ===================*/
extern unsigned char VRAM_page;	// Globle variable,current display coordinate,for byte mode
extern unsigned char VRAM_column;

unsigned char LCD_Disp_Page;
unsigned char LCD_Disp_Column;
extern unsigned char data1;
extern const unsigned char cucImage1[];
extern const unsigned char cucweb01[];
extern const unsigned char green[];
extern const unsigned char index[];
extern const unsigned char aaa[];
extern const unsigned char game[];
extern const unsigned char pri02[];
extern const unsigned char zy[];
extern const unsigned char kitty[];
extern const unsigned char hy[];

//extern unsigned short VRAM[160][120];
//extern unsigned short ASCIIchar[128][6];

/* =================== functions ===================*/

void LCD_initial(void);		// LCD initial

void LCD_Display_on(void);	// Display ON

void LCD_Display_off(void);	// Display OFF

void display( unsigned char data1, unsigned short n );	// display data

void vDisplayImage1( void );

void vDisplayImage2( void );

void vDisplayImage3( void );	            

void vClrLcd( void );

void vDisplayPallete( void );
//================================== Functions Definition (basic operations) =====================================

/************************************************
*                                               *
*                                   		*
*       Initial the TCM-A1263 module            *
*                                   		*
*                                   		*
************************************************/
void LCD_initial(void)
{	
	unsigned long i;
//	unsigned char i,j;
//	for (i=0;i<=159;i++)
//		for (j=0;j<=119;j++)
//			VRAM[i][j]= 0x00;
					
	//initial
	*(volatile unsigned char *)LCD_Command = 0xAE; // Display Off
	*(volatile unsigned char *)LCD_Command = 0x95; // Sleep in
	*(volatile unsigned char *)LCD_Command = 0xA7; // Display invert
	*(volatile unsigned char *)LCD_Command = 0xCA; // Display Control
	*(volatile unsigned char *)LCD_Data = 0x00; // Test mode,divid ratio,driving pattern
	*(volatile unsigned char *)LCD_Data = 0x27; // Duty=1/160
	*(volatile unsigned char *)LCD_Data = 0x0C; // FR-frequency=11H-inversion
	*(volatile unsigned char *)LCD_Command = 0x75; // Pager address set
	*(volatile unsigned char *)LCD_Data = 0x00; // page 0 (start)
	*(volatile unsigned char *)LCD_Data = 0x9f; // page 159 (end)
	*(volatile unsigned char *)LCD_Command = 0x15; // Column address set
	*(volatile unsigned char *)LCD_Data = 0x00; // Column 0 (start)
	*(volatile unsigned char *)LCD_Data = 0x77; // Column 119 (end)
	*(volatile unsigned char *)LCD_Command = 0xBC; // Data scan direction
	*(volatile unsigned char *)LCD_Data = 0x02; // Page 0 address location=line1 , Scan direction=Column direction
	*(volatile unsigned char *)LCD_Data = 0x01; // RGB alignment
	*(volatile unsigned char *)LCD_Command = 0xC6; // Volumn control
	*(volatile unsigned char *)LCD_Data = 0x10; // Vclk,Vu/d=L
	*(volatile unsigned char *)LCD_Command = 0x94;	//Sleep out
	for( i = 0; i < 0x0fffff; i++ )
	{
		asm("nop");
	}	
	*(volatile unsigned char *)LCD_Command = 0xAF; // Display on
}

//--------------------------------------------------------------------------------------------------------------------

void LCD_Display_on( void )
{
	*(volatile unsigned char *)LCD_Command = 0xAF;	// Display ON
}

//--------------------------------------------------------------------------------------------------------------------

void LCD_Display_off( void )
{	
	*(volatile unsigned char *)LCD_Command = 0xAE; //  Display OFF
}
	
void vClrLcd( void )
{
	unsigned short i;
	*(volatile unsigned char *)LCD_Command = 0x5C;	// writes data in the display memory
	
	for( i = 0; i < 3840 * 5; i++ )
		*(volatile unsigned char *)LCD_Data = 0;

	*(volatile unsigned char *)LCD_Command = 0x25;	// NOP operation
}

void display ( unsigned char data1, unsigned short n ) 
{
	unsigned short i;
	
	for( i = 0 ; i < n ; i++ )	
	{
		*(volatile unsigned char *)LCD_Data = data1;
	}
}

void vDisplayImage1( void )
{
	unsigned char tempdata;
	unsigned short* ucpImage;
	for( ucpImage = ( unsigned short * )index; ucpImage - ( unsigned short * )index < 19200 / 2; ucpImage++ )
	{
		tempdata = *ucpImage >> 8;
		*(volatile unsigned char *)LCD_Data = *ucpImage;
		//asm("nop");
		*(volatile unsigned char *)LCD_Data = tempdata;
	}
}

void vDisplayImage2( void )
{
	unsigned char tempdata;
	unsigned short* ucpImage;
	for( ucpImage = ( unsigned short * )pri02; ucpImage - ( unsigned short * )pri02 < 19200 / 2; ucpImage++ )
	{
		tempdata = *ucpImage >> 8;
		*(volatile unsigned char *)LCD_Data = *ucpImage;
		//asm("nop");
		*(volatile unsigned char *)LCD_Data = tempdata;
	}
}

void vDisplayImage3( void )
{
	unsigned char tempdata;
	unsigned short* ucpImage;
	for( ucpImage = ( unsigned short * )kitty; ucpImage - ( unsigned short * )kitty < 19200 / 2; ucpImage++ )
	{
		tempdata = *ucpImage >> 8;
		*(volatile unsigned char *)LCD_Data = *ucpImage;
		//asm("nop");
		*(volatile unsigned char *)LCD_Data = tempdata;
	}
}
	
void vDisplayPallete( void )
{
	unsigned short i, j;
	unsigned char data = 0x2a;
	*(volatile unsigned char *)LCD_Command = 0x5C;	// writes data in the display memory
	
	for( j = 0; j < 0x08; j++ )
	{
		for( i = 0; i < 2400; i++ )
			*(volatile unsigned char *)LCD_Data = data;
		//data >>= 3;
		//data = ~data;
		data = 0xff;
		if( j == 0 )
			data = 0;
	}

	*(volatile unsigned char *)LCD_Command = 0x25;	// NOP operation
}
