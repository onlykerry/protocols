/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: 16timer.h						*
 *	  This is 16bit timer driver header file.			*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify.		*
 *									*
 ************************************************************************/

/* Address definition */
#define		T16P_CR0A_ADDR		0x48180		// Address for 16bit timer0 compare data A register
#define		T16P_CR0B_ADDR		0x48182		// Address for 16bit timer0 compare data B register
#define		T16P_TC0_ADDR		0x48184		// Address for 16bit timer0 counter data register
#define		T16P_PRUN0_ADDR		0x48186		// Address for 16bit timer0 control register

#define		T16P_CR1A_ADDR		0x48188		// Address for 16bit timer1 compare data A register
#define		T16P_CR1B_ADDR		0x4818a		// Address for 16bit timer1 compare data B register
#define		T16P_TC1_ADDR		0x4818c		// Address for 16bit timer1 counter data register
#define		T16P_PRUN1_ADDR		0x4818e		// Address for 16bit timer1 control register

#define		T16P_CR2A_ADDR		0x48190		// Address for 16bit timer2 compare data A register
#define		T16P_CR2B_ADDR		0x48192		// Address for 16bit timer2 compare data B register
#define		T16P_TC2_ADDR		0x48194		// Address for 16bit timer2 counter data register
#define		T16P_PRUN2_ADDR		0x48196		// Address for 16bit timer2 control register

#define		T16P_CR3A_ADDR		0x48198		// Address for 16bit timer3 compare data A register
#define		T16P_CR3B_ADDR		0x4819a		// Address for 16bit timer3 compare data B register
#define		T16P_TC3_ADDR		0x4819c		// Address for 16bit timer3 counter data register
#define		T16P_PRUN3_ADDR		0x4819e		// Address for 16bit timer3 control register

#define		T16P_CR4A_ADDR		0x481a0		// Address for 16bit timer4 compare data A register
#define		T16P_CR4B_ADDR		0x481a2		// Address for 16bit timer4 compare data B register
#define		T16P_TC4_ADDR		0x481a4		// Address for 16bit timer4 counter data register
#define		T16P_PRUN4_ADDR		0x481a6		// Address for 16bit timer4 control register

#define		T16P_CR5A_ADDR		0x481a8		// Address for 16bit timer5 compare data A register
#define		T16P_CR5B_ADDR		0x481aa		// Address for 16bit timer5 compare data B register
#define		T16P_TC5_ADDR		0x481ac		// Address for 16bit timer5 counter data register
#define		T16P_PRUN5_ADDR		0x481ae		// Address for 16bit timer5 control register


/* Bit field definition */
#define		T16P_SELFM_FM		0x40		// 16bit timer fine mode
#define		T16P_SELFM_NOR		0x00		// 16bit timer normal mode

#define		T16P_SELCRB_ENA		0x20		// 16bit timer compare buffer enable
#define		T16P_SELCRB_DIS		0x00		// 16bit timer compare buffer disable

#define		T16P_OUTINV_INV		0x10		// 16bit timer output inverted
#define		T16P_OUTINV_NOR		0x00		// 16bit timer output normal

#define		T16P_CKSL_EXT		0x08		// 16bit timer input clock selection external
#define		T16P_CKSL_INT		0x00		// 16bit timer input clock selection internal

#define		T16P_PTM_ON		0x04		// 16bit timer clock output control on
#define		T16P_PTM_OFF		0x00		// 16bit timer clock output control off

#define		T16P_PSET_ON		0x02		// 16bit timer preset on
#define		T16P_PSET_OFF		0x00		// 16bit timer preset off

#define		T16P_PRUN_RUN		0x01		// 16bit timer run
#define		T16P_PRUN_STOP		0x00		// 16bit timer stop
