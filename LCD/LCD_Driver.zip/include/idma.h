/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: idma.h						*
 *	  This is IDMA driver header file.				*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify.		*
 *									*
 ************************************************************************/

/* Address definition */
#define		IDMA_DBASEL_ADDR	0x48200		// Address for IDMA base address (low-order 16 bits)
#define		IDMA_DBASEH_ADDR	0x48202		// Address for IDMA base address (high-order 12 bits)
#define		IDMA_DCHN_ADDR		0x48204		// Address for IDMA channel number, IDMA start register
#define		IDMA_DMAEN_ADDR		0x48205		// Address for IDMA enable register

#define		IDMA_DEP0_DEHDM_DE16T0_ADDR	0x40294		// Address for input port0-3, HSDMA and 16bit timer0 IDMA enable register
#define		IDMA_DE16T1_DE16T4_ADDR		0x40295		// Address for 16bit timer1-4 IDMA enable register
#define		IDMA_DE16T5_DE8TU_DES0_ADDR	0x40296		// Address for 16bit timer5, 8bit timer0-3, serial interface ch0 IDMA enable register
#define		IDMA_DES1_DEADE_DEP4_ADDR	0x40297		// Address for serial interface ch1, A/D converter, port input4-7 IDMA enable register


/* Bit field definition */
/* IDMA control word bit field definition ... 1st word */
#define		IDMA_LNKEN_ENA		0x80000000	// Link enable
#define		IDMA_LNKEN_DIS		0x00000000	// Link disable

/* IDMA control word bit field definition ... 2nd word */
#define		IDMA_DINTEN_ENA		0x80000000	// IDMA terminate interrupt enable
#define		IDMA_DINTEN_DIS		0x00000000	// IDMA terminate interrupt disable
#define		IDMA_DATSIZ_HW		0x40000000	// Data size .. half word
#define		IDMA_DATSIZ_BYTE	0x00000000	// Data size .. byte
#define		IDMA_SRINC_INC		0x30000000	// Increase address (return initial value when block transfer mode
#define		IDMA_SRINC_INCR		0x20000000	// Increase address (return initial value when block transfer mode
#define		IDMA_SRINC_DEC		0x10000000	// Decrease address (do not return initial value when block transfer mode
#define		IDMA_SRINC_FIX		0x00000000	// Address fix

/* IDMA control word bit field definition ... 3rd word */
#define		IDMA_DMOD_BLOCK		0x80000000	// Block transfer mode
#define		IDMA_DMOD_SEQ		0x40000000	// Sequential transfer mode
#define		IDMA_DMID_SIG		0x00000000	// Single transfer mode
#define		IDMA_DSINC_INC		0x30000000	// Increase address (return initial value when block transfer mode
#define		IDMA_DSINC_INCR		0x20000000	// Increase address (return initial value when block transfer mode
#define		IDMA_DSINC_DEC		0x10000000	// Decrease address (do not return initial value when block transfer mode
#define		IDMA_DSINC_FIX		0x00000000	// Address fix

/* IDMA control channel register bit definition */
#define		IDMA_DSTART_RUN		0x80		// IDMA start bit

/* IDMA enable register bit definition */
#define		IDMA_DE16TC0		0x80		// 16bit timer0 comparison match IDMA enable
#define		IDMA_DE16TU0		0x40		// 16bit timer0 underflow IDMA enable
#define		IDMA_DEHDM1		0x20		// HSDMA ch.1 IDMA enable
#define		IDMA_DEHDM0		0x10		// HSDMA ch.0 IDMA enable
#define		IDMA_DEP3		0x08		// Input port3 IDMA enable
#define		IDMA_DEP2		0x04		// Input port2 IDMA enable
#define		IDMA_DEP1		0x02		// Input port1 IDMA enable
#define		IDMA_DEP0		0x01		// Input port0 IDMA enable
#define		IDMA_DE16TC4		0x08		// 16bit timer4 comparison match A IDMA enable
#define		IDMA_DE16TU4		0x04		// 16bit timer4 comparison match B IDMA enable
#define		IDMA_DE16TC3		0x02		// 16bit timer3 comparison match A IDMA enable
#define		IDMA_DE16TU3		0x01		// 16bit timer3 comparison match B IDMA enable
#define		IDMA_DE16TC2		0x08		// 16bit timer2 comparison match A IDMA enable
#define		IDMA_DE16TU2		0x04		// 16bit timer2 comparison match B IDMA enable
#define		IDMA_DE16TC1		0x02		// 16bit timer1 comparison match A IDMA enable
#define		IDMA_DE16TU1		0x01		// 16bit timer1 comparison match B IDMA enable
#define		IDMA_DESTX0		0x80		// Serial interface ch.0 transmit DBF IDMA enable
#define		IDMA_DESRX0		0x40		// Serial interface ch.0 receive DBF IDMA enable
#define		IDMA_DE8TU3		0x20		// 8bit timer3 underflow IDMA enable
#define		IDMA_DE8TU2		0x10		// 8bit timer2 underflow IDMA enable
#define		IDMA_DE8TU1		0x08		// 8bit timer1 underflow IDMA enable
#define		IDMA_DE8TU0		0x04		// 8bit timer0 underflow IDMA enable
#define		IDMA_DE16TC5		0x02		// 16bit timer5 comparison match A IDMA enable
#define		IDMA_DE16TU5		0x01		// 16bit timer5 comparison match B IDMA enable
#define		IDMA_DEP7		0x80		// Input port7 IDMA enable
#define		IDMA_DEP6		0x40		// Input port6 IDMA enable
#define		IDMA_DEP5		0x20		// Input port5 IDMA enable
#define		IDMA_DEP4		0x10		// Input port5 IDMA enable
#define		IDMA_DEADE		0x04		// A/D converter convert end IDMA enable
#define		IDMA_DESTX1		0x02		// Serial interface ch.1 transmit buffer empty IDMA enable
#define		IDMA_DESRX1		0x01		// Serial interface ch.1 receive buffer full IDMA enable
#define		IDMA_DEIDMA_DIS		0x00		// IDMA enable is all disable
