/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: io.h							*
 *	  This is I/O port driver header file.				*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify.		*
 *									*
 ************************************************************************/

/* Address definition */
#define		IN_CFK5_ADDR		0x402c0		// Address for K50-54 input port selection register
#define		IN_K5D_ADDR		0x402c1		// Address for K50-54 input port data register
#define		IN_CFK6_ADDR		0x402c3		// Address for K60-67 input port selection register
#define		IN_K6D_ADDR		0x402c4		// Address for K60-67 input port data register
#define		IN_SPT0_SPT3_ADDR	0x402c6		// Address for FPT0-FPT3 interrupt port selection register
#define		IN_SPT4_SPT7_ADDR	0x402c7		// Address for FPT4-FPT7 interrupt port selection register
#define		IN_SPP_ADDR		0x402c8		// Address for FPT0-FPT7 interrupt input polarity selection register
#define		IN_SEP_ADDR		0x402c9		// Address for FPT0-FPT7 interrupt edge/level selection register
#define		IN_SPPK_ADDR		0x402ca		// Address for FPK0-FPK1 interrupt port selection register
#define		IN_SCPK0_ADDR		0x402cc		// Address for FPK0 input comparison register
#define		IN_SCPK1_ADDR		0x402cd		// Address for FPK1 input comparison register
#define		IN_SMPK0_ADDR		0x402ce		// Address for FPK0 input mask register
#define		IN_SMPK1_ADDR		0x402cf		// Address for FPK1 input mask register

#define		IO_CFP0_ADDR		0x402d0		// Address for P00-P07 input/output function selection register
#define		IO_P0D_ADDR		0x402d1		// Address for P00-P07 input/output port data register
#define		IO_IOC0_ADDR		0x402d2		// Address for P00-P07 input/output direction control register
#define		IO_CFP1_ADDR		0x402d4		// Address for P10-P16 input/output function selection register
#define		IO_P1D_ADDR		0x402d5		// Address for P10-P16 input/output port data register
#define		IO_IOC1_ADDR		0x402d6		// Address for P10-P16 input/output direction control register
#define		IO_CFP2_ADDR		0x402d8		// Address for P20-P27 input/output function selection register
#define		IO_P2D_ADDR		0x402d9		// Address for P20-P27 input/output port data register
#define		IO_IOC2_ADDR		0x402da		// Address for P20-P27 input/output direction control register
#define		IO_CFP3_ADDR		0x402dc		// Address for P30-P35 input/output function selection register
#define		IO_P3D_ADDR		0x402dd		// Address for P30-P35 input/output port data register
#define		IO_IOC3_ADDR		0x402de		// Address for P30-P35 input/output direction control register
#define		IO_CFEX_ADDR		0x402df		// Address for extended port selection regiser.


/* Bit field definition */
#define		IN_CFK54_DA1		0x10		// DA1 in K54
#define		IN_CFK53_DA0		0x08		// DA0 in K53
#define		IN_CFK52_ADTRG		0x04		// #ADTRG in K52
#define		IN_CFK51_DMAREQ1	0x02		// #DMAREQ1 in K51
#define		IN_CFK50_DMAREQ0	0x01		// #DMAREQ0 in K50

#define		IN_CFK67_AD7		0x80		// AD7 in K67
#define		IN_CFK66_AD6		0x40		// AD6 in K66
#define		IN_CFK65_AD5		0x20		// AD5 in K65
#define		IN_CFK64_AD4		0x10		// AD4 in K64
#define		IN_CFK63_AD3		0x08		// AD3 in K63
#define		IN_CFK62_AD2		0x04		// AD2 in K62
#define		IN_CFK61_AD1		0x02		// AD1 in K61
#define		IN_CFK60_AD0		0x01		// AD0 in K60
#define		IN_CFKALL_INP		0x00		// All input port

#define		IN_SPT3_P23		0xc0		// Interrupt port P23
#define		IN_SPT3_P03		0x40		// Interrupt port P03
#define		IN_SPT3_K53		0x20		// Interrupt port K53
#define		IN_SPT3_K63		0x00		// Interrupt port K63
#define		IN_SPT2_P22		0x30		// Interrupt port P22
#define		IN_SPT2_P02		0x20		// Interrupt port P02
#define		IN_SPT2_K52		0x10		// Interrupt port K52
#define		IN_SPT2_K62		0x00		// Interrupt port K62
#define		IN_SPT1_P21		0x0c		// Interrupt port P21
#define		IN_SPT1_P01		0x04		// Interrupt port P01
#define		IN_SPT1_K51		0x02		// Interrupt port K51
#define		IN_SPT1_K61		0x00		// Interrupt port K61
#define		IN_SPT0_P20		0x03		// Interrupt port P20
#define		IN_SPT0_P00		0x02		// Interrupt port P00
#define		IN_SPT0_K50		0x01		// Interrupt port K50
#define		IN_SPT0_K60		0x00		// Interrupt port K60

#define		IN_SPT7_P27		0xc0		// Interrupt port P23
#define		IN_SPT7_P07		0x80		// Interrupt port P03
#define		IN_SPT7_P33		0x40		// Interrupt port P33
#define		IN_SPT7_K67		0x00		// Interrupt port K67
#define		IN_SPT6_P26		0x30		// Interrupt port P22
#define		IN_SPT6_P06		0x20		// Interrupt port P02
#define		IN_SPT6_P32		0x10		// Interrupt port P32
#define		IN_SPT6_K66		0x00		// Interrupt port K66
#define		IN_SPT5_P25		0x0c		// Interrupt port P25
#define		IN_SPT5_P05		0x08		// Interrupt port P05
#define		IN_SPT5_P31		0x04		// Interrupt port P32
#define		IN_SPT5_K65		0x00		// Interrupt port K65
#define		IN_SPT4_P24		0x03		// Interrupt port P24
#define		IN_SPT4_P04		0x02		// Interrupt port P04
#define		IN_SPT4_K54		0x01		// Interrupt port K54
#define		IN_SPT4_K64		0x00		// Interrupt port K64

#define		IN_SPPK1_P2		0x0c		// Interrupt port P2[7:4]
#define		IN_SPPK1_P0		0x08		// Interrupt port P0[7:4]
#define		IN_SPPK1_K67_K64	0x04		// Interrupt port K6[7:4]
#define		IN_SPPK1_K63_K30	0x00		// Interrupt port K6[3:0]
#define		IN_SPPK0_P2		0x03		// Interrupt port P2[7:4]
#define		IN_SPPK0_P0		0x02		// Interrupt port P0[7:4]
#define		IN_SPPK0_K64_K60	0x01		// Interrupt port K6[4:0]
#define		IN_SPPK0_K54_K50	0x00		// Interrupt port K5[4:0]

#define		IO_CFP07_SRDY1		0x80		// Serial interface ch.1 #SRDY1 input/output in P07
#define		IO_CFP06_SCLK1		0x40		// Serial interface ch.1 #SCLK1 input/output in P06
#define		IO_CFP05_SOUT1		0x20		// Serial interface ch.1 SOUT1 output in P05
#define		IO_CFP04_SIN1		0x10		// Serial interface ch.1 SIN1 input in P04
#define		IO_CFP03_SRDY0		0x08		// Serial interface ch.0 #SRDY0 input/output in P03
#define		IO_CFP02_SCLK0		0x04		// Serial interface ch.0 #SCLK0 input/output in P02
#define		IO_CFP01_SOUT0		0x02		// Serial interface ch.0 SOUT0 output in P01
#define		IO_CFP00_SIN0		0x01		// Serial interface ch.0 SIN0 input in P00

#define		IO_CFP16_EXCL5_DMAEND1	0x40		// 16bit timer5 event counter input/#DMAEND1 output in P16
#define		IO_CFP15_EXCL4_DMAEND0	0x20		// 16bit timer4 event counter input/#DMAEND0 output in P15
#define		IO_CFP14_FOSC1		0x10		// FOSC1 signal in P14
#define		IO_CFP13_EXCL3_T8UF3	0x08		// 16bit timer3 event counter input/8bit timer3 output in P13
#define		IO_CFP12_EXCL2_T8UF2	0x04		// 16bit timer2 event counter input/8bit timer2 output in P12
#define		IO_CFP11_EXCL1_T8UF1	0x02		// 16bit timer1 event counter input/8bit timer1 output in P11
#define		IO_CFP10_EXCL0_T8UF0	0x01		// 16bit timer0 event counter input/8bit timer0 output in P10

#define		IO_CFP27_TM5		0x80		// TM5
#define		IO_CFP26_TM4		0x40		// TM4
#define		IO_CFP25_TM3		0x20		// TM3
#define		IO_CFP24_TM2		0x10		// TM2
#define		IO_CFP23_TM1		0x08		// TM1
#define		IO_CFP22_TM0		0x04		// TM0
#define		IO_CFP21_DWE		0x02		// DWE
#define		IO_CFP20_DRD		0x01		// DRD

#define		IO_CFP35_BUSACK		0x30		// #BUSACK
#define		IO_CFP34_BUSREQ_CE6	0x20		// #BUSREQ, #CE6
#define		IO_CFP33_DMAACK1	0x08		// #DMAACK1
#define		IO_CFP32_DMAACK0	0x04		// #DMAACK0
#define		IO_CFP31_BUSGET		0x02		// #BUSGET
#define		IO_CFP30_WAIT_CE4_CE5	0x01		// #WAIT,#CE4/CE5

#define		IO_CFEX7_DMAEND3	0x80		// #DMAEND3
#define		IO_CFEX6_DMAACK3	0x40		// #DMAACK3
#define		IO_CFEX5_DMAEND2	0x20		// #DMAEND2
#define		IO_CFEX4_DMAACK2	0x10		// #DMAACK2
#define		IO_CFEX3_GARD		0x08		// #GARD
#define		IO_CFEX2_GAAS		0x04		// #GAAS
#define		IO_CFEX1_DST_DPC	0x02		// DST0,DST1,DPC0
#define		IO_CFEX0_DST_DCLK	0x01		// DST2,DCLK

#define		IO_CFPALL_IOP		0x00		// All input/output port

#define		IO_IOCALL_OUT		0xff		// All output direction
#define		IO_IOCALL_INP		0x00		// All input direction
