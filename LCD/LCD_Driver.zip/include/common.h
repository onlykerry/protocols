/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: common.h						*
 *	  This is common header file.					*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify.		*
 *									*
 ************************************************************************/

/* Constant define */
#ifndef	TRUE
#define	TRUE	(1==1)
#endif

#ifndef	FALSE
#define	FALSE	(!(1==1))
#endif

/* Macro */
#define	INT_BEGIN	asm("pushn	%r15")
#define	INT_END		asm("popn	%r15\n	reti")
