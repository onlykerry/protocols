/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: 8timer.h						*
 *	  This is 8bit timer driver header file.			*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *									*
 ************************************************************************/

/* Address definition */
#define		T8P_PTRUN0_ADDR		0x40160		// Address for 8bit timer 0 clock output control, preset, run/stop control register
#define		T8P_RLD0_ADDR		0x40161		// Address for 8bit timer 0 reload data register
#define		T8P_PTD0_ADDR		0x40162		// Address for 8bit timer 0 counter data register

#define		T8P_PTRUN1_ADDR		0x40164		// Address for 8bit timer 1 clock output control, preset, run/stop control register
#define		T8P_RLD1_ADDR		0x40165		// Address for 8bit timer 1 reload data register
#define		T8P_PTD1_ADDR		0x40166		// Address for 8bit timer 1 counter data register

#define		T8P_PTRUN2_ADDR		0x40168		// Address for 8bit timer 2 clock output control, preset, run/stop control register
#define		T8P_RLD2_ADDR		0x40169		// Address for 8bit timer 2 reload data register
#define		T8P_PTD2_ADDR		0x4016a		// Address for 8bit timer 2 counter data register

#define		T8P_PTRUN3_ADDR		0x4016c		// Address for 8bit timer 3 clock output control, preset, run/stop control register
#define		T8P_RLD3_ADDR		0x4016d		// Address for 8bit timer 3 reload data register
#define		T8P_PTD3_ADDR		0x4016e		// Address for 8bit timer 3 counter data register


/* Bit field definition */
#define		T8P_PTOUT_ON		0x04		// 8bit timer clock output control on
#define		T8P_PTOUT_OFF		0x00		// 8bit timer clock output control off

#define		T8P_PSET_ON		0x02		// 8bit timer preset on
#define		T8P_PSET_OFF		0x00		// 8bit timer preset off

#define		T8P_PTRUN_RUN		0x01		// 8bit timer run
#define		T8P_PTRUN_STOP		0x00		// 8bit timer stop
