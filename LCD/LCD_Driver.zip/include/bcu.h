/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: bcu.h						*
 *	  This is BCU driver header file.				*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define Modify.		*
 *									*
 ************************************************************************/

/* Address definition */
#define		BCU_A15_A18_ADDR	0x48120		// Address for area 15-18 BCU register
#define		BCU_A13_A14_ADDR	0x48122		// Address for area 13-14 BCU register
#define		BCU_A11_A12_ADDR	0x48124		// Address for area 11-12 BCU register
#define		BCU_A9_A10_ADDR		0x48126		// Address for area 9-10 BCU register
#define		BCU_A7_A8_ADDR		0x48128		// Address for area 7-8 BCU register
#define		BCU_A4_A5_A6_ADDR	0x4812a		// Address for area 4-6 BCU register
#define		BCU_SWAITE_ADDR		0x4812e		// Address for #WAIT enable, external interface setting, DRAM interface estabishment, refresh setting, DRAM page mode selection, burst ROM mode selection, BCLK output control register
#define		BCU_TBRP_ADDR		0x4812d		// Address for TTBR register write protect
#define		BCU_RASC_ADDR		0x48130		// Address for DRAM RAS, CAS cycle, RAS precharge cycle, successive RAS mode, #CE pin function selection register
#define		BCU_EC_IO_ADDR		0x48132		// Address for area 5-18 endian control and external/internal access control register
#define		BCU_TTBRL_ADDR		0x48134		// Address for trap table base address register (low-order address)
#define		BCU_TTBRH_ADDR		0x48136		// Address for trap table base address register (high-order address)
#define		BCU_RD_AD_ADDR		0x48138		// Address for G/A read signal control register
#define		BCU_BCLKSEL_ADDR	0x4813a		// Address for BCLK selection register


/* Bit field definition */
#define		BCU_boot_16K		0x0000		// Area 10 Boot ROM size 16K
#define		BCU_boot_32K		0x1000		// Area 10 Boot ROM size 32K
#define		BCU_boot_64K		0x2000		// Area 10 Boot ROM size 64K
#define		BCU_boot_128K		0x3000		// Area 10 Boot ROM size 128K
#define		BCU_boot_256K		0x4000		// Area 10 Boot ROM size 256K
#define		BCU_boot_512K		0x5000		// Area 10 Boot ROM size 512K
#define		BCU_boot_1M		0x6000		// Area 10 Boot ROM size 1M
#define		BCU_boot_2M		0x7000		// Area 10 Boot ROM size 2M

//#define		BCU_boot_16K		0x0000		// Area 10 Boot ROM size 16K
//#define		BCU_boot_32K		0x0100		// Area 10 Boot ROM size 32K
//#define		BCU_boot_64K		0x0200		// Area 10 Boot ROM size 64K
//#define		BCU_boot_128K		0x0300		// Area 10 Boot ROM size 128K
//#define		BCU_boot_256K		0x0400		// Area 10 Boot ROM size 256K
//#define		BCU_boot_512K		0x0500		// Area 10 Boot ROM size 512K
//#define		BCU_boot_1M		0x0600		// Area 10 Boot ROM size 1M
//#define		BCU_boot_2M		0x0700		// Area 10 Boot ROM size 2M 

#define		BCU_SZH_8		0x4000		// Device size 8 bits (high-order address)
#define		BCU_SZH_16		0x0000		// Device size 16 bits (high-order address)

#define		BCU_SZL_8		0x0040		// Device size 8 bits (low-order address)
#define		BCU_SZL_16		0x0000		// Device size 16 bits (low-order address)

#define		BCU_DFH_35		0x3000		// Output disable delay 3.5 (high-order address)
#define		BCU_DFH_25		0x2000		// Output disable delay 2.5 (high-order address)
#define		BCU_DFH_15		0x1000		// Output disable delay 1.5 (high-order address)
#define		BCU_DFH_05		0x0000		// Output disable delay 0.5 (high-order address)

#define		BCU_DFL_35		0x0030		// Output disable delay 3.5 (low-order address)
#define		BCU_DFL_25		0x0020		// Output disable delay 2.5 (low-order address)
#define		BCU_DFL_15		0x0010		// Output disable delay 1.5 (low-order address)
#define		BCU_DFL_05		0x0000		// Output disable delay 0.5 (low-order address)

#define		BCU_WTH_7		0x0700		// Wait control 7 (high-order address)
#define		BCU_WTH_6		0x0600		// Wait control 6 (high-order address)
#define		BCU_WTH_5		0x0500		// Wait control 5 (high-order address)
#define		BCU_WTH_4		0x0400		// Wait control 4 (high-order address)
#define		BCU_WTH_3		0x0300		// Wait control 3 (high-order address)
#define		BCU_WTH_2		0x0200		// Wait control 2 (high-order address)
#define		BCU_WTH_1		0x0100		// Wait control 1 (high-order address)
#define		BCU_WTH_0		0x0000		// Wait control 0 (high-order address)

#define		BCU_WTL_7		0x0007		// Wait control 7 (low-order address)
#define		BCU_WTL_6		0x0006		// Wait control 6 (low-order address)
#define		BCU_WTL_5		0x0005		// Wait control 5 (low-order address)
#define		BCU_WTL_4		0x0004		// Wait control 4 (low-order address)
#define		BCU_WTL_3		0x0003		// Wait control 3 (low-order address)
#define		BCU_WTL_2		0x0002		// Wait control 2 (low-order address)
#define		BCU_WTL_1		0x0001		// Wait control 1 (low-order address)
#define		BCU_WTL_0		0x0000		// Wait control 0 (low-order address)

#define		BCU_DRAH_USE		0x0100		// Area 14 and area 8 DRAM is used
#define		BCU_DRAH_NOT		0x0000		// Area 14 and area 8 DRAM is not used

#define		BCU_DRAL_USE		0x0080		// Area 13 and area 7 DRAM is used
#define		BCU_DRAL_NOT		0x0000		// Area 13 and area 7 DRAM is not used

#define		BCU_BROH_USE		0x0100		// Area 10 burst ROM is used
#define		BCU_BROH_NOT		0x0000		// area 10 burst ROM is not used

#define		BCU_BROL_USE		0x0080		// Area 9 burst ROM is used
#define		BCU_BROL_NOT		0x0000		// Area 9 burst ROM is not used

#define		BCU_BW_3		0x0600		// Burst ROM burst read cycle wait 3
#define		BCU_BW_2		0x0400		// Burst ROM burst read cycle wait 2
#define		BCU_BW_1		0x0200		// Burst ROM burst read cycle wait 1
#define		BCU_BW_0		0x0000		// Burst ROM burst read cycle wait 0

#define		BCU_RBCLK_HI		0x8000		// BCLK output fixed at high
#define		BCU_RBCLK_ENA		0x0000		// BCLK output enable

#define		BCU_RBST8_8		0x2000		// Burst ROM mode 8
#define		BCU_RBST8_4		0x0000		// Burst ROM mode 4

#define		BCU_REDO_EDO		0x1000		// EDO RAM interface EDO
#define		BCU_REDO_FPAGE		0x0000		// EDO RAM interface fastpage

#define		BCU_RCA_11		0x0C00		// Column address size 11
#define		BCU_RCA_10		0x0800		// Column address size 10
#define		BCU_RCA_9		0x0400		// Column address size 9
#define		BCU_RCA_8		0x0000		// Column address size 8

#define		BCU_RPC2_ENA		0x0200		// Refresh enable
#define		BCU_RPC2_DIS		0x0000		// Refresh disable

#define		BCU_RPC1_SELF		0x0100		// Refresh self-refresh
#define		BCU_RPC1_CBR		0x0000		// Refresh CBR-refresh

#define		BCU_RPC0_2		0x0080		// Refresh RPC delay 2
#define		BCU_RPC0_1		0x0000		// Refresh RPC delay 1

#define		BCU_RRAS_5		0x0060		// Refresh #RAS pulse width 5
#define		BCU_RRAS_4		0x0040		// Refresh #RAS pulse width 4
#define		BCU_RRAS_3		0x0020		// Refresh #RAS pulse width 3
#define		BCU_RRAS_2		0x0000		// Refresh #RAS pulse width 2

#define		BCU_S2WE_2WE		0x0010		// DRAM interface selection 2WE
#define		BCU_S2WE_2CAS		0x0000		// DRAM interface selection 2CAS

#define		BCU_SBUSST_BSL		0x0008		// External interface selection #BSL
#define		BCU_SBUSST_A0		0x0000		// External interface selection A0

#define		BCU_SEMAS_EXIST		0x0004		// External bus master setup existing
#define		BCU_SEMAS_NOT		0x0000		// External bus master setup nonexistent

#define		BCU_SEPD_ENA		0x0002		// External power-down control enabled
#define		BCU_SEPD_DIS		0x0000		// External power-down control disable

#define		BCU_SWAITE_ENA		0x0001		// SRAM #WAIT enable
#define		BCU_SWAITE_DIS		0x0000		// SRAM #WAIT disable

#define		BCU_CEFUNC_HI		0x0200		// #CE pin function selection high address
#define		BCU_CEFUNC_NOR		0x0000		// #CE pin function selection normal address

#define		BCU_CRAS_SEQ		0x0100		// RAS mode sequential
#define		BCU_CRAS_NOR		0x0000		// RAS mode normal
//#define		BCU_CRAS_SEQ		0x0200		// RAS mode sequential
//#define		BCU_CRAS_NOR		0x0000		// RAS mode normal

#define		BCU_RPRC_4		0x00c0		// DRAM RAS precharge cycle 4
#define		BCU_RPRC_3		0x0080		// DRAM RAS precharge cycle 3
#define		BCU_RPRC_2		0x0040		// DRAM RAS precharge cycle 2
#define		BCU_RPRC_1		0x0000		// DRAM RAS precharge cycle 1

#define		BCU_CAS_4		0x0018		// DRAM CAS cycle 4
#define		BCU_CAS_3		0x0010		// DRAM CAS cycle 3
#define		BCU_CAS_2		0x0008		// DRAM CAS cycle 2
#define		BCU_CAS_1		0x0000		// DRAM CAS cycle 1
//#define		BCU_CAS_4		0x000c		// DRAM CAS cycle 4
//#define		BCU_CAS_3		0x0008		// DRAM CAS cycle 3
//#define		BCU_CAS_2		0x0004		// DRAM CAS cycle 2
//#define		BCU_CAS_1		0x0000		// DRAM CAS cycle 1

#define		BCU_RAS_4		0x0003		// DRAM RAS cycle 4
#define		BCU_RAS_3		0x0002		// DRAM RAS cycle 3
#define		BCU_RAS_2		0x0001		// DRAM RAS cycle 2
#define		BCU_RAS_1		0x0000		// DRAM RAS cycle 1

#define		BCU_A18IO_INT		0x8000		// Area 18,17 internal access
#define		BCU_A16IO_INT		0x4000		// Area 16,15 internal access
#define		BCU_A14IO_INT		0x2000		// Area 14,13 internal access
#define		BCU_A12IO_INT		0x1000		// Area 12,11 internal access
#define		BCU_A8IO_INT		0x0400		// Area 8,7 internal access
#define		BCU_A6IO_INT		0x0200		// Area 6 internal access
#define		BCU_A5IO_INT		0x0100		// Area 5,4 internal access

#define		BCU_A18EC_BIG		0x0080		// Area 18,17 internal access
#define		BCU_A16EC_BIG		0x0040		// Area 16,15 internal access
#define		BCU_A14EC_BIG		0x0020		// Area 14,13 internal access
#define		BCU_A12EC_BIG		0x0010		// Area 12,11 internal access
#define		BCU_A10EC_BIG		0x0008		// Area 10,9 internal access
#define		BCU_A8EC_BIG		0x0004		// Area 8,7 internal access
#define		BCU_A6EC_BIG		0x0002		// Area 6 internal access
#define		BCU_A5EC_BIG		0x0001		// Area 5,4 internal access

#define		BCU_A18AS_ENA		0x8000		// Area 18,17 address strobe
#define		BCU_A16AS_ENA		0x4000		// Area 16,15 address strobe
#define		BCU_A14AS_ENA		0x2000		// Area 14,13 address strobe
#define		BCU_A12AS_ENA		0x1000		// Area 12,11 address strobe
#define		BCU_A8AS_ENA		0x0400		// Area 8,7 address strobe
#define		BCU_A6AS_ENA		0x0200		// Area 6 address strobe
#define		BCU_A5AS_ENA		0x0100		// Area 5,4 address strobe

#define		BCU_A18RD_ENA		0x0080		// Area 18,17 read signal
#define		BCU_A16RD_ENA		0x0040		// Area 16,15 read signal
#define		BCU_A14RD_ENA		0x0020		// Area 14,13 read signal
#define		BCU_A12RD_ENA		0x0010		// Area 12,11 read signal
#define		BCU_A8RD_ENA		0x0004		// Area 8,7 read signal
#define		BCU_A6RD_ENA		0x0002		// Area 6 read signal
#define		BCU_A5RD_ENA		0x0001		// Area 5,4 read signal

#define		BCU_BCLKSEL_PLL		0x03		// PLL CLK
#define		BCU_BCLKSEL_OSC3	0x02		// OSC3 CLK
#define		BCU_BCLKSEL_BCU		0x01		// BCU CLK
#define		BCU_BCLKSEL_CPU		0x00		// CPU CLK

#define		BCU_TBRP_WR		0x5900		// Trap table base address register write enable


/* Memory start address */
#define		BCU_AREA4_ADDR		0x0100000	// Area 4 memory start address
#define		BCU_AREA5_ADDR		0x0200000	// Area 5 memory start address
#define		BCU_AREA6_ADDR		0x0300000	// Area 6 memory start address
#define		BCU_AREA7_ADDR		0x0400000	// Area 7 memory start address
#define		BCU_AREA8_ADDR		0x0600000	// Area 8 memory start address
#define		BCU_AREA9_ADDR		0x0800000	// Area 9 memory start address
#define		BCU_AREA10_ADDR		0x0c00000	// Area 10 memory start address
#define		BCU_AREA11_ADDR		0x1000000	// Area 11 memory start address
#define		BCU_AREA12_ADDR		0x1800000	// Area 12 memory start address
#define		BCU_AREA13_ADDR		0x2000000	// Area 13 memory start address
#define		BCU_AREA14_ADDR		0x3000000	// Area 14 memory start address
#define		BCU_AREA15_ADDR		0x4000000	// Area 15 memory start address
#define		BCU_AREA16_ADDR		0x6000000	// Area 16 memory start address
#define		BCU_AREA17_ADDR		0x8000000	// Area 17 memory start address
#define		BCU_AREA18_ADDR		0xc000000	// Area 18 memory start address
