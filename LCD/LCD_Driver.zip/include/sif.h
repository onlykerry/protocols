/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: sif.h						*
 *	  This is serial interface driver header.			*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify		*
 *.		2001.02.03	Kurt Shen	Define modify		*
 *									*
 ************************************************************************/

#define UART_BUFFER_ADDRESS	0xC20000

/* Address definition */
#define		SIF_TXD0_ADDR		0x401e0		// Address for serial interface ch.0 transmit data register
#define		SIF_RXD0_ADDR		0x401e1		// Address for serial interface ch.0 receive data register
#define		SIF_RDBF0_ADDR		0x401e2		// Address for serial interface ch.0 receive data buffer full, transmit data buffer empty, overrun error flag, parity error flag, flaming error flag register
#define		SIF_SMD0_ADDR		0x401e3		// Address for serial interface ch.0 transfer mode selection, input clock selection, stop bit selection, parity mode selection, parity enable, receive enable, transmit enable register
#define		SIF_IRMD0_ADDR		0x401e4		// Address for serial interface ch.0 interface mode selection, IrDA interface input logic inversion, IrDA interface output logic inversion. asynchronous clock division ration register

#define		SIF_TXD1_ADDR		0x401e5		// Address for serial interface ch.1 transmit data register
#define		SIF_RXD1_ADDR		0x401e6		// Address for serial interface ch.1 receive data register
#define		SIF_RDBF1_ADDR		0x401e7		// Address for serial interface ch.1 receive data buffer full, transmit data buffer empty, overrun error flag, parity error flag, flaming error flag register
#define		SIF_SMD1_ADDR		0x401e8		// Address for serial interface ch.1 transfer mode selection, input clock selection, stop bit selection, parity mode selection, parity enable, receive enable, transmit enable register
#define		SIF_IRMD1_ADDR		0x401e9		// Address for serial interface ch.1 interface mode selection, IrDA interface input logic inversion, IrDA interface output logic inversion. asynchronous clock division ration register


/* Bit field definition */
#define		SIF_TEND_ON		0x20		// Transfer status
#define		SIF_FER_ERR		0x10		// Flaming error
#define		SIF_PER_ERR		0x08		// Parity flag error
#define		SIF_OER_ERR		0x04		// Over run error
#define		SIF_TDBE_EMPTY		0x02		// Transfer data buffer full
#define		SIF_RDBF_FULL		0x01		// Receive data buffer full
#define		SIF_ERR_NON		0x00		// Serial status register no error

#define		SIF_TXEN_ENA		0x80		// Transfer enable
#define		SIF_TXEN_DIS		0x00		// Transfer disable

#define		SIF_RXEN_ENA		0x40		// Receive enable
#define		SIF_RXEN_DIS		0x00		// Receive disable

#define		SIF_EPR_ON		0x20		// Parity on
#define		SIF_EPR_OFF		0x00		// Parity off

#define		SIF_PMD_ODD		0x10		// Parity odd mode
#define		SIF_PMD_EVEN		0x00		// Parity even mode

#define		SIF_STPB_2		0x08		// Stop bit 2 bits
#define		SIF_STPB_1		0x00		// Stop bit 1 bit

#define		SIF_SSCK_SCLK		0x04		// Input clock #SCLK
#define		SIF_SSCK_INT		0x00		// Input clock internal clock

#define		SIF_SMD_8BIT		0x03		// Serial interface mode asynchronous 8bit
#define		SIF_SMD_7BIT		0x02		// Serial interface mode asynchronous 7bit
#define		SIF_SMD_SLA		0x01		// Serial interface mode clock synchronous slave
#define		SIF_SMD_MAS		0x00		// Serial interface mode clock synchronous master

#define		SIF_DIVMD_8		0x10		// Asynchronous clock division ratio 1/8
#define		SIF_DIVMD_16		0x00		// Asynchronous clock division ratio 1/16

#define		SIF_IRTL_INV		0x08		// IrDA interface transmit logic inversion inverted
#define		SIF_IRTL_DIR		0x00		// IrDA interface transmit logic inversion direct

#define		SIF_IRRL_INV		0x04		// IrDA interface receive logic inversion inverted
#define		SIF_IRRL_DIR		0x00		// IrDA interface receive logic inversion direct

#define		SIF_IRMD_IRDA		0x02		// IrDA 1.0
#define		SIF_IRMD_ORD		0x00		// Ordinary interface

