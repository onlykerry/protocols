/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: ct.h							*
 *	  This is clock timer driver header file.			*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify.		*
 *									*
 ************************************************************************/

/* Address definition */
#define		CT_TCRUN_ADDR		0x40151		// Address for clock timer run/stop control, clock timer reset register
#define		CT_TCAF_ADDR		0x40152		// Address for clock timer alarm factor generation flag, interrupt factor generation flag, clock timer alarm factor selection. clock timer interrupt factor selection register
#define		CT_TCD_ADDR		0x40153		// Address for clock timer data (Hz)
#define		CT_TCMD_ADDR		0x40154		// Address for clock timer data (second)
#define		CT_TCHD_ADDR		0x40155		// Address for clock timer data (minute)
#define		CT_TCDD_ADDR		0x40156		// Address for clock timer data (hour)
#define		CT_TCNDL_ADDR		0x40157		// Address for clock timer data (day low-order)
#define		CT_TCNDH_ADDR		0x40158		// Address for clock timer data (day high-order)
#define		CT_TCCH_ADDR		0x40159		// Address for clock timer minute comparison data
#define		CT_TCCD_ADDR		0x4015a		// Address for clock timer hour comparison data
#define		CT_TCCN_ADDR		0x4015b		// Address for clock timer day comparison data


/* Bit field definition */
#define		CT_TCRST_RST		0x02		// Clock timer reset

#define		CT_TCISE_NONE		0xe0		// Clock timer interrupt none
#define		CT_TCISE_D		0xc0		// Clock timer interrupt day
#define		CT_TCISE_H		0xa0		// Clock timer interrupt hour
#define		CT_TCISE_M		0x80		// Clock timer interrupt minute
#define		CT_TCISE_1HZ		0x60		// Clock timer interrupt 1Hz
#define		CT_TCISE_2HZ		0x40		// Clock timer interrupt 2Hz
#define		CT_TCISE_8HZ		0x20		// Clock timer interrupt 8Hz
#define		CT_TCISE_32HZ		0x00		// Clock timer interrupt 32Hz

#define		CT_TCASE_D		0x10		// Clock timer day alarm
#define		CT_TCASE_H		0x08		// Clock timer hour alarm
#define		CT_TCASE_M		0x04		// Clock timer minute alarm
#define		CT_TCASE_NONE		0x00		// Clock timer none alarm

#define		CT_TCIF_RST		0x02		// Clock timer interrupt factor generation flag reset

#define		CT_TCAF_RST		0x01		// Clock timer alarm factor generation flag reset
