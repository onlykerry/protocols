/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: wdt.h						*
 *	  This is watch dog timer driver header.			*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *									*
 ************************************************************************/

/* Address definition */
#define		WDT_WRWD_ADDR		0x40170		// Address for watch dog timer wirte protect register
#define		WDT_EWD_ADDR		0x40171		// Address for watch dog timer enable register


/* Bit field definition */
#define		WDT_WRWD_WRT		0x80		// Watch dog timer write protect
#define		WDT_EWD_ENABLE		0x02		// Watch dog timer enable
