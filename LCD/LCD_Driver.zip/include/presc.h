/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: presc.h						*
 *	  This is prescaler driver header file.				*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *									*
 ************************************************************************/

/* Address definition */
#define		PRESC_P8T_ADDR		0x40146		// Address for 8bit timer clock division ratio selection register
#define		PRESC_P16TS0_ADDR	0x40147		// Address for 16bit timer0 clock division ratio selection register
#define		PRESC_P16TS1_ADDR	0x40148		// Address for 16bit timer1 clock division ratio selection register
#define		PRESC_P16TS2_ADDR	0x40149		// Address for 16bit timer2 clock division ratio selection register
#define		PRESC_P16TS3_ADDR	0x4014a		// Address for 16bit timer3 clock division ratio selection register
#define		PRESC_P16TS4_ADDR	0x4014b		// Address for 16bit timer4 clock division ratio selection register
#define		PRESC_P16TS5_ADDR	0x4014c		// Address for 16bit timer5 clock division ratio selection register
#define		PRESC_P8TS0_P8TS1_ADDR	0x4014d		// Address for 8bit timer0,1 clock division ratio selection register
#define		PRESC_P8TS2_P8TS3_ADDR	0x4014e		// Address for 8bit timer2,3 clock division ratio selection register
#define		PRESC_PSAD_ADDR		0x4014f		// Address for A/D converter clock division ratio selection register


/* Bit field definition */
#define		PRESC_CLKDIVH_SEL7	0x70		// Prescaler clock division selection bit 7 (high-order byte)
#define		PRESC_CLKDIVH_SEL6	0x60		// Prescaler clock division selection bit 6 (high-order byte)
#define		PRESC_CLKDIVH_SEL5	0x50		// Prescaler clock division selection bit 5 (high-order byte)
#define		PRESC_CLKDIVH_SEL4	0x40		// Prescaler clock division selection bit 4 (high-order byte)
#define		PRESC_CLKDIVH_SEL3	0x30		// Prescaler clock division selection bit 3 (high-order byte)
#define		PRESC_CLKDIVH_SEL2	0x20		// Prescaler clock division selection bit 2 (high-order byte)
#define		PRESC_CLKDIVH_SEL1	0x10		// Prescaler clock division selection bit 1 (high-order byte)
#define		PRESC_CLKDIVH_SEL0	0x00		// Prescaler clock division selection bit 0 (high-order byte)

#define		PRESC_CLKDIVL_SEL7	0x07		// Prescaler clock division selection bit 7 (low-order byte)
#define		PRESC_CLKDIVL_SEL6	0x06		// Prescaler clock division selection bit 6 (low-order byte)
#define		PRESC_CLKDIVL_SEL5	0x05		// Prescaler clock division selection bit 5 (low-order byte)
#define		PRESC_CLKDIVL_SEL4	0x04		// Prescaler clock division selection bit 4 (low-order byte)
#define		PRESC_CLKDIVL_SEL3	0x03		// Prescaler clock division selection bit 3 (low-order byte)
#define		PRESC_CLKDIVL_SEL2	0x02		// Prescaler clock division selection bit 2 (low-order byte)
#define		PRESC_CLKDIVL_SEL1	0x01		// Prescaler clock division selection bit 1 (low-order byte)
#define		PRESC_CLKDIVL_SEL0	0x00		// Prescaler clock division selection bit 0 (low-order byte)

#define		PRESC_PTONH_ON		0x80		// Prescaler on (high-order byte)
#define		PRESC_PTONH_OFF		0x00		// Prescaler off (high-order byte)

#define		PRESC_PTONL_ON		0x08		// Prescaler on (low-order byte)
#define		PRESC_PTONL_OFF		0x00		// Prescaler off (low-order byte)
