#define		DLCD_ADDR		0x200000
#define		LCDRAM_ADDR		0x00d40
#define		SEGMENT			120
#define		ROW			160
#define		COMMON			160
#define		FRAME			60
#define		CPU_SPEED		23//45
//#define		LCD_SELF		0
//#define		VRAM_CHANGED		1
//#define		DISPLAY_CHANGED		4
#define		LCD_SELF		0x41
#define		VRAM_CHANGED		0x3d
#define		DISPLAY_CHANGED		0x40

//	#define		IO_CFP0_ADDR		0x402d0		// Address for P00-P07 input/output function selection register
//	#define		IO_P0D_ADDR		0x402d1		// Address for P00-P07 input/output port data register
//	#define		IO_IOC0_ADDR		0x402d2		// Address for P00-P07 input/output direction control register
//	#define		IO_CFP1_ADDR		0x402d4		// Address for P10-P16 input/output function selection register
//	#define		IO_P1D_ADDR		0x402d5		// Address for P10-P16 input/output port data register
//	#define		IO_IOC1_ADDR		0x402d6		// Address for P10-P16 input/output direction control register
//	#define		IO_CFP2_ADDR		0x402d8		// Address for P20-P27 input/output function selection register
//	#define		IO_P2D_ADDR		0x402d9		// Address for P20-P27 input/output port data register
//	#define		IO_IOC2_ADDR		0x402da		// Address for P20-P27 input/output direction control register
//	#define		IO_CFP3_ADDR		0x402dc		// Address for P30-P35 input/output function selection register
//	#define		IO_P3D_ADDR		0x402dd		// Address for P30-P35 input/output port data register
//	#define		IO_IOC3_ADDR		0x402de		// Address for P30-P35 input/output direction control register
//	#define		IO_CFEX_ADDR		0x402df		// Address for extended port selection regiser.


//	#define		T16P_CR0A_ADDR		0x48180		// Address for 16bit timer0 compare data A register
//	#define		T16P_CR0B_ADDR		0x48182		// Address for 16bit timer0 compare data B register
//	#define		T16P_TC0_ADDR		0x48184		// Address for 16bit timer0 counter data register
//	#define		T16P_PRUN0_ADDR		0x48186		// Address for 16bit timer0 control register


/* Bit field definition */
//	#define		T16P_SELFM_FM		0x40		// 16bit timer fine mode
//	#define		T16P_SELFM_NOR		0x00		// 16bit timer normal mode
//	
//	#define		T16P_SELCRB_ENA		0x20		// 16bit timer compare buffer enable
//	#define		T16P_SELCRB_DIS		0x00		// 16bit timer compare buffer disable
//	
//	#define		T16P_OUTINV_INV		0x10		// 16bit timer output inverted
//	#define		T16P_OUTINV_NOR		0x00		// 16bit timer output normal
//	
//	#define		T16P_CKSL_EXT		0x08		// 16bit timer input clock selection external
//	#define		T16P_CKSL_INT		0x00		// 16bit timer input clock selection internal
//	
//	#define		T16P_PTM_ON		0x04		// 16bit timer clock output control on
//	#define		T16P_PTM_OFF		0x00		// 16bit timer clock output control off
//	
//	#define		T16P_PSET_ON		0x02		// 16bit timer preset on
//	#define		T16P_PSET_OFF		0x00		// 16bit timer preset off
//	
//	#define		T16P_PRUN_RUN		0x01		// 16bit timer run
//	#define		T16P_PRUN_STOP		0x00		// 16bit timer stop
//
//
//
//
//	#define		PRESC_P16TS0_ADDR	0x40147		// Address for 16bit timer0 clock division ratio selection register
//	#define		PRESC_PSAD_ADDR		0x4014f		// Address for A/D converter clock division ratio selection register
//	
//	
//	/* Bit field definition */
//	#define		PRESC_CLKDIVH_SEL7	0x70		// Prescaler clock division selection bit 7 (high-order byte)
//	#define		PRESC_CLKDIVH_SEL6	0x60		// Prescaler clock division selection bit 6 (high-order byte)
//	#define		PRESC_CLKDIVH_SEL5	0x50		// Prescaler clock division selection bit 5 (high-order byte)
//	#define		PRESC_CLKDIVH_SEL4	0x40		// Prescaler clock division selection bit 4 (high-order byte)
//	#define		PRESC_CLKDIVH_SEL3	0x30		// Prescaler clock division selection bit 3 (high-order byte)
//	#define		PRESC_CLKDIVH_SEL2	0x20		// Prescaler clock division selection bit 2 (high-order byte)
//	#define		PRESC_CLKDIVH_SEL1	0x10		// Prescaler clock division selection bit 1 (high-order byte)
//	#define		PRESC_CLKDIVH_SEL0	0x00		// Prescaler clock division selection bit 0 (high-order byte)
//	
//	#define		PRESC_CLKDIVL_SEL7	0x07		// Prescaler clock division selection bit 7 (low-order byte)
//	#define		PRESC_CLKDIVL_SEL6	0x06		// Prescaler clock division selection bit 6 (low-order byte)
//	#define		PRESC_CLKDIVL_SEL5	0x05		// Prescaler clock division selection bit 5 (low-order byte)
//	#define		PRESC_CLKDIVL_SEL4	0x04		// Prescaler clock division selection bit 4 (low-order byte)
//	#define		PRESC_CLKDIVL_SEL3	0x03		// Prescaler clock division selection bit 3 (low-order byte)
//	#define		PRESC_CLKDIVL_SEL2	0x02		// Prescaler clock division selection bit 2 (low-order byte)
//	#define		PRESC_CLKDIVL_SEL1	0x01		// Prescaler clock division selection bit 1 (low-order byte)
//	#define		PRESC_CLKDIVL_SEL0	0x00		// Prescaler clock division selection bit 0 (low-order byte)
//	
//	#define		PRESC_PTONH_ON		0x80		// Prescaler on (high-order byte)
//	#define		PRESC_PTONH_OFF		0x00		// Prescaler off (high-order byte)
//	
//	#define		PRESC_PTONL_ON		0x08		// Prescaler on (low-order byte)
//	#define		PRESC_PTONL_OFF		0x00		// Prescaler off (low-order byte)
//	
//	#define		INT_P16T0_P16T1_ADDR	0x40266		// Address for 16bit timer0,1 interrupt priority register
//	#define		INT_F16T0_F16T1_ADDR	0x40282		// Address for 16bit timer0,1 interrupt factor flag register
//	#define		INT_F16TC0		0x08		// 16bit timer0 comparison match A interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
//	#define		INT_E16T0_E16T1_ADDR	0x40272		// Address for 16bit timer0,1 interrupt enable register
//	#define		INT_E16TC0		0x08		// 16bit timer0 comparison match A interrupt enable
//	
//	#define		HSDMA_HSD0S_HSD1S_ADDR	0x40298		// Address for HSDMA ch.0, ch.1 trigger setting register
//	#define		HSDMA_HSDMA_ADDR	0x4029a		// Address for HSDMA software trigger register
//	
//	#define		HSDMA_BLKLEN0_TC0L_ADDR	0x48220		// Address for HSDMA ch.0 block size and transfer counter register
//	#define		HSDMA_TC0H_D0DIR_DUALM0_ADDR	0x48222	// Address for HSDMA ch.0 control register
//	#define		HSDMA_S0ADRL_ADDR	0x48224		// Address for HSDMA ch.0 transfer source low address register
//	#define		HSDMA_S0ADRH_ADDR	0x48226		// Address for HSDMA ch.0 transfer source high address register
//	#define		HSDMA_D0ADRL_ADDR	0x48228		// Address for HSDMA ch.0 transfer target low address register
//	#define		HSDMA_D0ADRH_ADDR	0x4822a		// Address for HSDMA ch.0 transfer target high address register
//	#define		HSDMA_HS0EN_ADDR	0x4822c		// Address for HSDMA ch.0 enable register
//	#define		HSDMA_HS0TF_ADDR	0x4822e		// Address for HSDMA ch.0 trigger flag register
//	
//	/* Bit field definition */
//	#define		HSDMA_HSD0_ADEND	0x000c		// HSDMA ch.0 A/D conversion end trigger
//	#define		HSDMA_HSD0_SIF0TX	0x000b		// HSDMA ch.0 serial interface ch0 transfer buffer trigger
//	#define		HSDMA_HSD0_SIF0RX	0x000a		// HSDMA ch.0 serial interface ch0 receive buffer trigger
//	#define		HSDMA_HSD0_T16C4A	0x0009		// HSDMA ch.0 16bit timer4 compare A trigger
//	#define		HSDMA_HSD0_T16C4B	0x0008		// HSDMA ch.0 16bit timer4 compare B trigger
//	#define		HSDMA_HSD0_T16C0A	0x0007		// HSDMA ch.0 16bit timer0 compare A trigger
//	#define		HSDMA_HSD0_T16C0B	0x0006		// HSDMA ch.0 16bit timer0 compare B trigger
//	#define		HSDMA_HSD0_T8TU0	0x0005		// HSDMA ch.0 8bit timer0 input trigger
//	#define		HSDMA_HSD0_PORT4	0x0004		// HSDMA ch.0 port4 input trigger
//	#define		HSDMA_HSD0_PORT0	0x0003		// HSDMA ch.0 port0 input trigger
//	#define		HSDMA_HSD0_K50UP	0x0002		// HSDMA ch.0 K50 input (up edge) trigger
//	#define		HSDMA_HSD0_K50DWN	0x0001		// HSDMA ch.0 K50 input (down edge) trigger
//	#define		HSDMA_HSD0_SOFT		0x0000		// HSDMA ch.0 software trigger
//	
//	#define		HSDMA_HST0		0x01		// HSDMA ch.0 software trigger
//	
//	#define		HSDMA_DUAL_DUAL		0x80000000	// HSDMA dual mode
//	#define		HSDMA_DUAL_SIN		0x00000000	// HSDMA single mode
//	
//	#define		HSDMA_DDIR_WR		0x40000000	// HSDMA memory write
//	#define		HSDMA_DDIR_RD		0x00000000	// HSDMA memory read
//	
//	#define		HSDMA_DINTEN_ENA	0x80000000	// HSDMA interrupt enable
//	#define		HSDMA_DINTEN_DIS	0x00000000	// HSDMA interrupt disable
//	
//	#define		HSDMA_DATSIZE_HALF	0x40000000	// HSDMA half-word
//	#define		HSDMA_DATSIZE_BYTE	0x00000000	// HSDMA byte
//	
//	#define		HSDMA_DMOD_NO		0xc0000000	// HSDMA transfer mode no use
//	#define		HSDMA_DMOD_BLK		0x80000000	// HSDMA transfer mode block transfer
//	#define		HSDMA_DMOD_SEQ		0x40000000	// HSDMA transfer mode sequential transfer
//	#define		HSDMA_DMOD_SIN		0x00000000	// HSDMA transfer mode single transfer
//	
//	#define		HSDMA_INC		0x30000000	// HSDMA address control Inc.(no init)
//	#define		HSDMA_INC_INIT		0x20000000	// HSDMA address control Inc.(init)
//	#define		HSDMA_DEC		0x10000000	// HSDMA address control Dec.(no init)
//	#define		HSDMA_FIX		0x00000000	// HSDMA address control fix
//	
//	#define		HSDMA_HSEN_ENA		0x01		// HSDMA enable
//	#define		HSDMA_HSEN_DIS		0x00		// HSDMA disable
//	
//	#define		HSDMA_HSTF_ON		0x01		// HSDMA trigger flag clear(WR), set(RD)
//	#define		HSDMA_HSTF_OFF		0x00		// HSDMA trigger flag clear(RD)
//	
//	#define		INT_RP0_RHDM_R16T0_ADDR	0x40290		// Address for input port0-3, HSDMA and 16bit timer0 IDMA request register
//	
//	#define		INT_PRIL_LVL7		0x07		// Interrupt priority level 7 (low-order byte)
//	#define		INT_PRIL_LVL6		0x06		// Interrupt priority level 6 (low-order byte)
//	#define		INT_PRIL_LVL5		0x05		// Interrupt priority level 5 (low-order byte)
//	#define		INT_PRIL_LVL4		0x04		// Interrupt priority level 4 (low-order byte)
//	#define		INT_PRIL_LVL3		0x03		// Interrupt priority level 3 (low-order byte)
//	#define		INT_PRIL_LVL2		0x02		// Interrupt priority level 2 (low-order byte)
//	#define		INT_PRIL_LVL1		0x01		// Interrupt priority level 1 (low-order byte)
//	#define		INT_PRIL_LVL0		0x00		// Interrupt priority level 0 (low-order byte)
//	
//	#define		INT_PRIH_LVL7		0x70		// Interrupt priority level 7 (high-order byte)
//	#define		INT_PRIH_LVL6		0x60		// Interrupt priority level 6 (high-order byte)
//	#define		INT_PRIH_LVL5		0x50		// Interrupt priority level 5 (high-order byte)
//	#define		INT_PRIH_LVL4		0x40		// Interrupt priority level 4 (high-order byte)
//	#define		INT_PRIH_LVL3		0x30		// Interrupt priority level 3 (high-order byte)
//	#define		INT_PRIH_LVL2		0x20		// Interrupt priority level 2 (high-order byte)
//	#define		INT_PRIH_LVL1		0x10		// Interrupt priority level 1 (high-order byte)
//	#define		INT_PRIH_LVL0		0x00		// Interrupt priority level 0 (high-order byte)
//	
//	#define		INT_RIDMA_DIS		0x00		// IDMA request is all disable and CPU request is all enable
//	
//	#define		INT_PHSD0_PHSD1_ADDR	0x40263		// Address for hih-speed DMA ch.0,1 interrupt priority register
//	#define		INT_PHSD2_PHSD3_ADDR	0x40264		// Address for hih-speed DMA ch.2,3 interrupt priority register
//	#define		INT_FHDM_FIDM_ADDR	0x40281		// Address for HSDMA ch.0,1 and IDMA interrupt factor flag register
//	
//	#define		INT_FHSDMA1		0x02		// HSDMA ch1 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
//	#define		INT_FHSDMA0		0x01		// HSDMA ch0 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode








































