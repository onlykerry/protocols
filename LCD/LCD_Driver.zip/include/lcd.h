/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 2000				*
 *									*
 *	File name: lcd.h						*
 *	  This is lcd driver header file.				*
 *									*
 *	Revision history						*
 *		2000.04.12	Kurt Shen	Start.			*
 *						Define modify.		*
 *									*
 ************************************************************************/

/* Address definition 
 * refer to P1-44 of sed1374 manual MF1173-01 */
#define		SED1374_R00		0x60FFE0		// Address for SED1374 Revision Code Register
#define		SED1374_R01		0x60FFE1		// Address for SED1374 Mode Register 0
#define		SED1374_R02		0x60FFE2		// Address for SED1374 Mode Register 1
#define		SED1374_R03		0x60FFE3		// Address for SED1374 Mode Register 2
#define		SED1374_R04		0x60FFE4		// Address for SED1374 Horizonal Panel Size Register
#define		SED1374_R05		0x60FFE5		// Address for SED1374 Vertical Panel Size Register (LSB)
#define		SED1374_R06		0x60FFE6		// Address for SED1374 Vertical Panel Size Register (MSB)
#define		SED1374_R07		0x60FFE7		// Address for SED1374 FPLINE Start Position
#define		SED1374_R08		0x60FFE8		// Address for SED1374 Horizonal Non-display Period
#define		SED1374_R09		0x60FFE9		// Address for SED1374 FPFRAMEStart Position
#define		SED1374_R0A		0x60FFEA		// Address for SED1374 Vertical Non-display Period
#define		SED1374_R0B		0x60FFEB		// Address for SED1374 Mod Rate Register
#define		SED1374_R0C		0x60FFEC		// Address for SED1374 Screen 1 Start Address Register (LSB)
#define		SED1374_R0D		0x60FFED		// Address for SED1374 Screen 1 Start Address Register (MSB)
#define		SED1374_R0F		0x60FFEF		// Address for SED1374 Screen 2 Start Address Register (LSB)
#define		SED1374_R10		0x60FFF0		// Address for SED1374 Screen 2 Start Address Register (MSB)
#define		SED1374_R12		0x60FFF2		// Address for SED1374 Memory Address Offset Register
#define		SED1374_R13		0x60FFF3		// Address for SED1374 Screen 1 Vertical Size Register (LSB)
#define		SED1374_R14		0x60FFF4		// Address for SED1374 Screen 1 Vertical Size Register (MSB)
#define		SED1374_R15		0x60FFF5		// Address for SED1374 Look-up Table Address Register
#define		SED1374_R16		0x60FFF6		// Address for SED1374 Look-up Bank Select Register
#define		SED1374_R17		0x60FFF7		// Address for SED1374 Look-up Table Data Register
#define		SED1374_R18		0x60FFF8		// Address for SED1374 GPIO Configuration Control Register
#define		SED1374_R19		0x60FFF9		// Address for SED1374 GPIO Status/Control Register
#define		SED1374_R1A		0x60FFFA		// Address for SED1374 Scratch Pad Register
#define		SED1374_R1B		0x60FFFB		// Address for SED1374 Portrait Mode Register
#define		SED1374_R1C		0x60FFFC		// Address for SED1374 Line Byte Count Register for Portrait Mode


