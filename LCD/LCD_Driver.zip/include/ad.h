/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: ad.h							*
 *	  This is A/D converter driver header.				*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *									*
 ************************************************************************/

/* Address definition */
#define		AD_ADD_ADDR		0x40240		// Address for A/D converted data register
#define		AD_CH_ADDR		0x40242		// Address for A/D conversion channel, A/D conversion trigger selection, A/D conversion mode selection register
#define		AD_CS_ADDR		0x40243		// Address for A/D converter start channel selection, A/D converter end channel selection register
#define		AD_OWE_ADDR		0x40244		// Address for A/D converter overwrite error flag, A/D conversion control/status, A/D enable, conversion-complete flag
#define		AD_ST_ADDR		0x40245		// Address for A/D converter input signal sampling time setup


/* Bit field definition */
#define		AD_MS_CON		0x20		// Continuous mode
#define		AD_MS_NOR		0x00		// Normal mode

#define		AD_TS_ADTRG		0x18		// #ADTRG trigger
#define		AD_TS_T8T0		0x10		// 8bit timer0 underflow trigger
#define		AD_TS_16T0		0x08		// 16bit timer0 underflow trigger
#define		AD_TS_SOFT		0x00		// Software trigger

#define		AD_CE_7			0x38		// A/D convert end channel AD7
#define		AD_CE_6			0x30		// A/D convert end channel AD6
#define		AD_CE_5			0x28		// A/D convert end channel AD5
#define		AD_CE_4			0x20		// A/D convert end channel AD4
#define		AD_CE_3			0x18		// A/D convert end channel AD3
#define		AD_CE_2			0x10		// A/D convert end channel AD2
#define		AD_CE_1			0x08		// A/D convert end channel AD1
#define		AD_CE_0			0x00		// A/D convert end channel AD0

#define		AD_CS_7			0x07		// A/D convert start channel AD7
#define		AD_CS_6			0x06		// A/D convert start channel AD6
#define		AD_CS_5			0x05		// A/D convert start channel AD5
#define		AD_CS_4			0x04		// A/D convert start channel AD4
#define		AD_CS_3			0x03		// A/D convert start channel AD3
#define		AD_CS_2			0x02		// A/D convert start channel AD2
#define		AD_CS_1			0x01		// A/D convert start channel AD1
#define		AD_CS_0			0x00		// A/D convert start channel AD0

#define		AD_ADF_FIN		0x08		// A/D convert finish

#define		AD_ADE_ENA		0x04		// A/D convert enable
#define		AD_ADE_DIS		0x00		// A/D convert disable

#define		AD_ADST_RUN		0x02		// A/D convert run
#define		AD_ADST_STOP		0x00		// A/D convert stop

#define		AD_OWE_ERR		0x01		// A/D convert over write error
#define		AD_OWE_NOERR		0x00		// A/D convert no over write error

#define		AD_ST_9			0x03		// A/D sampling 9 clocks
#define		AD_ST_7			0x02		// A/D sampling 7 clocks
#define		AD_ST_5			0x01		// A/D sampling 5 clocks
#define		AD_ST_3			0x00		// A/D sampling 3 clocks
