/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: int.h						*
 *	  This is interrupt controller driver header file.		*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify.		*
 *									*
 ************************************************************************/

/* Address definition */
#define		INT_PP0_PP1_ADDR	0x40260		// Address for input0,1 port interrupt priority register
#define		INT_PP2_PP3_ADDR	0x40261		// Address for input2,3 port interrupt priority register
#define		INT_PK0_PK1_ADDR	0x40262		// Address for key input0,1 interrupt priority register
#define		INT_PHSD0_PHSD1_ADDR	0x40263		// Address for hih-speed DMA ch.0,1 interrupt priority register
#define		INT_PHSD2_PHSD3_ADDR	0x40264		// Address for hih-speed DMA ch.2,3 interrupt priority register
#define		INT_PDM_ADDR		0x40265		// Address for intelligent interrupt priority register
#define		INT_P16T0_P16T1_ADDR	0x40266		// Address for 16bit timer0,1 interrupt priority register
#define		INT_P16T2_P16T3_ADDR	0x40267		// Address for 16bit timer2,3 interrupt priority register
#define		INT_P16T4_P16T5_ADDR	0x40268		// Address for 16bit timer4,5 interrupt priority register
#define		INT_P8TM_PSIO0_ADDR	0x40269		// Address for 8bit timer and serial interface ch.0 interrupt priority register
#define		INT_PSIO1_PAD_ADDR	0x4026a		// Address for serial interface ch.1 and A/D converter interrupt priority register
#define		INT_PCTM_ADDR		0x4026b		// Address for clock timer interrupt priority register
#define		INT_PP4_PP5_ADDR	0x4026c		// Address for port input4,5 interrupt priority register
#define		INT_PP6_PP7_ADDR	0x4026d		// Address for port input6,7 interrupt priority register

#define		INT_EP0_EK_ADDR		0x40270		// Address for input port0-3 and key input0,1 interrupt enable register
#define		INT_EHDM_EIDM_ADDR	0x40271		// Address for HSDMA ch.0,1 and IDMA interrupt enable register
#define		INT_E16T0_E16T1_ADDR	0x40272		// Address for 16bit timer0,1 interrupt enable register
#define		INT_E16T2_E16T3_ADDR	0x40273		// Address for 16bit timer2,3 interrupt enable register
#define		INT_E16T4_E16T5_ADDR	0x40274		// Address for 16bit timer4,5 interrupt enable register
#define		INT_E8TU_ADDR		0x40275		// Address for 8bit timer0-3 interrupt enable register
#define		INT_ES_ADDR		0x40276		// Address for serial interface ch.0,1 receive error, receive buffer full, transmit buffer empty interrupt enable register
#define		INT_EADE_ECTM_EP4_ADDR	0x40277		// Address for A/D converter clock timer and input port 4-7 interrupt enable register

#define		INT_FP0_FK_ADDR		0x40280		// Address for input port0-3 and key input0,1 interrupt factor flag register
#define		INT_FHDM_FIDM_ADDR	0x40281		// Address for HSDMA ch.0,1 and IDMA interrupt factor flag register
#define		INT_F16T0_F16T1_ADDR	0x40282		// Address for 16bit timer0,1 interrupt factor flag register
#define		INT_F16T2_F16T3_ADDR	0x40283		// Address for 16bit timer2,3 interrupt factor flag register
#define		INT_F16T4_F16T5_ADDR	0x40284		// Address for 16bit timer4,5 interrupt factor flag register
#define		INT_F8TU_ADDR		0x40285		// Address for 8bit timer0-3 interrupt factor flag register
#define		INT_FS_ADDR		0x40286		// Address for serial interface ch.0,1 receive error, receive buffer full, transmit buffer empty interrupt factor flag register
#define		INT_FADE_FCTM_FP4_ADDR	0x40287		// Address for A/D converter clock timer and input port 4-7 interrupt factor flag register

#define		INT_RP0_RHDM_R16T0_ADDR	0x40290		// Address for input port0-3, HSDMA and 16bit timer0 IDMA request register
#define		INT_R16T1_R16T4_ADDR	0x40291		// Address for 16bit timer1-4 IDMA request register
#define		INT_R16T5_R8TU_RS0_ADDR	0x40292		// Address for 16bit timer5, 8bit timer0-3, serial interface ch.0 IDMA request register
#define		INT_RS1_RADE_RP4_ADDR	0x40293		// Address for serial interface ch.1, A/D converter, port input4-7 IDMA request register

#define		INT_RSTONLY_ADDR	0x4029f		// Address for interrupt factor flag reset method selection register


/* Bit field definition */
#define		INT_PRIH_LVL7		0x70		// Interrupt priority level 7 (high-order byte)
#define		INT_PRIH_LVL6		0x60		// Interrupt priority level 6 (high-order byte)
#define		INT_PRIH_LVL5		0x50		// Interrupt priority level 5 (high-order byte)
#define		INT_PRIH_LVL4		0x40		// Interrupt priority level 4 (high-order byte)
#define		INT_PRIH_LVL3		0x30		// Interrupt priority level 3 (high-order byte)
#define		INT_PRIH_LVL2		0x20		// Interrupt priority level 2 (high-order byte)
#define		INT_PRIH_LVL1		0x10		// Interrupt priority level 1 (high-order byte)
#define		INT_PRIH_LVL0		0x00		// Interrupt priority level 0 (high-order byte)

#define		INT_PRIL_LVL7		0x07		// Interrupt priority level 7 (low-order byte)
#define		INT_PRIL_LVL6		0x06		// Interrupt priority level 6 (low-order byte)
#define		INT_PRIL_LVL5		0x05		// Interrupt priority level 5 (low-order byte)
#define		INT_PRIL_LVL4		0x04		// Interrupt priority level 4 (low-order byte)
#define		INT_PRIL_LVL3		0x03		// Interrupt priority level 3 (low-order byte)
#define		INT_PRIL_LVL2		0x02		// Interrupt priority level 2 (low-order byte)
#define		INT_PRIL_LVL1		0x01		// Interrupt priority level 1 (low-order byte)
#define		INT_PRIL_LVL0		0x00		// Interrupt priority level 0 (low-order byte)

#define		INT_EK1			0x20		// Key input1 interrupt enable
#define		INT_EK0			0x10		// Key input0 interrupt enable
#define		INT_EP3			0x08		// Input port3 interrupt enable
#define		INT_EP2			0x04		// Input port2 interrupt enable
#define		INT_EP1			0x02		// Input port1 interrupt enable
#define		INT_EP0			0x01		// Input port0 interrupt enable
#define		INT_EIDMA		0x10		// IDMA interrupt enable
#define		INT_EHSDMA3		0x08		// HSDMA ch.3 interrupt enable
#define		INT_EHSDMA2		0x04		// HSDMA ch.2 interrupt enable
#define		INT_EHSDMA1		0x02		// HSDMA ch.1 interrupt enable
#define		INT_EHSDMA0		0x01		// HSDMA ch.0 interrupt enable
#define		INT_E16TC1		0x80		// 16bit timer1 comparison match A interrupt enable
#define		INT_E16TU1		0x40		// 16bit timer1 comparison match B interrupt enable
#define		INT_E16TC0		0x08		// 16bit timer0 comparison match A interrupt enable
#define		INT_E16TU0		0x04		// 16bit timer0 comparison match B interrupt enable
#define		INT_E16TC3		0x80		// 16bit timer3 comparison match A interrupt enable
#define		INT_E16TU3		0x40		// 16bit timer3 comparison match B interrupt enable
#define		INT_E16TC2		0x08		// 16bit timer2 comparison match A interrupt enable
#define		INT_E16TU2		0x04		// 16bit timer2 comparison match B interrupt enable
#define		INT_E16TC5		0x80		// 16bit timer5 comparison match A interrupt enable
#define		INT_E16TU5		0x40		// 16bit timer5 comparsion match B interrupt enable
#define		INT_E16TC4		0x08		// 16bit timer4 comparison match A interrupt enable
#define		INT_E16TU4		0x04		// 16bit timer4 comparsion match B interrupt enable
#define		INT_E8TU3		0x08		// 8bit timer3 underflow interrupt enable
#define		INT_E8TU2		0x04		// 8bit timer2 underflow interrupt enable
#define		INT_E8TU1		0x02		// 8bit timer1 underflow interrupt enable
#define		INT_E8TU0		0x01		// 8bit timer0 underflow interrupt enable
#define		INT_ESTX1		0x20		// Serial interface ch.1 transmit buffer empty interrupt enable
#define		INT_ESRX1		0x10		// Serial interface ch.1 receive buffer full interrupt enable
#define		INT_ESERR1		0x08		// Serial interface ch.1 receive error interrupt enable
#define		INT_ESTX0		0x04		// Serial interface ch.0 transmit buffer empty interrupt enable
#define		INT_ESRX0		0x02		// Serial interface ch.0 receive buffer full interrupt enable
#define		INT_ESERR0		0x01		// Serial interface ch.0 receive error interrupt enable
#define		INT_EP7			0x20		// Input port7 interrupt enable
#define		INT_EP6			0x10		// Input port6 interrupt enable
#define		INT_EP5			0x08		// Input port5 interrupt enable
#define		INT_EP4			0x04		// Input port4 interrupt enable
#define		INT_ECTM		0x02		// Clock timer interrupt enable
#define		INT_EADE		0x01		// A/D converter convert end interrupt enable
#define		INT_ENABLE_DIS		0x00		// interrupt enable register all bit disable

#define		INT_FK1			0x20		// Key input1 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FK0			0x10		// Key input0 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP3			0x08		// Input port3 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP2			0x04		// Input port2 interupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP1			0x02		// Input port1 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP0			0x01		// Input port0 interrupt ractor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FIDMA		0x10		// IDMA interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FHSDMA3		0x08		// HSDMA ch3 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FHSDMA2		0x04		// HSDMA ch2 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FHSDMA1		0x02		// HSDMA ch1 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FHSDMA0		0x01		// HSDMA ch0 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TC1		0x80		// 16bit timer1 comparison match A interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TU1		0x40		// 16bit timer1 comparsion match B interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TC0		0x08		// 16bit timer0 comparison match A interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TU0		0x04		// 16bit timer0 comparison match B interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TC3		0x80		// 16bit timer3 comparison match A interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TU3		0x40		// 16bit timer3 comparison match B interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TC2		0x08		// 16bit timer2 comparison match A interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TU2		0x04		// 16bit timer2 comparison match B interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TC5		0x80		// 16bit timer5 comparison match A interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TU5		0x40		// 16bit timer5 comparison match B interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TC4		0x08		// 16bit timer4 comparison match A interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F16TU4		0x04		// 16bit timer4 comparison match B interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F8TU3		0x08		// 8bit timer3 underflow interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F8TU2		0x04		// 8bit timer2 underflow interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F8TU1		0x02		// 8bit timer1 underflow interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_F8TU0		0x01		// 8bit timer0 underflow interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FSTX1		0x20		// Serial interface ch.1 transmit buffer empty interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FSRX1		0x10		// Serial interface ch.1 receive buffer full interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FSERR1		0x08		// Serial interface ch.1 receive error interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FSTX0		0x04		// Serial interface ch.0 transmit buffer empty interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FSRX0		0x02		// Serial interface ch.0 receive buffer full interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FSERR0		0x01		// Serial interface ch.0 receive error interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP7			0x20		// Input port7 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP6			0x10		// Input port6 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP5			0x08		// Input port5 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FP4			0x04		// Input port4 interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FCTM		0x02		// Clock timer interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FADE		0x01		// A/D converter convert end interrupt factor is reset in read only mode, interrupt factor is generated in read/write mode
#define		INT_FLAG_RST		0xff		// Interrupt factor flag all reset (interrupt factor flag read only mode)

#define		INT_R16TC0		0x80		// 16bit timer0 comparison match IDMA request
#define		INT_R16TU0		0x40		// 16bit timer0 underflow IDMA request
#define		INT_RHDM1		0x20		// HSDMA DMA ch.1 IDMA request
#define		INT_RHDM0		0x10		// HSDMA DMA ch.0 IDMA request
#define		INT_RP3			0x08		// Input port3 IDMA request
#define		INT_RP2			0x04		// Input port2 IDMA request
#define		INT_RP1			0x02		// Input port1 IDMA request
#define		INT_RP0			0x01		// Input port0 IDMA request
#define		INT_R16TC4		0x08		// 16bit timer4 comparison match A IDMA request
#define		INT_R16TU4		0x04		// 16bit timer4 comparsion match B IDMA request
#define		INT_R16TC3		0x02		// 16bit timer3 comparison match A IDMA request
#define		INT_R16TU3		0x01		// 16bit timer3 comparsion match B IDMA request
#define		INT_R16TC2		0x08		// 16bit timer2 comparison match A IDMA request
#define		INT_R16TU2		0x04		// 16bit timer2 comparsion match B IDMA request
#define		INT_R16TC1		0x02		// 16bit timer1 comparison match A IDMA request
#define		INT_R16TU1		0x01		// 16bit timer1 comparsion match B IDMA request
#define		INT_RSTX0		0x80		// Serial interface ch.0 transmit DBF IDMA request
#define		INT_RSRX0		0x40		// Serial interface ch.0 receive DBF IDMA request
#define		INT_R8TU3		0x20		// 8bit timer3 underflow IDMA request
#define		INT_R8TU2		0x10		// 8bit timer2 underflow IDMA request
#define		INT_R8TU1		0x08		// 8bit timer1 underflow IDMA request
#define		INT_R8TU0		0x04		// 8bit timer0 underflow IDMA request
#define		INT_R16TC5		0x02		// 16bit timer5 comparison match A IDMA request
#define		INT_R16TU5		0x01		// 16bit timer5 comparison match B IDMA request
#define		INT_RP7			0x80		// Input port7 IDMA request
#define		INT_RP6			0x40		// Input port6 IDMA request
#define		INT_RP5			0x20		// Input port5 IDMA request
#define		INT_RP4			0x10		// Input port5 IDMA request
#define		INT_RADE		0x04		// A/D converter convert end IDMA request
#define		INT_RSTX1		0x02		// Serial interface ch.1 transmit buffer empty IDMA request
#define		INT_RSRX1		0x01		// Serial interface ch.1 receive buffer full IDMA request
#define		INT_RIDMA_DIS		0x00		// IDMA request is all disable and CPU request is all enable

#define		INT_DENONLY_RST		0x04		// IDMA enable register set read only mode
#define		INT_DENONLY_RDWR	0x00		// IDMA enable register set read/write mode

#define		INT_IDMAONLY_RST	0x02		// IDMA request register set read only mode
#define		INT_IDMAONLY_RDWR	0x00		// IDMA request register set read/write mode

#define		INT_RSTONLY_RST		0x01		// Interrupt factor flag reset read only mode
#define		INT_RSTONLY_RDWR	0x00		// Interrupt factor flag reset read/write mode
