/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1999				*
 *									*
 *	File name: hsdma.h						*
 *	  This is HSDMA driver header file.				*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *		1999.04.22	T.Mineshima	Define modify.		*
 *									*
 ************************************************************************/

/* Address definition */
#define		HSDMA_HSD0S_HSD1S_ADDR	0x40298		// Address for HSDMA ch.0, ch.1 trigger setting register
#define		HSDMA_HSD2S_HSD3S_ADDR	0x40299		// Address for HSDMA ch.2, ch.3 trigger setting register
#define		HSDMA_HSDMA_ADDR	0x4029a		// Address for HSDMA software trigger register

#define		HSDMA_BLKLEN0_TC0L_ADDR	0x48220		// Address for HSDMA ch.0 block size and transfer counter register
#define		HSDMA_TC0H_D0DIR_DUALM0_ADDR	0x48222	// Address for HSDMA ch.0 control register
#define		HSDMA_S0ADRL_ADDR	0x48224		// Address for HSDMA ch.0 transfer source low address register
#define		HSDMA_S0ADRH_ADDR	0x48226		// Address for HSDMA ch.0 transfer source high address register
#define		HSDMA_D0ADRL_ADDR	0x48228		// Address for HSDMA ch.0 transfer target low address register
#define		HSDMA_D0ADRH_ADDR	0x4822a		// Address for HSDMA ch.0 transfer target high address register
#define		HSDMA_HS0EN_ADDR	0x4822c		// Address for HSDMA ch.0 enable register
#define		HSDMA_HS0TF_ADDR	0x4822e		// Address for HSDMA ch.0 trigger flag register

#define		HSDMA_BLKLEN1_TC1L_ADDR	0x48230		// Address for HSDMA ch.1 block size and transfer counter register
#define		HSDMA_TC1H_D1DIR_DUALM1_ADDR	0x48232	// Address for HSDMA ch.1 control register
#define		HSDMA_S1ADRL_ADDR	0x48234		// Address for HSDMA ch.1 transfer source low address register
#define		HSDMA_S1ADRH_ADDR	0x48236		// Address for HSDMA ch.1 transfer source high address register
#define		HSDMA_D1ADRL_ADDR	0x48238		// Address for HSDMA ch.1 transfer target low address register
#define		HSDMA_D1ADRH_ADDR	0x4823a		// Address for HSDMA ch.1 transfer target high address register
#define		HSDMA_HS1EN_ADDR	0x4823c		// Address for HSDMA ch.1 enable register
#define		HSDMA_HS1TF_ADDR	0x4823e		// Address for HSDMA ch.1 trigger flag register

#define		HSDMA_BLKLEN2_TC2L_ADDR	0x48240		// Address for HSDMA ch.2 block size and transfer counter register
#define		HSDMA_TC2H_D2DIR_DUALM2_ADDR	0x48242	// Address for HSDMA ch.2 control register
#define		HSDMA_S2ADRL_ADDR	0x48244		// Address for HSDMA ch.2 transfer source low address register
#define		HSDMA_S2ADRH_DINT2_ADDR	0x48246		// Address for HSDMA ch.2 transfer source high address register
#define		HSDMA_D2ADRL_ADDR	0x48248		// Address for HSDMA ch.2 transfer target low address register
#define		HSDMA_D2ADRH_ADDR	0x4824a		// Address for HSDMA ch.2 transfer target high address register
#define		HSDMA_HS2EN_ADDR	0x4824c		// Address for HSDMA ch.2 enable register
#define		HSDMA_HS2TF_ADDR	0x4824e		// Address for HSDMA ch.2 trigger flag register

#define		HSDMA_BLKLEN3_TC3L_ADDR	0x48250		// Address for HSDMA ch.3 block size and transfer counter register
#define		HSDMA_TC3H_D3DIR_DUALM3_ADDR	0x48252	// Address for HSDMA ch.3 control register
#define		HSDMA_S3ADRL_ADDR	0x48254		// Address for HSDMA ch.3 transfer source low address register
#define		HSDMA_S3ADRH_ADDR	0x48256		// Address for HSDMA ch.3 transfer source high address register
#define		HSDMA_D3ADRL_ADDR	0x48258		// Address for HSDMA ch.3 transfer target low address register
#define		HSDMA_D3ADRH_ADDR	0x4825a		// Address for HSDMA ch.3 transfer target high address register
#define		HSDMA_HS3EN_ADDR	0x4825c		// Address for HSDMA ch.3 enable register
#define		HSDMA_HS3TF_ADDR	0x4825e		// Address for HSDMA ch.3 trigger flag register


/* Bit field definition */
#define		HSDMA_HSD0_ADEND	0x000c		// HSDMA ch.0 A/D conversion end trigger
#define		HSDMA_HSD0_SIF0TX	0x000b		// HSDMA ch.0 serial interface ch0 transfer buffer trigger
#define		HSDMA_HSD0_SIF0RX	0x000a		// HSDMA ch.0 serial interface ch0 receive buffer trigger
#define		HSDMA_HSD0_T16C4A	0x0009		// HSDMA ch.0 16bit timer4 compare A trigger
#define		HSDMA_HSD0_T16C4B	0x0008		// HSDMA ch.0 16bit timer4 compare B trigger
#define		HSDMA_HSD0_T16C0A	0x0007		// HSDMA ch.0 16bit timer0 compare A trigger
#define		HSDMA_HSD0_T16C0B	0x0006		// HSDMA ch.0 16bit timer0 compare B trigger
#define		HSDMA_HSD0_T8TU0	0x0005		// HSDMA ch.0 8bit timer0 input trigger
#define		HSDMA_HSD0_PORT4	0x0004		// HSDMA ch.0 port4 input trigger
#define		HSDMA_HSD0_PORT0	0x0003		// HSDMA ch.0 port0 input trigger
#define		HSDMA_HSD0_K50UP	0x0002		// HSDMA ch.0 K50 input (up edge) trigger
#define		HSDMA_HSD0_K50DWN	0x0001		// HSDMA ch.0 K50 input (down edge) trigger
#define		HSDMA_HSD0_SOFT		0x0000		// HSDMA ch.0 software trigger

#define		HSDMA_HSD1_ADEND	0x0c00		// HSDMA ch.1 A/D conversion end trigger
#define		HSDMA_HSD1_SIF1TX	0x0b00		// HSDMA ch.1 serial interface ch1 transfer buffer trigger
#define		HSDMA_HSD1_SIF1RX	0x0a00		// HSDMA ch.1 serial interface ch1 receive buffer trigger
#define		HSDMA_HSD1_T16C5A	0x0900		// HSDMA ch.1 16bit timer5 compare A trigger
#define		HSDMA_HSD1_T16C5B	0x0800		// HSDMA ch.1 16bit timer5 compare B trigger
#define		HSDMA_HSD1_T16C1A	0x0700		// HSDMA ch.1 16bit timer1 compare A trigger
#define		HSDMA_HSD1_T16C1B	0x0600		// HSDMA ch.1 16bit timer1 compare B trigger
#define		HSDMA_HSD1_T8TU1	0x0500		// HSDMA ch.1 8bit timer1 input trigger
#define		HSDMA_HSD1_PORT5	0x0400		// HSDMA ch.1 port5 input trigger
#define		HSDMA_HSD1_PORT1	0x0300		// HSDMA ch.1 port1 input trigger
#define		HSDMA_HSD1_K51UP	0x0200		// HSDMA ch.1 K51 input (up edge) trigger
#define		HSDMA_HSD1_K51DWN	0x0100		// HSDMA ch.1 K51 input (down edge) trigger
#define		HSDMA_HSD1_SOFT		0x0000		// HSDMA ch.1 software trigger

#define		HSDMA_HSD2_ADEND	0x000c		// HSDMA ch.2 A/D conversion end trigger
#define		HSDMA_HSD2_SIF2TX	0x000b		// HSDMA ch.2 serial interface ch2 transfer buffer trigger
#define		HSDMA_HSD2_SIF2RX	0x000a		// HSDMA ch.2 serial interface ch2 receive buffer trigger
#define		HSDMA_HSD2_T16C4A	0x0009		// HSDMA ch.2 16bit timer4 compare A trigger
#define		HSDMA_HSD2_T16C4B	0x0008		// HSDMA ch.2 16bit timer4 compare B trigger
#define		HSDMA_HSD2_T16C2A	0x0007		// HSDMA ch.2 16bit timer2 compare A trigger
#define		HSDMA_HSD2_T16C2B	0x0006		// HSDMA ch.2 16bit timer2 compare B trigger
#define		HSDMA_HSD2_T8TU2	0x0005		// HSDMA ch.2 8bit timer2 input trigger
#define		HSDMA_HSD2_PORT6	0x0004		// HSDMA ch.2 port6 input trigger
#define		HSDMA_HSD2_PORT2	0x0003		// HSDMA ch.2 port2 input trigger
#define		HSDMA_HSD2_K53UP	0x0002		// HSDMA ch.2 K53 input (up edge) trigger
#define		HSDMA_HSD2_K53DWN	0x0001		// HSDMA ch.2 K53 input (down edge) trigger
#define		HSDMA_HSD2_SOFT		0x0000		// HSDMA ch.2 software trigger

#define		HSDMA_HSD3_ADEND	0x0c00		// HSDMA ch.3 A/D conversion end trigger
#define		HSDMA_HSD3_SIF3TX	0x0b00		// HSDMA ch.3 serial interface ch3 transfer buffer trigger
#define		HSDMA_HSD3_SIF3RX	0x0a00		// HSDMA ch.3 serial interface ch3 receive buffer trigger
#define		HSDMA_HSD3_T16C5A	0x0900		// HSDMA ch.3 16bit timer5 compare A trigger
#define		HSDMA_HSD3_T16C5B	0x0800		// HSDMA ch.3 16bit timer5 compare B trigger
#define		HSDMA_HSD3_T16C3A	0x0700		// HSDMA ch.3 16bit timer3 compare A trigger
#define		HSDMA_HSD3_T16C3B	0x0600		// HSDMA ch.3 16bit timer3 compare B trigger
#define		HSDMA_HSD3_T8TU3	0x0500		// HSDMA ch.3 8bit timer3 input trigger
#define		HSDMA_HSD3_PORT7	0x0400		// HSDMA ch.3 port7 input trigger
#define		HSDMA_HSD3_PORT3	0x0300		// HSDMA ch.3 port3 input trigger
#define		HSDMA_HSD3_K54UP	0x0200		// HSDMA ch.3 K54 input (up edge) trigger
#define		HSDMA_HSD3_K54DWN	0x0100		// HSDMA ch.3 K54 input (down edge) trigger
#define		HSDMA_HSD3_SOFT		0x0000		// HSDMA ch.3 software trigger

#define		HSDMA_HST3		0x08		// HSDMA ch.3 software trigger
#define		HSDMA_HST2		0x04		// HSDMA ch.2 software trigger
#define		HSDMA_HST1		0x02		// HSDMA ch.1 software trigger
#define		HSDMA_HST0		0x01		// HSDMA ch.0 software trigger

#define		HSDMA_DUAL_DUAL		0x80000000	// HSDMA dual mode
#define		HSDMA_DUAL_SIN		0x00000000	// HSDMA single mode

#define		HSDMA_DDIR_WR		0x40000000	// HSDMA memory write
#define		HSDMA_DDIR_RD		0x00000000	// HSDMA memory read

#define		HSDMA_DINTEN_ENA	0x80000000	// HSDMA interrupt enable
#define		HSDMA_DINTEN_DIS	0x00000000	// HSDMA interrupt disable

#define		HSDMA_DATSIZE_HALF	0x40000000	// HSDMA half-word
#define		HSDMA_DATSIZE_BYTE	0x00000000	// HSDMA byte

#define		HSDMA_DMOD_NO		0xc0000000	// HSDMA transfer mode no use
#define		HSDMA_DMOD_BLK		0x80000000	// HSDMA transfer mode block transfer
#define		HSDMA_DMOD_SEQ		0x40000000	// HSDMA transfer mode sequential transfer
#define		HSDMA_DMOD_SIN		0x00000000	// HSDMA transfer mode single transfer

#define		HSDMA_INC		0x30000000	// HSDMA address control Inc.(no init)
#define		HSDMA_INC_INIT		0x20000000	// HSDMA address control Inc.(init)
#define		HSDMA_DEC		0x10000000	// HSDMA address control Dec.(no init)
#define		HSDMA_FIX		0x00000000	// HSDMA address control fix

#define		HSDMA_HSEN_ENA		0x01		// HSDMA enable
#define		HSDMA_HSEN_DIS		0x00		// HSDMA disable

#define		HSDMA_HSTF_ON		0x01		// HSDMA trigger flag clear(WR), set(RD)
#define		HSDMA_HSTF_OFF		0x00		// HSDMA trigger flag clear(RD)
