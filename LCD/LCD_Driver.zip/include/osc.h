/************************************************************************
 *									*
 *	Copyright (C) SEIKO EPSON CORP. 1997 - 1998			*
 *									*
 *	File name: osc.h						*
 *	  This is OSC driver header file.				*
 *									*
 *	Revision history						*
 *		1999.03.11	T.Mineshima	Start.			*
 *									*
 ************************************************************************/

/* Address definition */
#define		OSC_SOSC_ADDR		0x40180		// Address for low-speed (OSC1) oscillation on/off, high-speed (OSC3) oscillation on/off, CPU operation clock switch, prescaler on/off control, system clock division ratio selection register (power control register)
#define		OSC_PSCDT0_ADDR		0x40181		// Address for prescaler clock selection register
#define		OSC_PF1ON_ADDR		0x40190		// Address for OSC1 external output control, OSC3-stabilize waiting function, HALT clock option register (clock control register)
#define		OSC_CLGP_ADDR		0x4019e		// Address for power control register protect flag register


/* Bit field definition */
#define		OSC_CLKDT_18		0xc0		// CPU clock 1/8
#define		OSC_CLKDT_14		0x80		// CPU clock 1/4
#define		OSC_CLKDT_12		0x40		// CPU clock 1/2
#define		OSC_CLKDT_11		0x00		// CPU clock 1/1

#define		OSC_PSCON_ON		0x20		// Prescaler control on
#define		OSC_PSCON_OFF		0x00		// Prescaler control off

#define		OSC_CLKCHG_OSC3		0x04		// OSC3 clock
#define		OSC_CLKCHG_OSC1		0x00		// OSC1 clock

#define		OSC_SOSC3_ON		0x02		// OSC3 on
#define		OSC_SOSC3_OFF		0x00		// OSC3 off

#define		OSC_SOSC1_ON		0x01		// OSC1 on
#define		OSC_SOSC1_OFF		0x00		// OSC1 off

#define		OSC_PSCDT0_OSC1		0x01		// OSC1
#define		OSC_PSCDT0_OSC3		0x00		// OSC3/PLL

#define		OSC_HALT2OP_ON		0x04		// HALT clock option on
#define		OSC_HALT2OP_OFF		0x04		// HALT clock option off

#define		OSC_8T1ON_OFF		0x04		// OSC3-stabilize waiting function off
#define		OSC_8T1ON_ON		0x00		// OSC3-stabilize waiting function on

#define		OSC_PF1ON_ON		0x01		// OSC1 external output on
#define		OSC_PF1ON_OFF		0x00		// OSC1 external output off

#define		OSC_CLGP_ENA		0x96		// Power control register protect off, write enable
