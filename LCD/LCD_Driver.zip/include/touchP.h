#define AD_DATA_NUM	6	//x_add[AD_DATA_NUM]
#define TIMER8_2	43	//8 bit timer reload data
#define MARGIN		20	// the margin of adjust point to the edge of lcd

//#define NO_AD_INT	0	//ad_int, if in waiting pendown situation,ad_int is NO_AD_INT
//#define AD1_INT		1	//ad_int
#define GET_ADD		2	//ad_int
//#define AD3_INT		3	//ad_int,if pendown occurs change ad_int from AD1_INT to AD3_INT
//#define ERR_AD		4	//ad_int
#define AD_KEEP		5	//ad_int. continuously AD

#define UNFINISHED 0	//ad3
#define FINISHED 1	//ad3

#define TP_ADD_MIN	0x50
#define TP_ADD_MAX	0x3df
