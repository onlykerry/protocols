#define FLASH_LOCKOPRCMD	0x60
#define FLASH_UNLOCKCMD		0xD0
#define FLASH_LOCKCMD		0x01
#define FLASH_LOCKDOWNCMD	0x2F

#define FLASH_ER_PG_CONFM	0xD0//		/* Erase confirm command */
#define FLASH_ERASECMD		0x20//		/* Erase command	*/
#define FLASH_SUSPENDCMD	0xB0		/* Program/Erase suspend command */
#define	FLASH_RDARRAY		0xFF		/* Read array command                    */
#define FLASH_RDSTATUS		0x70		/* Read Status Register command            */
#define FLASH_PROGRAMECMD	0x40//		/* Word Write Programe command              */
#define FLASH_IDRDCOMM		0x90		/* Inteligent Identifier command            */
#define	FLASH_STATCLR		0x50		/* Clear Status Register command            */
#define FLASH_SYSADDR		0x8000000//0x0c00000	/* This constant can be initialized to any */
						/*   address within the memory map of the  */
						/*   target  and is alterable depending on */
						/*   the system architecture               */
#define FLASH_MFGRADDR		0x8000000//0x0c00000        /* Address "0" for the target ...alterable  */
                		              	/*   depending on the system architecture   */
#define FLASH_DEVICADD		0x8000002//0X0C00001        /* Address "1" for the target ...alterable  */
                      	        		/*   depending on the system architecture   */
#define FLASH_INTELID		0x0089    	/* Manufacturer ID for Intel devices        */
#define FLASH_DVCID		0x8891//88c2    	/* This should be modified for the current device   */
#define USECTOR			39
                                 	
#define FLASH_UNLOCK	0
#define FLASH_LOCK	1
#define FLASH_LOCKDOWN	2
#define FLASH_ADDR_ERRO	3

#define OK	0
#define ERR	1
/***       28F160C3-T,   88C2  */
/*       28F160C3-B,   88C3  */