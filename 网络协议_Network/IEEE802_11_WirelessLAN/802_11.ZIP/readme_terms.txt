
THESE ARE THE TERMS OF USE YOU AGREED TO WHEN YOU DOWNLOADED THE PDF FILE:


Terms of Use for Individual IEEE Standards Publications Delivered in Electronic Form


THE INSTITUTE OF ELECTRICAL AND ELECTRONICS ENGINEERS,INC. IS WILLING
TO DELIVER THIS IEEE STANDARDS PUBLICATION TO THE PURCHASER ("YOU") IN
ELECTRONIC FORM ON THE CONDITION THAT YOU ACCEPT THE FOLLOWING TERMS OF
USE.


READ THE TERMS OF USE CAREFULLY. BY SELECTING THE  "ACCEPT" BUTTON AT
THE BOTTOM OF THIS PAGE, YOU AGREE TO BE BOUND BY THESE TERMS OF USE.


IF YOU SELECT  "DO NOT ACCEPT" THE FILE TRANSFER FOR THIS STANDARDS
PUBLICATION WILL NOT CONTINUE AND YOU WILL

RECEIVE FURTHER INSTRUCTIONS  ON HOW TO PROCEED.


COPYRIGHT

The Institute of Electrical and Electronics Engineers, Inc. ("IEEE")
owns the copyright to this IEEE Standards publication in all forms of
media. Copyright in the text retrieved, displayed or output from this
IEEE Standards publication is owned by IEEE and is protected by the
copyright laws of the United States and by international treaties. The
IEEE reserves all its rights in this IEEE Standards publication. 


TERMS OF USE

You may retrieve, down-load and print one (1) copy of this IEEE
Standards publication for your personal use. You may retain one (1)
additional copy of this IEEE Standards publication as your personal
archive copy.  You may not copy this IEEE Standards publication for any
other purpose, unless explicitly allowed herein or except as allowed
under the copyright laws of the United States of America (U.S.C. Title
17) or applicable international treaties.  You may not prepare and
distribute copies of this IEEE Standards

publication or derivative works based on this IEEE Standards
publication, in any form, to any other persons or entities without an
appropriate license or prior written permission from the IEEE. Requests
for permission to reprint portions of this IEEE Standards

publication or requests for a license to reproduce this IEEE Standards
publication, in any form, must be submitted in writing to:
	Administrator, Intellectual Property Rights
	IEEE Standards Department, 445 Hoes Lane, P.O. Box, 1331, 
	Piscataway, NJ 08855-1331, USA. 


LIMITED WARRANTIES & LIMITATION OF REMEDIES

The IEEE has approved and published this Standards publication in
accordance with its established bylaws and operations procedures. THE
IEEE  MAKES NO GUARANTIES OR WARRANTIES AS TO THE RESULTS TO BE
OBTAINED FROM PURCHASING AND USING THIS STANDARDS PUBLICATION IN
ELECTRONIC FORM AND IS NOT RESPONSIBLE FOR PROBLEMS IN THE DELIVERY OF
THIS STANDARDS PUBLICATION THAT ARE BEYOND ITS CONTROL. If you do not
receive this Standards Publication as requested, or if there is a
problem with the transmission and you are unable to receive this
Standards Publication in electronic form as requested, you should
contact the <underline>IEEE Standards Systems/Network Staff</underline>
who will make reasonable efforts to remedy the problem and provide the
requested Standards publication. 


I , the Purchaser of this IEEE Standards publication, acknowledge that
I have read and fully understand the foregoing information and agree to
abide by these Terms of Use. 


		ACCEPT		DO NOT ACCEPT


