#include <stdio.h>

int
main(int argc, char **argv)
{
    int i,j,chr,val,nbits;

    puts("static octet ch_flags[256] = {");
    for (i = 0; i < 256; i += 8) {
	putchar('\t');
	for (j = 0; j < 8; j++) {
	    chr = i+j;
	    val = (chr & 0x80) ? 8 : 4;
	    if (chr >= 32)
		val |= 0x10;
	    if ((chr & 0x7F) >= 32)
		val |= 0x20;
	    if (chr == 0x7F || chr == 0xFF)
		val |= 0x40;
	    nbits = 0;
	    while (chr != 0)
		nbits++, chr &= chr-1;
	    printf("0x%02X,%c",val | ((nbits&1) ? 2 : 1),
		   j==7?'\n':' ');
	}
    }
    puts("};");
    return 0;
}
