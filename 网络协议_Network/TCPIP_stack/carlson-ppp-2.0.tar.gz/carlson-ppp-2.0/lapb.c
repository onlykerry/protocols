/*
 * This code shows a simple LAP-B implementation for use with PPP
 * Numbered Mode (RFC 1663).  It assumes a system interface like the
 * ahdlc.c module provided with this example.
 *
 * It is also assumed that packets sent and received pass through
 * callback functions and are simple buffers.  Buffers are acquired
 * through "buffer_fetch" and released back to the system by a
 * "buffer_release" function.
 *
 * The user of this module is provided a simple queue interface using
 * lapp_send() and lapb_receive().
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code is
 * also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1999 by James Carlson and Working Code.
 */

#include <stdlib.h>
#include <assert.h>

#include "sysdep.h"
#include "lapb.h"

/*
 * Theoretically, at least, the operation mode (basic, extended, or
 * super) could be negotiated and could be different in each direction
 * as could be the window size.  This is not done in standard LAP-B.
 * This code optionally supports both features.
 */

#ifdef DEBUG_LAPB
#include <stdio.h>
#define DBG(x)	printf x
#else
#define DBG(x)	/* */
#endif

enum lapb_phase {
    phQueue, phQueueDrain, phInitial, phData, phDisconnecting,
    phDisconnected
};

#ifdef DEBUG_LAPB
static const char *phstring[] = {
    "queue", "qdrain", "initial", "data", "disconnecting",
    "disconnected",
};
#endif

#define DEF_T1PERIOD	1000
#define DEF_T2MAX	5

/* Retransmission and reassembly queues */
struct lapb_queue {
    octet *buffer;
    uint16 length;
    uint16 qflags;
};

#define QF_SENDING	0x0001		/* Frame is being sent */
#define QF_ACKED	0x0002		/* Frame has been acked */
#define QF_SEND		0x0004		/* Needs to be sent */

struct lapb_state {
    void *userstate;
    void (*rcvnonempty)(void *userstate);
    void (*xmthasroom)(void *userstate);
    enum lapb_phase phase;
    int t1period;		/* Length of timer T1 in milliseconds */
    uint16 t2max,t2ctr;		/* T2; max T1 timeouts */
    octet mode;			/* 0=basic, 1=extended, 2=super */
    octet cmdaddr;		/* Address to use in sending commands */
    octet crabit;		/* Bit for sending responses or rcv command */
    octet flags;		/* Configuration flags */
    uint16 vs,vr;		/* Send/receive state variables */
    uint16 lastnr;		/* Last received NR value (ack number) */
    uint16 txqsize;		/* Transmit sequence number modulus */
    uint16 rxqsize;		/* Receive sequence number modulus */
    uint16 txkval;		/* Window size "k" for transmit */
    uint16 rxkval;		/* Window size "k" for receive */
    uint16 tsending;		/* Item currently being sent */
    uint16 tnext;		/* Next item to send */
    uint16 rtail,rhead;		/* Queue pointers (modulo k) */
    uint16 ttail,thead;		/* Queue pointers (modulo k) */
    uint16 statflag;		/* Status code transmission flags */
    octet *discarding;		/* Buffer to discard */
    struct lapb_queue txpend;	/* Pending transmit */
    struct lapb_queue *rxq;	/* Receive queue (length k+1) */
    struct lapb_queue *txq;	/* Transmit queue (length k+1) */
};

/* Test if given NS value is inside the window. */
#define WINDOWOFFS(ns,vr,mod)	(((ns)+(mod)-(vr))%(mod))
#define INWINDOW(ns,vr,mod,k)	(WINDOWOFFS(ns,vr,mod) < (k))

#define ALLSET(fl,bits)	(((fl)&(bits)) == (bits))

/*
 * Command and response definitions.  CRU_SABM is for basic (mod 8)
 * mode only, CRU_SABME is for extended (mod 128) mode only, and
 * CRU_SM is for super (mod 32768) mode only.  CRU_SREJ is not used
 * with basic mode.  All other commands and responses are always
 * valid.
 */
#define CRI_I		0x00	/* Information; command only */
#define CRS_RR		0x01	/* Receive Ready */
#define CRS_RNR		0x05	/* Receive Not Ready */
#define CRS_REJ		0x09	/* Reject */
#define CRS_SREJ	0x0D	/* Selective Reject; response only */
#define CRU_SABM	0x2F	/* Set Asynchronous Balanced Mode; cmd only */
#define CRU_SABME	0x6F	/* Set Asynchronous Balanced Mode Extended */
#define CRU_SM		0xC3	/* Set Mode; command only */
#define CRU_DISC	0x43	/* Disconnect; command only */
#define CRU_DM		0x0F	/* Disconnect Mode; response only */
#define CRU_UA		0x63	/* Unnumbered Acknowledgement; response only */
#define CRU_FRMR	0x87	/* Frame Reject -- response only */

#define IS_I_TYPE(x)	(((x)&1) == 0)
#define IS_S_TYPE(x)	(((x)&3) == 1)
#define IS_U_TYPE(x)	(((x)&3) == 3)
#define ITYPE_MASK	0x01
#define STYPE_MASK	0x0F
#define UTYPE_MASK	0xEF

/* Internal flags */
#define LBF_PEERREADY	0x10	/* Peer is ready for receive */
#define LBF_IMREADY	0x20	/* I'm ready to receive (internal) */
#define LBF_PERMISSIVE	0x40	/* Permissive set-mode operation */
#define LBF_USERREADY	0x80	/* User is ready */

/* Flags for statflag */
#define STF_NEEDSTATUS	0x0001	/* Need to transmit status frame */
#define STF_PFBIT	0x0002	/* Status frame should have PF bit set */
#define STF_XMITRUN	0x0004	/* Transmit is running */
#define STF_NEEDUA	0x0008	/* Need to transmit UA frame */
#define STF_UAFBIT	0x0010	/* UA frame should have F bit set */
#define STF_NEEDSABM	0x0020	/* Need to send SABM now */
#define STF_XMITFULL	0x0040	/* User filled transmit queue */
#define STF_NEEDREJ	0x0080	/* Sequence number error detected */
#define STF_NEEDVR	0x0100	/* Need to give new VR number to peer */
#define STF_T1RUNNING	0x0200	/* Timer T1 is running */
#define STF_NEEDDM	0x0400	/* Need to send DM */
#define STF_NEEDDISC	0x0800	/* Need to send DISC */

static int mode_modulus[] = { 8, 128, 32768, 32768 };

static void t1handler(void *state);

static void
init_values(struct lapb_state *ls, struct lapb_queue *qp,
	    int mode, int txkval, int rxkval, int flags)
{
    memset(ls,'\0',sizeof(*ls));
    memset(qp,'\0',(txkval+rxkval+2)*sizeof(struct lapb_queue));
    ls->rxq = qp;
    ls->txq = qp+rxkval+1;
    if (mode == MODE_PERMISSIVE)
	ls->mode = MODE_SUPER, flags |= LBF_PERMISSIVE;
    else
	ls->mode = mode;
    if (mode == MODE_SUPER)
	flags |= LBF_TXSREJ | LBF_RXSREJ;
    else if (mode == MODE_BASIC)
	flags &= ~LBF_TXSREJ & ~LBF_RXSREJ;
    if (flags & LBF_MULTILINK) {
	ls->cmdaddr = 0x0F;
	ls->crabit = 0x08;
    } else {
	ls->cmdaddr = 0x03;
	ls->crabit = 0x02;
    }
    ls->flags = flags | LBF_PEERREADY | LBF_IMREADY | LBF_USERREADY;
    if (flags & LBF_ISDTE)
	ls->cmdaddr ^= ls->crabit;
    ls->phase = phQueue;
    ls->txkval = txkval;
    ls->rxkval = rxkval;
    ls->txqsize = ls->rxqsize = mode_modulus[mode];
}

/*
 * Create a LAP-B session in plain queue mode.  Returns a state
 * structure pointer.
 */
void *
lapb_create(int mode, int txkval, int rxkval, int t1period, int t2max,
	    int flags)
{
    struct lapb_state *ls;
    int len;
    struct lapb_queue *qp;

    if (mode < MODE_BASIC || mode > MODE_PERMISSIVE)
	return NULL;
    len = mode_modulus[mode];
    if (txkval >= len || rxkval >= len)
	return NULL;

    if (txkval <= 0)
	txkval = 1;
    if (rxkval <= 0)
	rxkval = 1;

    ls = (struct lapb_state *)malloc(sizeof(*ls));
    if (ls == NULL)
	return NULL;

    len = (txkval+rxkval+2)*sizeof(struct lapb_queue);
    qp = (struct lapb_queue *)malloc(len);
    if (qp == NULL) {
	free(ls);
	return NULL;
    }

    init_values(ls,qp,mode,txkval,rxkval,flags);
    if (t1period <= 0)
	t1period = DEF_T1PERIOD;
    ls->t1period = t1period;
    if (t2max <= 0)
	t2max = DEF_T2MAX;
    ls->t2max = t2max;
    return (void *)ls;
}

static void
free_all_packets(struct lapb_state *ls)
{
    int idx;

    DBG(("freeing all packets on state %p\n",ls));
    if (!(ls->txpend.qflags & QF_SENDING) && ls->txpend.buffer != NULL) {
	buffer_release(ls->txpend.buffer);
	ls->txpend.buffer = NULL;
	ls->txpend.qflags = 0;
    }

    /* Note that "k" in the LAP-B spec is modulus - 1, thus use <= here. */
    for (idx = 0; idx <= ls->txkval; idx++) {
	if (ls->txq[idx].qflags & QF_SENDING) {
	    ls->txpend = ls->txq[idx];
	    DBG(("moved packet from TX queue to pending.\n"));
	} else if (ls->txq[idx].buffer != NULL)
	    buffer_release(ls->txq[idx].buffer);
	ls->txq[idx].buffer = NULL;
	ls->txq[idx].qflags = 0;
    }

    for (idx = 0; idx <= ls->rxkval; idx++)
	if (ls->rxq[idx].buffer != NULL) {
	    buffer_release(ls->rxq[idx].buffer);
	    ls->rxq[idx].buffer = NULL;
	    ls->rxq[idx].qflags = 0;
	}

    ls->rtail = ls->rhead = 0;
    ls->ttail = ls->thead = 0;
}

void
lapb_destroy(void *statep)
{
    struct lapb_state *ls = (struct lapb_state *)statep;

    DBG(("destroying state structure %p\n",ls));
    if (ls != NULL) {
	free_all_packets(ls);
	free(ls->rxq);
	free(ls);
    }
}

void
lapb_handlers(void *statep, void *userstate,
	      void (*rcvnonempty)(void *userstate),
	      void (*xmthasroom)(void *userstate))
{
    struct lapb_state *ls = (struct lapb_state *)statep;

    DBG(("set handlers on %p\n",ls));
    ls->userstate = userstate;
    ls->rcvnonempty = rcvnonempty;
    ls->xmthasroom = xmthasroom;
}

/*
 * This is called when we need an upcall from the HDLC driver below
 * us.  As long as he's been told, we don't need to tell him again.
 */
static void
need_transmit(struct lapb_state *ls, int flags)
{
    ls->statflag |= flags;
    if (!(ls->statflag & STF_XMITRUN)) {
	ls->statflag |= STF_XMITRUN;
	enable_transmit();
    }
}

/*
 * Handle received NR value.  As with TCP this acks all transmitted
 * frames up through NR-1.
 */
static void
handle_nr(struct lapb_state *ls, int nr)
{
    int lastnr,tptr,tptrn,tnext;

    /* Check for duplicate */
    lastnr = ls->lastnr;
    if (lastnr == nr)
	return;

    /* Cancel T1 timeout */
    if (ls->statflag & STF_T1RUNNING) {
	ls->t2ctr = 0;
	ls->statflag &= ~STF_T1RUNNING;
	untimeout(t1handler,(void *)ls);
    }
    ls->lastnr = nr;
    DBG(("handle nr %d on %p; lastnr %d\n",nr,ls,lastnr));
    tptr = ls->ttail;
    tnext = ls->tnext;

    /* Loop through acked buffers and free them. */
    while (lastnr != nr) {
	/* Special handling in case HDLC is busy with this frame. */
	if (ls->txq[tptr].qflags & QF_SENDING) {
	    DBG(("buffer %p in transit marked as acked; queue position %d\n",
		 ls->txq[tptr].buffer,tptr));
	    ls->discarding = ls->txq[tptr].buffer;
	} else if (ls->txq[tptr].buffer != NULL) {
	    DBG(("freeing buffer on ack; queue position %d\n",tptr));
	    buffer_release(ls->txq[tptr].buffer);
	}
	ls->txq[tptr].buffer = NULL;
	ls->txq[tptr].qflags = 0;
	if ((tptrn = tptr+1) > ls->txkval)
	    tptrn = 0;
	if (tptr == tnext)
	    tnext = tptrn;
	tptr = tptrn;
	lastnr = (lastnr + 1) % ls->txqsize;
    }
    ls->tnext = tnext;

    /*
     * If we now have more transmit room and the sender above us had
     * stopped because we ran out of room, then give him an upcall
     * to tell him that he can start again.
     */
    if (tptr != ls->ttail) {
	ls->ttail = tptr;
	if (ls->statflag & STF_XMITFULL) {
	    ls->statflag &= ~STF_XMITFULL;
	    if (ls->phase == phData && ls->xmthasroom != NULL)
		(*ls->xmthasroom)(ls->userstate);
	    else
		DBG(("no room signaled; phase %s\n",phstring[ls->phase]));
	}
    }
}

/*
 * Mark given sequence numbers in transmit queue for retransmission.
 *
 * This is intentionally not highly optimized.
 */
static void
mark_retransmit(struct lapb_state *ls, int nrstart, int nrend)
{
    int tptr,tnext,lastnr;

    /* Loop through packets, find matches, and retransmit those */
    lastnr = ls->lastnr;
    tnext = ls->tnext;
    tptr = ls->ttail;
    while (tptr != ls->thead) {
	if (tptr == tnext)
	    tnext = -1;
	if (nrstart < 0 || lastnr == nrstart) {
	    if (nrstart >= 0 && tnext >= 0)
		ls->tnext = tptr;
	    nrstart = -1;
	    if (ls->txq[tptr].buffer == NULL)
		DBG(("ignoring retransmit request of unsent NS %d\n",lastnr));
	    else {
		DBG(("marked retransmit of NS %d\n",lastnr));
		ls->txq[tptr].qflags |= QF_SEND;
		need_transmit(ls,0);
	    }
	}
	if (lastnr == nrend)
	    break;
	if (++tptr > ls->txkval)
	    tptr = 0;
	if (++lastnr >= ls->txqsize)
	    lastnr = 0;
    }
}

/*
 * This is called by the operating system dependent timer library.
 * It handles a time-out on T1.
 */
static void
t1handler(void *state)
{
    struct lapb_state *ls = (struct lapb_state *)state;
    int ptr;

    DBG(("T1 timeout on %p\n",ls));
    ls->statflag &= ~STF_T1RUNNING;
    if (++ls->t2ctr >= ls->t2max) {
	ls->phase = phDisconnected;
	DBG(("T2 expired; disconnected.\n"));
    }
    switch (ls->phase) {
    case phInitial:
	DBG(("timeout requesting SABM\n"));
	need_transmit(ls,STF_NEEDSABM);
	break;
    case phData:
	/* Retransmit on timeout. */
	for (ptr = ls->rtail; ptr != ls->rhead;) {
	    if (ls->rxq[ptr].buffer == NULL) {
		DBG(("timeout requesting REJ/SREJ\n"));
		need_transmit(ls,STF_NEEDREJ);
		break;
	    }
	    if (++ptr > ls->rxkval)
		ptr = 0;
	}
	if (ls->thead != ls->ttail) {
	    ptr = (ls->lastnr+ls->tnext-ls->ttail+2*ls->txqsize-1)%ls->txqsize;
	    DBG(("timeout requesting I retransmit of NS %d\n",ptr));
	    mark_retransmit(ls,ptr,ptr);
	}
	break;
    case phDisconnecting:
	need_transmit(ls,STF_NEEDDM);
	DBG(("timeout requesting DM\n"));
	break;
    default:
	return;
    }
}

/*
 * The application should call this routine if it wishes to block or
 * unblock input.  The current state (0 for blocked, 1 for unblocked)
 * is returned.  If the flag is <0, then the current state is not
 * modified.
 */
int
lapb_ready_state(void *statep, int flag)
{
    struct lapb_state *ls = (struct lapb_state *)statep;

    if (flag == 0)
	ls->flags &= ~LBF_USERREADY;
    else if (flag > 0)
	ls->flags |= LBF_USERREADY;
    return (ls->flags & LBF_USERREADY) ? 1 : 0;
}

/*
 * This routine is called from the function that receives data from
 * the HDLC receive queue.  It processes the data according to the
 * LAP-B protocol and sends output frames to the tx_queue for output
 * processing by the HDLC transmit routines.
 */
void
lapb_input(void *statep, octet *buffer, int count)
{
    struct lapb_state *ls = (struct lapb_state *)statep;
    int iscmd,ns,nr,crcode,pfbit,errbits,ilen,woffs;
    octet *bp;

    if (ls == NULL || buffer == NULL || count < 2) {
	/* Error; missing address and control */
	if (buffer != NULL)
	    buffer_release(buffer);
	return;
    }

    if (ls->phase == phQueue)
	goto simple_queue;

    /* First examine the address */
    if (buffer[0] == ls->cmdaddr) {
	/* This is a response from the peer */
	iscmd = 0;
    } else if (buffer[0] == (ls->cmdaddr^ls->crabit)) {
	/* This is a command from the peer */
	iscmd = 1;
    } else if (buffer[0] == 0xFF && buffer[1] == 0x03) {
	/* This is a non-LAP-B PPP frame; peer may have restarted. */
	if (ls->phase != phQueue) {
	    ls->phase = phQueue;
	    free_all_packets(ls);
	}
    simple_queue:
	DBG(("simple queue on %p\n",ls));
	woffs = ls->rhead;
	nr = woffs + 1;
	if (nr > ls->rxkval)
	    nr = 0;
	if (nr == ls->rtail)
	    buffer_release(buffer);
	else {
	    ls->rxq[woffs].buffer = buffer;
	    ls->rxq[woffs].length = count;
	    ls->rhead = nr;
	    if (ls->rcvnonempty != NULL &&
		woffs == ls->rtail)
		(*ls->rcvnonempty)(ls->userstate);
	}
	return;
    } else {
	/* Error; bad address. */
	buffer_release(buffer);
	return;
    }

    /* Next, extract the command/response code and sequence. */
    DBG(("process input on %p\n",ls));
    ns = nr = 0;	/* quiet down compiler */
    crcode = buffer[1];
    ilen = 2;
    if (IS_U_TYPE(crcode)) {
	pfbit = (crcode & 0x10)>>4;
    } else switch (ls->mode) {
    case MODE_BASIC:
	ns = (crcode & 0x0E)>>1;
	pfbit = (crcode & 0x10)>>4;
	nr = (crcode & 0xE0)>>5;
	break;
    case MODE_EXTENDED:
	if (count < 3) {
	    errbits = 3;
	    goto frmr_handler;
	}
	ns = (crcode & 0xFE)>>1;
	pfbit = buffer[2] & 1;
	nr = (buffer[2] & 0xFE)>>1;
	ilen = 3;
	break;
    case MODE_SUPER:
	if (count < 5) {
	    errbits = 3;
	    goto frmr_handler;
	}
	ns = ((crcode & 0xFE)>>1) | (buffer[2]<<7);
	pfbit = buffer[3] & 1;
	nr = ((buffer[3] & 0xFE)>>1) | (buffer[4]<<7);
	ilen = 5;
	break;
    default:
	/* This can't happen. */
	buffer_release(buffer);
	return;
    }
    if (IS_I_TYPE(crcode))
	crcode &= ITYPE_MASK;
    else if (IS_S_TYPE(crcode))
	crcode &= STYPE_MASK;
     else
	crcode &= UTYPE_MASK;

    /* Switch out on type of received frame. */
    DBG(("code %d, nr %d, ns %d\n",crcode,nr,ns));
    errbits = 0;
    switch (crcode) {
    case CRI_I:
	DBG(("received I frame\n"));
	/* Still setting up; silent discard. */
	if (ls->phase == phInitial)
	    break;
	if (!iscmd) {
	    errbits = 1;
	    break;
	}
	handle_nr(ls,nr);
	/*
	 * Note:  LAP-B assumes that packets cannot be reordered on the
	 * link.  For that reason, it is safe to assume that a sequence
	 * number error implies a lost packet.
	 */
	if (INWINDOW(ns,ls->vr,ls->rxqsize,ls->rxkval)) {
	    DBG(("inside window; vr is %d\n",ls->vr));

	    /* Get non-negative window offset. */
	    woffs = (ls->rtail+ns-ls->vr+ls->rxkval+1) % (ls->rxkval+1);

	    if (ls->rxq[woffs].buffer != NULL) {
		/* Discard duplicate buffer. */
		DBG(("duplicate buffer; discarding.\n"));
		break;
	    }
	    ls->rxq[woffs].buffer = buffer+ilen;
	    ls->rxq[woffs].length = count-ilen;

	    /* Check for sequence number error. */
	    if (woffs != ls->rhead) {
		DBG(("queue offset %d not equal to head %d; need reject.\n",
		     woffs,ls->rhead));
		need_transmit(ls,STF_NEEDREJ);
	    }

	    if (++woffs > ls->rxkval)
		woffs = 0;

	    if (ls->rhead >= ls->rtail) {
		if (woffs > ls->rhead || woffs < ls->rtail)
		    ls->rhead = woffs;
	    } else {
		if (woffs > ls->rhead && woffs < ls->rtail)
		    ls->rhead = woffs;
	    }

	    /* While in sequence, send data to application */
	    if (ls->rcvnonempty != NULL &&
		ls->rxq[ls->rtail].buffer != NULL)
		(*ls->rcvnonempty)(ls->userstate);

	    /* Don't free queued packets. */
	    buffer = NULL;
	} else {
	    DBG(("outside window; vr is %d\n",ls->vr));
	}
	if (pfbit) {
	    need_transmit(ls,STF_NEEDSTATUS | STF_PFBIT);
	}
	break;

    case CRS_RR:
    case CRS_RNR:
	if (crcode == CRS_RR)
	    DBG(("received RR frame\n"));
	else
	    DBG(("received RNR frame\n"));
	/* Still setting up; silent discard. */
	if (ls->phase == phInitial)
	    break;
	if (count != ilen) {
	    errbits = 3;
	    break;
	}
	if (crcode == CRS_RR)
	    ls->flags |= LBF_PEERREADY;
	else
	    ls->flags &= ~LBF_PEERREADY;
	handle_nr(ls,nr);
	if (iscmd && pfbit) {
	    need_transmit(ls,STF_NEEDSTATUS | STF_PFBIT);
	}
	break;

    case CRS_REJ:
	DBG(("received REJ frame\n"));
	/* Still setting up; silent discard. */
	if (ls->phase == phInitial)
	    break;
	if (ls->mode == MODE_EXTENDED || (ls->flags & LBF_RXSREJ)) {
	    errbits = 1;
	    break;
	}
	if (count != ilen) {
	    errbits = 3;
	    break;
	}
	ls->flags |= LBF_PEERREADY;
	handle_nr(ls,nr);
	if (iscmd && pfbit)
	    need_transmit(ls,STF_NEEDSTATUS | STF_PFBIT);
	/* Drop back to sequence N(R) and try again on all. */
	DBG(("reject marking retransmit %d to %d\n",nr,ls->vs));
	mark_retransmit(ls,nr,ls->vs);
	break;

    case CRS_SREJ:
	DBG(("received SREJ frame\n"));
	/* Still setting up; silent discard. */
	if (ls->phase == phInitial)
	    break;
	if (ls->mode == MODE_BASIC || iscmd || !(ls->flags & LBF_RXSREJ)) {
	    errbits = 1;
	    break;
	}
	if (pfbit)
	    handle_nr(ls,nr);
	/* Drop back to sequence N(R) and try again on some. */
	mark_retransmit(ls,nr,nr);
	bp = buffer+ilen;
	count -= ilen;
	while (count > 0) {
	    nr = *bp++;
	    count--;
	    if (ls->mode == MODE_SUPER) {
		if (--count < 0)
		    break;
		nr |= *bp++ << 8;
	    }
	    if ((nr & 1) && count > 0) {
		woffs = *bp++;
		if (ls->mode == MODE_SUPER) {
		    if (--count < 0)	/* XXX */
			break;
		    woffs |= *bp++ << 8;
		}
		mark_retransmit(ls,nr>>1,woffs>>1);
	    } else {
		nr >>= 1;
		mark_retransmit(ls,nr,nr);
	    }
	}
	break;

    case CRU_SABM:
	DBG(("received SABM frame\n"));
	if (ls->flags & LBF_PERMISSIVE)
	    ls->mode = MODE_BASIC;
	if (ls->mode != MODE_BASIC || !iscmd) {
	    errbits = 1;
	    break;
	}
	if (count != 2) {
	    errbits = 3;
	    break;
	}
    enter_data_phase:
	DBG(("received entering data phase\n"));
	if (ls->statflag & STF_T1RUNNING) {
	    ls->t2ctr = 0;
	    ls->statflag &= ~STF_T1RUNNING;
	    untimeout(t1handler,(void *)ls);
	}
	ls->flags |= LBF_PEERREADY;
	ls->vr = ls->vs = 0;
	free_all_packets(ls);
	ls->phase = phData;
	ls->statflag &= ~STF_UAFBIT;
	need_transmit(ls,STF_NEEDUA | (pfbit ? STF_UAFBIT : 0));
	if (ls->xmthasroom != NULL)
	    (*ls->xmthasroom)(ls->userstate);
	break;

    case CRU_SABME:
	DBG(("received SABME frame\n"));
	if (ls->flags & LBF_PERMISSIVE)
	    ls->mode = MODE_EXTENDED;
	if (ls->mode != MODE_EXTENDED || !iscmd) {
	    errbits = 1;
	    break;
	}
	if (count != 2) {
	    errbits = 3;
	    break;
	}
	goto enter_data_phase;

    case CRU_SM:
	DBG(("received SM frame\n"));
	if (ls->flags & LBF_PERMISSIVE)
	    ls->mode = MODE_SUPER;
	ilen = (count > 6) ? 6 : count;	/* FRMR generation */
	if (ls->mode != MODE_SUPER || !iscmd) {
	    errbits = 1;
	    break;
	}
	/* Should have one address byte and 5 Set Mode bytes */
	if (count != 6 || buffer[2] != 0 || buffer[3] != 0x40 ||
	    buffer[4] != 0x80 || buffer[5] != 0x20) {
	    errbits = 3;
	    break;
	}
	goto enter_data_phase;

    case CRU_DISC:
	DBG(("received DISC frame\n"));
	if (!iscmd) {
	    errbits = 1;
	    break;
	}
	if (count != 2) {
	    errbits = 3;
	    break;
	}
	ls->phase = phDisconnected;
	ls->statflag &= ~STF_UAFBIT;
	need_transmit(ls,STF_NEEDUA | (pfbit ? STF_UAFBIT : 0));
	break;

    case CRU_DM:
	DBG(("received DM frame\n"));
	if (iscmd) {
	    errbits = 1;
	    break;
	}
	if (count != 2) {
	    errbits = 3;
	    break;
	}
	if (ls->phase != phInitial)
	    ls->phase = phDisconnected;
	break;

    case CRU_UA:
	DBG(("received UA frame\n"));
	if (iscmd) {
	    errbits = 1;
	    break;
	}
	if (count != 2) {
	    errbits = 3;
	    break;
	}
	if (ls->phase == phDisconnecting)
	    ls->phase = phDisconnected;
	ls->flags |= LBF_PEERREADY;
	break;

    case CRU_FRMR:
	DBG(("received FRMR frame\n"));
	/* Still setting up; silent discard. */
	if (ls->phase == phInitial)
	    break;
	if (iscmd) {
	    /* Rejecting a rejection seems like a bad idea. */
	    /* errbits = 1; */
	    break;
	}
	break;

    default:
	DBG(("received bad frame\n"));
	/* Error; bad code. */
	errbits = 1;
	break;
    }

frmr_handler:
    if (errbits && !(ls->txpend.qflags & QF_SENDING)) {
	/*
	 * We don't assume here that the input buffer is big
	 * enough to hold this error frame.  It probably is
	 * (and certainly is with the example AHDLC code),
	 * but better safe than sorry.
	 */
	DBG(("Generating FRMR in response\n"));
	bp = (octet *)buffer_fetch(11);
	if (bp != NULL) {
	    bp[0] = ls->cmdaddr ^ ls->crabit;
	    bp[1] = CRU_FRMR;
	    bp[3] = bp[4] = bp[5] = 0;
	    memcpy(bp+2,buffer+1,ilen-1);
	    switch (ls->mode) {
	    case MODE_BASIC:
		bp[3] = (ls->vs<<1) | (iscmd?0:0x10) | (ls->vr<<5);
		bp[4] = errbits;
		ilen = 5;
		break;
	    case MODE_EXTENDED:
		bp[4] = ls->vs<<1;
		bp[5] = (iscmd?0:1) | (ls->vr<<1);
		bp[6] = errbits;
		ilen = 7;
		break;
	    case MODE_SUPER:
		bp[6] = ls->vs<<1;
		bp[7] = ls->vs>>7;
		bp[8] = (iscmd?0:1) | (ls->vr<<1);
		bp[9] = ls->vr>>1;
		bp[10] = errbits;
		ilen = 11;
		break;
	    }
	    ls->txpend.qflags = QF_SEND;
	    ls->txpend.length = ilen;
	    if (ls->txpend.buffer != NULL)
		buffer_release(ls->txpend.buffer);
	    ls->txpend.buffer = bp;
	}
    }
    if (buffer != NULL)
	buffer_release(buffer);
}

/*
 * This creates a SABM, SABME, or SM message as appropriate for the
 * configured mode.
 */
static octet *
make_set_mode(struct lapb_state *ls, int *lengthp)
{
    octet *bp,ctl;
    int len;

    len = 0;
    bp = (octet *)buffer_fetch(6);
    if (bp != NULL) {
	bp[0] = ls->cmdaddr;
	/* 2.4.4.1 -- DTE sets P bit in set-mode command */
	ctl = (ls->flags & LBF_ISDTE) ? 0x10 : 0;
	switch (ls->mode) {
	case MODE_BASIC:
	    bp[1] = CRU_SABM | ctl;
	    len = 2;
	    break;
	case MODE_EXTENDED:
	    bp[1] = CRU_SABME | ctl;
	    len = 2;
	    break;
	case MODE_SUPER:
	    bp[1] = CRU_SM | ctl;
	    bp[2] = 0;
	    bp[3] = 0x40;
	    bp[4] = 0x80;
	    bp[5] = 0x20;
	    len = 6;
	    break;
	default:
	    /* This can't happen. */
	    buffer_release(bp);
	    bp = NULL;
	}
    }
    *lengthp = len;
    return bp;
}

/*
 * This creates a Receive Ready or Receive Not Ready message as
 * appropriate for the current state and mode.
 */
static octet *
make_status(struct lapb_state *ls, int *lengthp)
{
    octet *bp,ctl;
    int len;

    if ((bp = (octet *)buffer_fetch(5)) == NULL)
	return NULL;
    bp[0] = ls->cmdaddr ^ (0 ? 0 : ls->crabit);
    ctl = ALLSET(ls->flags,LBF_IMREADY|LBF_USERREADY) ? CRS_RR : CRS_RNR;
    switch (ls->mode) {
    case MODE_BASIC:
	bp[1] = ctl | (ls->statflag & STF_PFBIT ? 0x10 : 0) | (ls->vr<<5);
	len = 2;
	break;
    case MODE_EXTENDED:
	bp[1] = ctl;
	bp[2] = (ls->statflag & STF_PFBIT ? 1 : 0) | (ls->vr<<1);
	len = 3;
	break;
    case MODE_SUPER:
	bp[1] = ctl;
	bp[2] = 0;
	bp[3] = (ls->statflag & STF_PFBIT ? 1 : 0) | (ls->vr<<1);
	bp[4] = ls->vr>>7;
	len = 5;
	break;
    default:
	/* This can't happen. */
	buffer_release(bp);
	return NULL;
    }
    *lengthp = len;
    return bp;
}

/*
 * Generate an unnumbered acknowledgement response.  This is used as a
 * reply to a received SABM/SABME/SM frame.
 */
static octet *
make_ua(struct lapb_state *ls, int *lengthp)
{
    octet *bp;

    if ((bp = (octet *)buffer_fetch(2)) == NULL)
	return NULL;
    bp[0] = ls->cmdaddr ^ ls->crabit;
    bp[1] = CRU_UA | ((ls->statflag & STF_UAFBIT) ? 0x10 : 0);
    *lengthp = 2;
    return bp;
}

/*
 * Generate a disconnect mode response.
 */
static octet *
make_dm(struct lapb_state *ls, int *lengthp)
{
    octet *bp;

    if ((bp = (octet *)buffer_fetch(2)) == NULL)
	return NULL;
    bp[0] = ls->cmdaddr ^ ls->crabit;
    bp[1] = CRU_DM;
    *lengthp = 2;
    return bp;
}

/*
 * Generate a disconnect command.
 */
static octet *
make_disc(struct lapb_state *ls, int *lengthp)
{
    octet *bp;

    if ((bp = (octet *)buffer_fetch(2)) == NULL)
	return NULL;
    bp[0] = ls->cmdaddr;
    bp[1] = CRU_DISC | 0x10;
    *lengthp = 2;
    return bp;
}

/*
 * Make a reject or selective reject command frame as appropriate.
 */
static octet *
make_reject(struct lapb_state *ls, int *lengthp)
{
    octet *bp,*buffer;
    int rtail,nrej,slen,rfirst,vrnum;

    /* Count up entries needed in information field. */
    rtail = ls->rtail;
    slen = nrej = 0;
    rfirst = -1;
    while (rtail != ls->rhead) {
	if (ls->rxq[rtail].buffer == NULL) {
	    if (rfirst < 0)
		rfirst = rtail;
	    if (ls->flags & LBF_TXSREJ) {
		slen++;
	    } else {
		nrej++;
		break;
	    }
	} else if (slen > 0) {
	    if (slen > 1)
		nrej += 2;
	    else
		nrej++;
	    slen = 0;
	}
	if (++rtail > ls->rxkval)
	    rtail = 0;
    }
    if (slen > 0) {
	if (slen > 1)
	    nrej += 2;
	else
	    nrej++;
    }
    if (nrej == 0) {
	ls->statflag &= ~STF_NEEDREJ;
	return NULL;
    }

    /* Calculate approximate message size. */
    if (ls->mode == MODE_SUPER) {
	nrej *= 2;
	nrej += 5;
    } else {
	nrej += 3;
    }
    if ((bp = buffer = (octet *)buffer_fetch(nrej)) == NULL)
	return NULL;

    /* Construct the message */
    *bp++ = ls->cmdaddr ^ ls->crabit;
    nrej = (ls->flags & LBF_TXSREJ) ? CRS_SREJ : CRS_REJ;
    vrnum = (ls->rxkval+1+rfirst-ls->rtail)%(ls->rxkval+1);
    vrnum = (vrnum+ls->vr)%ls->rxqsize;
    switch (ls->mode) {
    case MODE_BASIC:
	*bp++ = nrej | (vrnum<<5);
	break;
    case MODE_EXTENDED:
	*bp++ = nrej;
	*bp++ = (vrnum<<1) | ((ls->flags & LBF_TXSREJ) ? 1 : 0);
	break;
    case MODE_SUPER:
	*bp++ = nrej;
	*bp++ = 0;
	*bp++ = (vrnum<<1) | ((ls->flags & LBF_TXSREJ) ? 1 : 0);
	*bp++ = vrnum>>7;
	break;
    }
    rtail = rfirst;
    slen = 0;
    if (ls->flags & LBF_TXSREJ) {
	/* Build up the span list for selective reject. */
	while (rtail != ls->rhead) {
	    if (ls->rxq[rtail].buffer == NULL) {
		if (++slen == 1) {
		    *bp++ = vrnum<<1;
		    if (ls->mode == MODE_SUPER)
			*bp++ = vrnum>>7;
		}
	    } else if (slen > 0) {
		if (slen > 1) {
		    if ((slen = vrnum) == 0)
			slen = ls->rxqsize;
		    slen--;
		    bp[(ls->mode == MODE_SUPER) ? -2 : -1] |= 1;
		    *bp++ = (slen<<1) | 1;
		    if (ls->mode == MODE_SUPER)
			*bp++ = slen>>7;
		}
		slen = 0;
	    }
	    if (++rtail > ls->rxkval)
		rtail = 0;
	    if (++vrnum >= ls->rxqsize)
		vrnum = 0;
	}
    }

    *lengthp = bp-buffer;
    ls->statflag &= ~STF_NEEDREJ;
    return buffer;
}

/*
 * Called when timer T1 should be enabled.
 */
static void
set_timer_t1(struct lapb_state *ls)
{
    if (!(ls->statflag & STF_T1RUNNING)) {
	ls->statflag |= STF_T1RUNNING;
	timeout(t1handler,(void *)ls,ls->t1period);
    }
}

/*
 * This routine is handed over to the HDLC framer, which should call
 * when it needs a new packet to transmit.
 */
void
lapb_transmit(void *statep, octet **bufferp, int *lengthp)
{
    struct lapb_state *ls = (struct lapb_state *)statep;
    octet *bp;
    int len,tptr;

    if (statep == NULL || bufferp == NULL || lengthp == NULL)
	return;
    *bufferp = NULL;
    *lengthp = 0;

    DBG(("transmit handler for %p.\n",ls));
    /* Check for completed frames to free up. */
    if (ls->txpend.qflags & QF_SENDING) {
	DBG(("done with pended packet.\n"));
	if (ls->txpend.buffer != NULL)
	    buffer_release(ls->txpend.buffer);
	ls->txpend.buffer = NULL;
	ls->txpend.qflags = 0;
    }

    if (ls->discarding != NULL) {
	buffer_release(ls->discarding);
	ls->discarding = NULL;
    }

    /* We are done sending the current frame; mark or free it. */
    tptr = ls->tsending;
    if (ls->txq[tptr].qflags & QF_SENDING) {
	/*
	 * Timing note: we may get an reject in before we finish
	 * transmitting the frame being rejected.  Don't free the
	 * frame in this case.
	 */
	if ((ls->txq[tptr].qflags&(QF_ACKED|QF_SEND)) == QF_ACKED) {
	    DBG(("done with acked packet.\n"));
	    buffer_release(ls->txq[tptr].buffer);
	    ls->txq[tptr].buffer = NULL;
	    ls->txq[tptr].qflags = 0;
	    if (tptr == ls->ttail && ls->phase <= phQueueDrain) {
		if (++tptr > ls->txkval)
		    tptr = 0;
		ls->ttail = tptr;
		if (ls->statflag & STF_XMITFULL) {
		    ls->statflag &= ~STF_XMITFULL;
		    if (ls->phase == phQueue && ls->xmthasroom != NULL)
			(*ls->xmthasroom)(ls->userstate);
		}
	    }
	} else
	    ls->txq[tptr].qflags &= ~QF_SENDING;
    }

    /* If no pending frame, then find one to do. */
    if (ls->txpend.buffer == NULL && ls->phase >= phInitial) {

	if (ls->statflag & STF_NEEDDM) {
	    if ((ls->txpend.buffer = make_dm(ls,&len)) != NULL) {
		DBG(("pended DM packet.\n"));
		ls->statflag &= ~STF_NEEDDM;
		ls->txpend.length = len;
	    }

	/* Check for SABM frame. */
	} else if (ls->statflag & STF_NEEDSABM) {
	    if ((ls->txpend.buffer = make_set_mode(ls,&len)) != NULL) {
		DBG(("pended SABM packet.\n"));
		ls->statflag &= ~STF_NEEDSABM;
		ls->txpend.length = len;
		set_timer_t1(ls);
	    }

	} else if (ls->statflag & STF_NEEDDISC) {
	    if ((ls->txpend.buffer = make_disc(ls,&len)) != NULL) {
		DBG(("pended DISC packet.\n"));
		ls->statflag &= ~STF_NEEDDISC;
		ls->txpend.length = len;
		set_timer_t1(ls);
	    }

	/* Check for UA frame. */
	} else if (ls->statflag & STF_NEEDUA) {
	    if ((ls->txpend.buffer = make_ua(ls,&len)) != NULL) {
		DBG(("pended UA packet.\n"));
		ls->statflag &= ~STF_NEEDUA & ~STF_UAFBIT;
		ls->txpend.length = len;
	    }

	/* Check for status with PF bit. */
	} else if (ALLSET(ls->statflag,STF_NEEDSTATUS|STF_PFBIT)) {
	    if ((ls->txpend.buffer = make_status(ls,&len)) != NULL) {
		DBG(("pended RR/RNR with PF bit.\n"));
		ls->statflag &= ~STF_NEEDSTATUS & ~STF_PFBIT;
		ls->txpend.length = len;
	    }

	/* Check for reject frame. */
	} else if (ls->statflag & STF_NEEDREJ) {
	    if ((ls->txpend.buffer = make_reject(ls,&len)) != NULL) {
		DBG(("pended REJ/SREJ frame.\n"));
		ls->txpend.length = len;
		set_timer_t1(ls);
	    }
	}
    }

    /* If we now have something pending, then do it. */
    if (ls->txpend.buffer != NULL) {
	DBG(("sending pended packet.\n"));
	ls->txpend.qflags = QF_SENDING;
	*bufferp = ls->txpend.buffer;
	*lengthp = ls->txpend.length;
	ls->statflag |= STF_XMITRUN;
	return;
    }

    /* Skip over any frames that don't need to be sent. */
    tptr = ls->tnext;
    if (tptr != ls->thead) {
	while (tptr != ls->thead && !(ls->txq[tptr].qflags & QF_SEND)) {
	    if (++tptr > ls->txkval)
		tptr = 0;
	}
	ls->tnext = tptr;
    }

    /* Check for new I frame to transmit */
    if (tptr != ls->thead) {
	DBG(("sending from transmit queue location %d on %p\n",tptr,ls));
	bp = ls->txq[tptr].buffer;
	len = ls->txq[tptr].length;
	ls->txq[tptr].qflags = 
	    (ls->txq[tptr].qflags & ~QF_SEND) | QF_SENDING;
	assert(bp != NULL);

	ls->tsending = tptr;
	if (ls->phase == phData) {
	    /* Insert current VR number now. */
	    ls->statflag &= ~STF_NEEDVR;
	    switch (ls->mode) {
	    case MODE_BASIC:
		DBG(("sending basic I frame; ns %d nr %d.\n",
		     (bp[1]>>1)&7,ls->vr));
		bp[1] = (bp[1] & 0x1F) | (ls->vr<<5);
		break;
	    case MODE_EXTENDED:
		DBG(("sending extended I frame; ns %d nr %d.\n",
		     (bp[1]>>1)&0x7F,ls->vr));
		bp[2] = (bp[2] & 1) | (ls->vr<<1);
		break;
	    case MODE_SUPER:
		DBG(("sending super I frame; ns %d nr %d.\n",
		     ((bp[1]>>1)&0x7F)|(bp[2]<<7),ls->vr));
		bp[3] = (bp[3]&1) | (ls->vr<<1);
		bp[4] = ls->vr>>7;
		break;
	    }
	    set_timer_t1(ls);
	} else {
	    DBG(("sending queued frame.\n"));
	    ls->txq[tptr].qflags |= QF_ACKED;
	}

	tptr++;
	if (tptr > ls->txkval)
	    tptr = 0;
	ls->tnext = tptr;

	/* Complete switch into LAP-B mode. */
	if (tptr == ls->thead && ls->phase == phQueueDrain) {
	    DBG(("drained; switching to LAP-B.\n"));
	    ls->phase = phInitial;
	    ls->statflag |= STF_NEEDSABM;
	}

	*bufferp = bp;
	*lengthp = len;
	ls->statflag |= STF_XMITRUN;
	return;
    }

    /* Check for plain status frame to transmit */
    if ((ls->statflag & (STF_NEEDSTATUS|STF_NEEDVR)) != 0 &&
	ls->phase >= phInitial) {
	if ((ls->txpend.buffer = make_status(ls,&len)) != NULL) {
	    DBG(("plain RR/RNR frame to send.\n"));
	    ls->statflag = (ls->statflag & ~STF_NEEDSTATUS & ~STF_NEEDVR &
			    ~STF_PFBIT) | STF_XMITRUN;
	    *lengthp = ls->txpend.length = len;
	    *bufferp = ls->txpend.buffer;
	    ls->txpend.qflags = QF_SENDING;
	    return;
	}
    }

    /* Nothing left to send. */
    ls->statflag &= ~STF_XMITRUN;
}

/*
 * User function to fetch data from receive queue.  Returns pointer
 * to data and length.
 */
int
lapb_receive(void *statep, octet **bufferp)
{
    struct lapb_state *ls = (struct lapb_state *)statep;
    int rptr,len;

    if (ls == NULL || bufferp == NULL)
	return -1;

    rptr = ls->rtail;
    /* Check for empty buffer. */
    if (rptr == ls->rhead) {
	DBG(("empty receive queue on %p\n",ls));
	*bufferp = NULL;
	return 0;
    }
    /* Check if next packet in window hasn't been received yet. */
    if ((*bufferp = ls->rxq[rptr].buffer) == NULL) {
	DBG(("out-of-order; sequence not received yet.\n"));
	return 0;
    }
    len = ls->rxq[rptr].length;
    ls->rxq[rptr].buffer = NULL;
    rptr++;
    if (rptr > ls->rxkval)
	rptr = 0;
    ls->rtail = rptr;
    ls->vr = (ls->vr + 1) % ls->rxqsize;
    DBG(("buffer received by application; bumping vr to %d\n",ls->vr));
    ls->flags |= LBF_IMREADY;
    ls->statflag |= STF_NEEDVR;
    need_transmit(ls,STF_NEEDVR);

    return len;
}

/*
 * User function to send data to transmit queue.  Returns non-zero if
 * queue is now full.  (xmthasroom callback will be made when room is
 * again available.)
 *
 * It is assumed that the buffer given has enough room to prepend a
 * header.  This is 2 octets for basic mode, 3 for extended, and 5 for
 * super.
 */
int
lapb_send(void *statep, octet *buffer, int length)
{
    struct lapb_state *ls = (struct lapb_state *)statep;
    int tptr,tnxt;

    if (ls == NULL || buffer == NULL)
	return -1;

    tptr = ls->thead;
    tnxt = tptr+1;
    if (tnxt > ls->txkval)
	tnxt = 0;
    if (tnxt == ls->ttail || (ls->phase != phQueue && ls->phase != phData)) {
	/* User error; queue is already full. */
	DBG(("send error on %p; %s\n",ls,
	     (tnxt == ls->ttail) ? "queue is full" : "wrong phase"));
	buffer_release(buffer);
	ls->statflag |= STF_XMITFULL;
	return -1;
    }

    if (ls->phase >= phData) {
	/* VR is inserted when the frame is actually sent. */
	switch (ls->mode) {
	case MODE_BASIC:
	    *--buffer = CRI_I | (ls->vs<<1);
	    length += 2;
	    break;
	case MODE_EXTENDED:
	    *--buffer = 0;
	    *--buffer = CRI_I | (ls->vs<<1);
	    length += 3;
	    break;
	case MODE_SUPER:
	    *--buffer = 0;
	    *--buffer = 0;
	    *--buffer = ls->vs>>7;
	    *--buffer = CRI_I | (ls->vs<<1);
	    length += 5;
	    break;
	}
	*--buffer = ls->cmdaddr;
	ls->vs = (ls->vs + 1) % ls->txqsize;
    }

    DBG(("set transmit queue location %d on %p\n",tptr,ls));
    ls->txq[tptr].buffer = buffer;
    ls->txq[tptr].length = length;
    ls->txq[tptr].qflags = QF_SEND;

    tptr = (tptr == ls->ttail);
    ls->thead = tnxt;

    if (tptr && !(ls->statflag & STF_XMITRUN)) {
	ls->statflag |= STF_XMITRUN;
	enable_transmit();
    }

    if (ls->phase == phQueueDrain) {
	DBG(("in queue drain phase; marking full flag.\n"));
	ls->statflag |= STF_XMITFULL;
	return 1;
    }

    tnxt++;
    if (tnxt > ls->txkval)
	tnxt = 0;
    if (tnxt == ls->ttail) {
	DBG(("transmit queue is full.\n"));
	ls->statflag |= STF_XMITFULL;
	return 1;
    }
    return 0;
}

/*
 * User function to enable and disable LAP-B operation.
 */
void
lapb_control(void *statep, int onoff)
{
    struct lapb_state *ls = (struct lapb_state *)statep;

    if (ls == NULL)
	return;
    if (onoff) {
	if (ls->phase == phQueue) {
	    if (ls->tnext != ls->thead)
		ls->phase = phQueueDrain;
	    else {
		ls->phase = phInitial;
		need_transmit(ls,STF_NEEDSABM);
	    }
	}
    } else {
	if (ls->phase == phQueueDrain || ls->phase == phDisconnected)
	    ls->phase = phQueue;
	else if (ls->phase >= phInitial) {
	    ls->phase = phDisconnecting;
	    need_transmit(ls,STF_NEEDDISC);
	}
    }
}

/*
 * Change LAP-B parameters.  Should be called by LCP negotiation.
 */
void
lapb_change(void *statep, int mode, int txkval, int rxkval,
	    int t1period, int t2max, int flags)
{
    struct lapb_state *ls = (struct lapb_state *)statep;
    int len;
    struct lapb_queue *qp;

    if (ls == NULL || mode < MODE_BASIC || mode > MODE_PERMISSIVE)
	return;
    len = mode_modulus[mode];
    if (txkval >= len || rxkval >= len)
	return;

    if ((mode != ls->mode && mode != MODE_PERMISSIVE) ||
	(mode == MODE_PERMISSIVE && !(ls->flags & LBF_PERMISSIVE)) ||
	txkval != ls->txkval || rxkval != ls->rxkval) {
	if (ls->phase >= phInitial)
	    free_all_packets(ls);
	if (txkval != ls->txkval || rxkval != ls->rxkval) {
	    len = (txkval+rxkval+2)*sizeof(struct lapb_queue);
	    qp = (struct lapb_queue *)realloc(ls->rxq,len);
	    if (qp == NULL)
		return;
	    init_values(ls,qp,mode,txkval,rxkval,flags);
	}
    }
    if (t1period <= 0)
	t1period = DEF_T1PERIOD;
    ls->t1period = t1period;
    if (t2max <= 0)
	t2max = DEF_T2MAX;
    ls->t2max = t2max;
}
