/*
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code is
 * also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1999 by James Carlson and Working Code.
 */

#ifndef UTIL_H
#define UTIL_H

extern void dump_buffer(char *buf, int count);
extern char *buffer_fetch(int size);
extern void buffer_release(char *buffer);

#endif /* UTIL_H */
