/*
 * Test routines for AHDLC driver.
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code
 * is also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1997 by James Carlson and Working Code
 */

#include <stdio.h>
#include <stdlib.h>

#include "sysdep.h"
#include "util.h"
#include "ahdlc.h"

static char testbuffers[4][2048];
static int testlens[4];
static int rcv_ctr = 0;

/* Receive decoded packet; check against data that were sent. */
static void
my_receive(void *state, octet *buffer, int size)
{
    printf("Received a packet of length %d\n",size);
    dump_buffer(buffer,size);
    if (size != testlens[rcv_ctr]) {
	printf("Expected length %d!\n",testlens[rcv_ctr]);
	exit(1);
    }
    if (memcmp(buffer,testbuffers[rcv_ctr],size) != 0) {
	printf("Data received is corrupted!\n");
	exit(1);
    }
    buffer_release(buffer);
    rcv_ctr++;
}

/* Fill a transmit buffer with random data. */
static void
fill_a_buffer(int ctr, octet **bufferp, int *sizep, int size)
{
    char *cp;

    cp = *bufferp = buffer_fetch(size);
    *sizep = size;
    while (--size >= 0)
	*cp++ = rand();
    printf("Sending a buffer of size %d.\n",*sizep);
    dump_buffer(*bufferp,*sizep);
    memcpy(testbuffers[ctr],*bufferp,*sizep);
    testlens[ctr] = *sizep;
}

/*
 * Handle transmit upcall from AHDLC driver.  Normally, this would
 * dequeue the next packet to send from an interface structure.
 * For this simple test, it just selects a test packet to send.
 */
static void
my_transmit(void *state, octet **bufferp, int *sizep)
{
    static int ctr = 0;

    ctr++;
    *bufferp = NULL;
    *sizep = 0;
    switch (ctr) {
    case 1:
	fill_a_buffer(0,bufferp,sizep,256);
	break;
    case 2:
	fill_a_buffer(1,bufferp,sizep,20);
	break;
    case 3:
	printf("Not sending a buffer (emulating an empty transmit queue)\n");
	break;
    case 4:
	fill_a_buffer(2,bufferp,sizep,1000);
	break;
    case 5:
	fill_a_buffer(3,bufferp,sizep,1);
	break;
    }
}

/* Dummy routines. */
void interrupts_off(void) {}
void interrupts_on(void) {}
void wakeup(void *event) {}
void sleep(void *event, int level) {}

int
main(argc,argv)
int argc;
char **argv;
{
    void *line;
    int i,count;
    char obuffer[32];

    /* Create an AHDLC session and loop output to input. */
    line = ahdlc_create();
    ahdlc_handlers(line,NULL,my_receive,my_transmit);
    count = 0;
    while ((i=getopt(argc,argv,"cs")) != EOF)
	switch (i) {
	case 'c':
	    ahdlc_set_crc_mode(line,1);
	    break;
	case 's':
	    ahdlc_set_sbdpt(line,1);
	    break;
	case '?':
	    fprintf(stderr,"Usage:\n\t%s [-cs]\n",argv[0]);
	    exit(1);
	}

    /* Run a bunch of tests; transmit and expect the same on input */
    for (i = 0; i < 70; i++) {
	count = ahdlc_transmit(line,obuffer,sizeof(obuffer));
	if (count > 0) {
	    printf("Looping back %d characters\n",count);
	    dump_buffer(obuffer,count);
	    ahdlc_receive(line,obuffer,count);
	}
    }

    /* Clean up. */
    ahdlc_destroy(line);
    if (rcv_ctr != 4)
	printf("Some packets were lost\n");
    return 0;
}
