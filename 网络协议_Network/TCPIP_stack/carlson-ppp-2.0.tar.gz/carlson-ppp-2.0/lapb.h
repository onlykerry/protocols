/*
 * This code shows a simple LAP-B implementation for use with PPP
 * Numbered Mode (RFC 1663).  It assumes a system interface like the
 * ahdlc.c module provided with this example.
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code is
 * also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1999 by James Carlson and Working Code.
 */

#ifndef LAPB_H
#define LAPB_H

#include "sysdep.h"

extern void *lapb_create(int mode, int txkval, int rxkval, int t1period,
			 int t2max, int flags);
extern void lapb_destroy(void *statep);
extern void lapb_handlers(void *statep, void *userstate,
			  void (*rcvnonempty)(void *userstate),
			  void (*xmthasroom)(void *userstate));
extern int lapb_ready_state(void *statep, int flag);
extern void lapb_input(void *statep, octet *buffer, int count);
extern void lapb_transmit(void *statep, octet **bufferp, int *lengthp);
extern int lapb_receive(void *statep, octet **bufferp);
extern int lapb_send(void *statep, octet *buffer, int length);
extern void lapb_control(void *statep, int onoff);
extern void lapb_change(void *statep, int mode, int txkval, int rxkval,
			int t1period, int t2max, int flags);

/* Modes for create */
#define MODE_BASIC	0
#define MODE_EXTENDED	1
#define MODE_SUPER	2
#define MODE_PERMISSIVE	3

/* Flags for use with LAP-B session creation. */
#define LBF_ISDTE	0x01	/* DTE side */
#define LBF_MULTILINK	0x02	/* Run multilink */
#define LBF_TXSREJ	0x04	/* Send SREJ instead of REJ to peer */
#define LBF_RXSREJ	0x08	/* Allow SREJ instead of REJ from peer */

#define LAPB_OVERHEAD	5	/* Overhead to prepend */

#endif /* LAPB_H */
