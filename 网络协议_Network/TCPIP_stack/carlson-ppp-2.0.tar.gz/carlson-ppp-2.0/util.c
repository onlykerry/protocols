/*
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code is
 * also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1999 by James Carlson and Working Code.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>

#define MAX_CALLOUTS	10

#ifdef RECORD_BUFFERS
#define MAXRECORD	5000
static char *bufferrec[MAXRECORD];
static int lengthrec[MAXRECORD];
#endif

struct callout {
    struct callout *next;
    int millisec;
    void (*func)(void *handle);
    void *handle;
};

static struct callout clist[MAX_CALLOUTS];
static struct callout *cnext = NULL,*cuse = clist, *cfree = NULL;

int buffers_allocated,buffers_freed;

void
dump_buffer(char *buf, int count)
{
    int i,j;

    for (i = 0; i < count; i += 16) {
	printf("%04X:  ",i);
	for (j = 0; j < 16 && j+i < count; j++)
	    printf("%02X ",buf[j+i]&0xFF);
	printf("%*s",(16-j)*3+2,"");
	for (j = 0; j < 16 && j+i < count; j++)
	    if (isprint(buf[j+i]))
		putchar(buf[j+i]);
	    else
		putchar('.');
	putchar('\n');
    }
}

char *
buffer_fetch(int size)
{
    char *cp = malloc(size);

    assert(cp != NULL);
#ifdef RECORD_BUFFERS
    if (buffers_allocated < MAXRECORD) {
	bufferrec[buffers_allocated] = cp;
	lengthrec[buffers_allocated] = size;
    }
#endif
    buffers_allocated++;
#ifdef DEBUG_UTIL
    printf("Allocated buffer of size %d at %p\n",size,cp);
#endif
    return cp;
}

void
buffer_release(char *buffer)
{
#ifdef DEBUG_UTIL
    printf("Freeing buffer at %p\n",buffer);
#endif
    buffers_freed++;
#ifdef RECORD_BUFFERS
    {
	int i;
	for (i = 0; i < buffers_allocated; i++)
	    if (buffer >= bufferrec[i] && buffer < bufferrec[i]+lengthrec[i])
		break;
	assert(i < buffers_allocated);
	bufferrec[i] = NULL;
    }
#endif
    *buffer = 'X';
    free(buffer);
}

void
buffer_status(void)
{
    printf("%d buffers allocated, %d freed, %d outstanding.\n",
	   buffers_allocated,buffers_freed,buffers_allocated-buffers_freed);
#ifdef RECORD_BUFFERS
    {
	int i;
	for (i = 0; i < buffers_allocated && i < MAXRECORD; i++)
	    if (bufferrec[i] != NULL) {
		printf("Abandoned buffer of size %d at %p:\n",lengthrec[i],
		       bufferrec[i]);
		dump_buffer(bufferrec[i],lengthrec[i]);
	    }
    }
#endif
}

void
timeout(void (*func)(void *handle), void *handle, int millisec)
{
    struct callout *cthis,*cptr;

    if ((cthis = cfree) == NULL) {
	assert(cuse < clist+MAX_CALLOUTS);
	cthis = cuse++;
    } else
	cfree = cthis->next;

    cthis->func = func;
    cthis->handle = handle;

    if ((cptr = cnext) == NULL || millisec < cptr->millisec) {
	cthis->next = cptr;
	cnext = cthis;
    } else {
	while (cptr->next != NULL) {
	    millisec -= cptr->millisec;
	    if (millisec < cptr->next->millisec) {
		cptr->next->millisec -= millisec;
		break;
	    }
	}
	cthis->next = cptr->next;
	cptr->next = cthis;
    }
    cthis->millisec = millisec;
}

/* Delete any outstanding call to the given function. */
void
untimeout(void (*func)(void *handle), void *handle)
{
    struct callout *cthis,*cprev,*cnxt;

    cprev = NULL;
    for (cthis = cnext; cthis != NULL;) {
	cnxt = cthis->next;
	if (cthis->func == func && cthis->handle == handle) {
	    if (cprev == NULL)
		cnext = cnxt;
	    else
		cprev->next = cnxt;
	    cthis->next = cfree;
	    cfree = cthis;
	    cthis = cnxt;
	} else {
	    cprev = cthis;
	    cthis = cnxt;
	}
    }
}

int
nextevent(void)
{
    if (cnext == NULL)
	return -1;
    return cnext->millisec;
}

void
timeelapsed(int millisec)
{
    struct callout *cthis;

    if (cnext == NULL)
	return;
    if (millisec < 0)
	millisec = cnext->millisec;
    while (cnext != NULL && millisec >= 0) {
	if (millisec < cnext->millisec) {
	    cnext->millisec -= millisec;
	    break;
	}
	millisec -= cnext->millisec;
	cthis = cnext;
	cnext = cthis->next;
	cthis->next = cfree;
	cfree = cthis;
	if (cthis->func != NULL) {
	    (*cthis->func)(cthis->handle);
	}
    }
}
