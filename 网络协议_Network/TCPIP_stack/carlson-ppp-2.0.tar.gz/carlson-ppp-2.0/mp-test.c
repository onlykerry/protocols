/*
 * MP test driver.  This code does NOT actually negotiate PPP links.
 * It just initializes an MP fragmentation and reassembly handler and
 * runs some packets through to test it.
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code
 * is also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 * http://www.workingcode.com/ppp
 *
 * Copyright 1997 by James Carlson and Working Code.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "sysdep.h"
#include "util.h"
#include "mp.h"

/* Dummy ECP routine. */
char *
ecp_decrypt(struct xcp_state *xcp, char *indata, int *inlen)
{
    printf("Would decrypt %d bytes here.\n",*inlen);
    return indata;
}

/* Dummy CCP routine. */
char *
ccp_uncompress(struct xcp_state *xcp, char *indata, int *inlen)
{
    printf("Would uncompress %d bytes here.\n",*inlen);
    return indata;
}

/* Dummy CCP uncompressed data handler (BSD Compress/Deflate) */
void
ccp_uncompressed(struct xcp_state *xcp, uint16 proto, char *indata, int inlen)
{
    printf("Would update decompressor dictionary here.\n");
}

static int h1,h2;		/* Dummy handle to discriminate links */
static void *l1,*l2;		/* Returned handle from MP */
static octet testbuf[2048];	/* Test I/O buffer */

/* Handle a received LCP frame (should go to PPP) */
void
lcp_handler(struct xcp_state *xcp, octet *indata, int inlen)
{
    printf("LCP handler.\n");
    dump_buffer(indata,inlen);
}

/* Handle a received IP frame */
void
ip_handler(struct xcp_state *xcp, octet *indata, int inlen)
{
    printf("IP handler; %d bytes.\n",inlen);
    dump_buffer(indata,inlen);
}

/* Transmit routine passed to MP. */
static void
link_output(void *handle, octet *outdata, int outlen)
{
    void *lptr;

    if (handle == (void *)&h1) {
	printf("Output for link 1");
	lptr = l1;
    } else if (handle == (void *)&h2) {
	printf("Output for link 2");
	lptr = l2;
    } else {
	printf("Error; bad handle %X\n",(unsigned)handle);
	return;
    }
    printf(", %d bytes:\n",outlen);
    dump_buffer(outdata,outlen);
    link_receive(lptr,outdata,outlen);
}

/* Fill up test buffer with random data. */
static void
fill_testbuf(void)
{
    int i;

    for (i = 0; i < sizeof(testbuf); i++)
	testbuf[i] = rand();
}

int canned_list[][3] = {
    { 0, 0, 2 },
    { 1, 1, 0 },
    { 1, 2, 0 },
    { 1, 5, 2 },
    { 1, 7, 1 },
    { 1, 8, 2 },
    { 0, 3, 0 },
    { 0, 4, 1 },
    { 0, 6, 0 },
    { 0, 9, 0 },
    { 0, 10, 1 },
    { -1, -1, -1 },
};

void
run_canned_test(void)
{
    int i,j;
    void *lptr;

    for (i = 0; canned_list[i][0] >= 0; i++) {
	lptr = canned_list[i][0] ? l2 : l1;
	j = 0;
	testbuf[j++] = 0xFF;
	testbuf[j++] = 0x03;
	testbuf[j++] = 0x00;
	testbuf[j++] = 0x3D;
	testbuf[j++] = canned_list[i][2] << 6;
	testbuf[j++] = canned_list[i][1] >> 16;
	testbuf[j++] = canned_list[i][1] >> 8;
	testbuf[j++] = canned_list[i][1];
	if (canned_list[i][2] & 2) {
	    testbuf[j++] = 0x00;
	    testbuf[j++] = 0x21;
	}
	sprintf(testbuf+j,"fragment %d (loop %d)",canned_list[i][1],i);
	link_receive(lptr,testbuf,32+j);
    }
}

int
main(argc,argv)
int argc;
char **argv;
{
    void *mp1,*mp2,*ip;

    fill_testbuf();

    /*
     * Create two links and put them together as though LCP had
     * run, an MRRU were negotiated, and authentication completed
     * successfully.
     *
     * Also add a handler for received IP data as though IPCP had
     * come up.
     */
    l1 = create_ppp_link(&h1,link_output);
    set_link_mtu(l1,250);
    ip = add_xcp(l1,0x21,ip_handler,generic_sender);
    l2 = create_ppp_link(&h2,link_output);
    set_link_mtu(l2,250);
    mp1 = find_bundle_head(l1);
    mp2 = find_bundle_head(l2);
    if (mp1 != mp2) {
	printf("Null peername/ed should bundle together.\n");
	return 1;
    }

    if (argv[1] != NULL && strcmp(argv[1],"-c") == 0) {
	run_canned_test();
	return 0;
    }

    /* Now send a bunch of IP packets and make sure they work. */
    printf("Sending test buffer of 1500 bytes:\n");
    dump_buffer(testbuf+32,1500);
    generic_sender(ip,testbuf+32,150);
    generic_sender(ip,testbuf+32,300);
    generic_sender(ip,testbuf+32,1500);
    generic_sender(ip,testbuf+32,15);
    generic_sender(ip,testbuf+32,150);
    generic_sender(ip,testbuf+32,1500);
    generic_sender(ip,testbuf+32,300);

    /* All done.  Clean up. */
    destroy_ppp_link(l1);
    destroy_ppp_link(l2);
    return 0;
}
