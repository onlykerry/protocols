/*
 * Multilink PPP example code.
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code
 * is also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1997 by James Carlson and Working Code
 */

#ifndef MP_H
#define MP_H

/* Individual PPP link or bundle level */
struct ppp_link {
    struct ppp_link *next;	/* Next link when using MP */
    struct xcp_state *xcp_list;	/* Pointer to list of protocols */
    int frame_drops;		/* Illegal frames discarded */
    void *handle;		/* User's handle */
    void (*link_output)(struct ppp_link *link, octet *outdata, int outlen,
			uint16 proto);
    void (*user_output)(void *handle, octet *outdata, int outlen);
    BOOLEAN acfc_in, acfc_out;	/* ACFC options negotiated */
    BOOLEAN pfc_in, pfc_out;	/* PFC options negotiated */
    struct mp_state *mp;	/* Backpointer to MP */
    BOOLEAN ecp_in_use;		/* ECP enabled */
    BOOLEAN ccp_in_use;		/* CCP enabled */
    int mtu;			/* MTU for link (peer's MRU or MRRU) */
    uint32 seq;			/* Last received MP sequence number */
    char *peername;		/* Authenticated peer name, if any */
    char *endpoint;		/* Peer's reported endpoint discriminator */
    int pn_size,ep_size;	/* Sizes of peer name and discriminator */
};

enum XcpState {
    Initial, Starting, Closed, Stopped, Closing, Stopping,
    ReqSent, AckRcvd, AckSent, Opened
};

/* LCP or NCP state */
struct xcp_state {
  struct xcp_state *next;	/* Next XCP on this PPP link */
  struct ppp_link *link;	/* Backpointer to link */
  enum XcpState state;		/* XCP state */
  octet id_number;		/* Current Configure-Request ID */
  octet unused;
  uint16 proto;			/* PPP Protocol ID */
  void (*handler)(struct xcp_state *xcp, octet *indata, int inlen);
  void (*send_data)(struct xcp_state *xcp, octet *outdata, int outlen);
};

/* Functions called by MP module. */
extern char *ecp_decrypt(struct xcp_state *xcp, char *indata, int *inlen);
extern char *ccp_uncompress(struct xcp_state *xcp, char *indata, int *inlen);
extern void ccp_uncompressed(struct xcp_state *xcp, uint16 proto,
			     char *indata, int inlen);
extern void lcp_handler(struct xcp_state *xcp, octet *indata, int inlen);

/*
 * Next level handler above HDLC or AHDLC.  Assumes that CRC has been
 * verified and removed, and that all escaping (transparency)
 * characters have been handled.  The PPP processing continues here by
 * decoding the address and control fields, then by demultiplexing
 * based on the PPP protocol number.
 */
extern void link_receive(struct ppp_link *lptr, octet *indata, int inlen);

/* Normal data sender for most NCP protocols. */
extern void generic_sender(struct xcp_state *xcp, octet *outdata, int outlen);

/* Find a matching bundle head or create a new one. */
extern struct ppp_link *find_bundle_head(struct ppp_link *newlink);

/* Create a new PPP state structure for a single PPP link. */
extern void *create_ppp_link(void *handle,
			     void (*outhandler)(void *handle,
						octet *data,
						int datalen));

/* Remove storage associated with an XCP. */
extern void destroy_xcp(struct xcp_state *xcp);

/* Tear down a PPP link. */
extern void destroy_ppp_link(void *link);

/* Add an XCP to an existing PPP session */
extern void *add_xcp(struct ppp_link *lptr, uint16 proto,
		     void (*handler)(struct xcp_state *xcp, octet *indata,
				     int inlen),
		     void (*sender)(struct xcp_state *xcp, octet *indata,
				    int inlen));

/* Remove an XCP from a PPP session */
extern void destroy_xcp(struct xcp_state *xcp);

/* Only for testing purposes. */
extern void set_link_mtu(void *handle, int mtu);

#define PPP_PROTO_MP		0x003D
#define PPP_PROTO_EP		0x0053
#define PPP_PROTO_EP_LINK	0x0055
#define PPP_PROTO_CP_LINK	0x00FB
#define PPP_PROTO_CP		0x00FD
#define PPP_PROTO_ECP		0x8053
#define PPP_PROTO_ECP_LINK	0x8055
#define PPP_PROTO_CCP_LINK	0x80FB
#define PPP_PROTO_CCP		0x80FD
#define PPP_PROTO_LCP		0xC021
#define PPP_PROTO_PAP		0xC023
#define PPP_PROTO_CHAP		0xC223
#define PROTO_REJ	8
#define MIN_FRAG_SIZE	200
#define MP_BEGIN 0x80
#define MP_END 0x40
#define MAX_MRRU	2048

#endif /* MP_H */
