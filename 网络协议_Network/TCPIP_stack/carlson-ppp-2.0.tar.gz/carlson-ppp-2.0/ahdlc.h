/*
 * This code shows a simple AHDLC interface.  It assumes that some
 * kind of serial hardware with FIFOs is in use and that interrupts
 * from this hardware and from the PPP system above can be disabled
 * and that the CPU uses 8 bit bytes and 32 bit longs.
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code
 * is also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1997 by James Carlson and Working Code
 */

#ifndef AHDLC_H
#define AHDLC_H

#include "sysdep.h"

extern void *ahdlc_create(void);
extern void ahdlc_destroy(void *statep);
extern void ahdlc_handlers(void *statep, void *userstate,
			   void (*userrcv)(void *state, octet *buffer,
					   int length),
			   void (*userxmt)(void *state, octet **bufferp,
					   int *lengthp));
extern void ahdlc_receive(void *statep, char *buffer, int count);
extern int ahdlc_transmit(void *statep, char *buffer, int maxcount);
extern void ahdlc_sync_wait(void *statep);
extern void ahdlc_set_accm(void *statep, unsigned long rx_accm,
			   unsigned long tx_accm);
extern void ahdlc_set_crc_mode(void *statep, int mode);
extern void ahdlc_set_sbdpt(void *statep, int onoff);
extern void ahdlc_report_on_failure(void *statep);

#endif /* AHDLC_H */
