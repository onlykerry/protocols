/*
 * A minimal implementation of PPP tunneled over UDP.  This implements
 * just LCP and IPCP, and then only a subset of each of those.  This
 * is not supported and probably shouldn't be used for much more than
 * simple experiments with PPP.  If you need a real version of PPP,
 * see Paul Mackerras' ppp-2.3.  If you do try to use this, don't say
 * I didn't warn you.
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code
 * is also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1997 by James Carlson and Working Code
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <unistd.h>
#include <strings.h>
#include <time.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#ifdef _AIX
#include <sys/select.h>
#endif
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

#define MAX_TERMINATE 2
#define MAX_CONFIGURE 10
#define MAX_FAILURE 5
#define INITIAL_TIMEOUT 2
#define MAX_TIMEOUT 8
#define DEFAULT_MRU 1500
#define MAX_WAIT 40		/* Maximum wait time for PPP to come up. */

#define Dim(x)	(sizeof(x)/sizeof(*(x)))

int remote_ip_base = 0x0A000000;
int remote_ip_mask = 0xFF000000;

char *myname;
int showpackets = 0, debugphases = 0, debugstates = 0, debugactions = 0;
int showraw = 0, debugtimer = 0;

void
usage(void)
{
    fprintf(stderr,"\nUsage:\n\t%s [-adpstv] <peer-IP> [<peer-port> [<local-port>]]\n\n",
	    myname);
    fprintf(stderr,"\t-a\tShow state machine actions\n");
    fprintf(stderr,"\t-d\tShow raw data\n");
    fprintf(stderr,"\t-p\tShow link phases\n");
    fprintf(stderr,"\t-s\tShow XCP states\n");
    fprintf(stderr,"\t-t\tShow timer actions\n");
    fprintf(stderr,"\t-v\tShow negotiation packets\n");
    exit(1);
}

/* Look up UDP port number. */
int
resolve_port(char *port_name)
{
    struct servent *sp;
    char *cp;
    int pnum;

    if (port_name != NULL) {
	sp = getservbyname(port_name,"udp");
	if (sp == NULL) {
	    pnum = strtol(port_name,&cp,0);
	    if (pnum <= 0 || pnum > 65535 || port_name == cp || *cp != '\0') {
		fprintf(stderr,"Illegal port name/number '%s'\n",port_name);
		return -1;
	    }
	    pnum = htons(pnum);
	} else
	    pnum = sp->s_port;
    } else
	pnum = htons(5001);
    return pnum;
}

/* Set up connected UDP socket. */
int
set_up_tunnel(char **argv)
{
    struct sockaddr_in sin,bsin;
    struct hostent *hp;
    int sock = -1,nlen;
    char *host_name;

    host_name = *argv++;

    if (host_name == NULL) {
	fprintf(stderr,"Must specify a peer name or IP address.\n");
	return -1;
    }

    memset(&sin,0,sizeof(sin));
    memset(&bsin,0,sizeof(bsin));
    sin.sin_port = resolve_port(*argv);
    bsin.sin_port = resolve_port(*argv?argv[1]:NULL);

    hp = gethostbyname(host_name);

    if (hp == NULL) {
	sin.sin_family = AF_INET;
	if ((sin.sin_addr.s_addr = inet_addr(host_name)) ==
	    (unsigned long)-1) {
	    (void)fprintf(stderr,
			  "%s:  Host \"%s\" not found.\n",
			  myname,host_name);
	    return -1;
	}
    } else {
	memcpy((char *)&sin.sin_addr,(char *)hp->h_addr,hp->h_length);
	sin.sin_family = hp->h_addrtype;
    }

    sock = socket(AF_INET,SOCK_DGRAM,0);
    if (sock < 0) {
	perror("socket");
	return -1;
    }
    nlen = 1;
    if (setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,(char *)&nlen,sizeof(nlen)) ==
	-1) {
	perror("setsockopt");
	close(sock);
	return -1;
    }
    bsin.sin_family = AF_INET;
    bsin.sin_addr.s_addr = INADDR_ANY;
    if (bind(sock,(struct sockaddr *)&bsin,sizeof(bsin)) == -1) {
	perror("bind");
	close(sock);
	return -1;
    }
    nlen = sizeof(bsin);
    if (getsockname(sock,(struct sockaddr *)&bsin,&nlen) == -1) {
	perror("getsockname");
	close(sock);
	return -1;
    }
    if (connect(sock,(struct sockaddr *)&sin,sizeof(sin)) == -1) {
	perror("connect");
	close(sock);
	return -1;
    }
    printf("Tunnel from %s:%d to ",inet_ntoa(bsin.sin_addr),
	   ntohs(bsin.sin_port));
    printf("%s:%d.\n",inet_ntoa(sin.sin_addr),ntohs(sin.sin_port));
    return sock;
}

/* Handle fatal negotiation timeout. */
void
alarm_handle(dummy)
int dummy;
{
    fprintf(stderr,"PPP failed to negotiate in prescribed time; shutting down.\n");
    exit(1);
}

/* Standard link phases */
enum ppp_phase {
    phDead, phEstablish, phAuthenticate, phNetwork, phTerminate
};
const char *ph_str[] = {
    "Dead", "Establish", "Authenticate", "Network", "Terminate"
};

/* Standard set of events */
enum ppp_event {
    evUp = 0, evDown, evOpen, evClose, evTOp, evTOm,
    evRCRp, evRCRm, evRCA, evRCN, evRTR, evRTA,
    evRUC, evRXJp, evRXJm, evRXR
};
const char *ev_str[] = {
    "Up", "Down", "Open", "Close", "TO+", "TO-",
    "RCR+", "RCR-", "RCA", "RCN", "RTR", "RTA",
    "RUC", "RXJ+", "RXJ-", "RXR"
};

/* Standard negotiation states */
enum xcp_state {
    stInitial = 0, stStarting, stClosed, stStopped, stClosing, stStopping,
    stReqSent, stAckRcvd, stAckSent, stOpened,
    stNoChange
};
const char *st_str[] = {
    "Initial", "Starting", "Closed", "Stopped", "Closing", "Stopping",
    "Req-Sent", "Ack-Rcvd", "Ack-Sent", "Opened",
    "No-Change"
};

/* Standard set of actions */
enum xcp_action {
    acNull, acIrc, acScr, acTls, acTlf, acStr, acSta, acSca, acScn, acScj,
    acTld, acTlu, acZrc, acSer
};
const char *ac_str[] = {
    "Null", "irc", "scr", "tls", "tlf", "str", "sta", "sca", "scn", "scj",
    "tld", "tlu", "zrc", "ser"
};

/* Dispatch table from RFC 1661 */
const struct ppp_dispatch {
    enum xcp_state next;
    enum xcp_action act[3];
} ppp_dispatch[10][16] = {
    { /* stInitial */
	/* evUp */    { stClosed, { acNull, acNull, acNull } },
	/* evDown */  { stNoChange, { acNull, acNull, acNull } },
	/* evOpen */  { stStarting, { acTls, acNull, acNull } },
	/* evClose */ { stClosed, { acNull, acNull, acNull } },
	/* evTOp */   { stNoChange, { acNull, acNull, acNull } },
	/* evTOm */   { stNoChange, { acNull, acNull, acNull } },
	/* evRCRp */  { stNoChange, { acNull, acNull, acNull } },
	/* evRCRm */  { stNoChange, { acNull, acNull, acNull } },
	/* evRCA */   { stNoChange, { acNull, acNull, acNull } },
	/* evRCN */   { stNoChange, { acNull, acNull, acNull } },
	/* evRTR */   { stNoChange, { acNull, acNull, acNull } },
	/* evRTA */   { stNoChange, { acNull, acNull, acNull } },
	/* evRUC */   { stNoChange, { acNull, acNull, acNull } },
	/* evRXJp */  { stNoChange, { acNull, acNull, acNull } },
	/* evRXJm */  { stNoChange, { acNull, acNull, acNull } },
	/* evRXR */   { stNoChange, { acNull, acNull, acNull } },
    },
    { /* stStarting */
	/* evUp */    { stReqSent, { acIrc, acScr, acNull } },
	/* evDown */  { stNoChange, { acNull, acNull, acNull } },
	/* evOpen */  { stStarting, { acNull, acNull, acNull } },
	/* evClose */ { stInitial, { acTlf, acNull, acNull } },
	/* evTOp */   { stNoChange, { acNull, acNull, acNull } },
	/* evTOm */   { stNoChange, { acNull, acNull, acNull } },
	/* evRCRp */  { stNoChange, { acNull, acNull, acNull } },
	/* evRCRm */  { stNoChange, { acNull, acNull, acNull } },
	/* evRCA */   { stNoChange, { acNull, acNull, acNull } },
	/* evRCN */   { stNoChange, { acNull, acNull, acNull } },
	/* evRTR */   { stNoChange, { acNull, acNull, acNull } },
	/* evRTA */   { stNoChange, { acNull, acNull, acNull } },
	/* evRUC */   { stNoChange, { acNull, acNull, acNull } },
	/* evRXJp */  { stNoChange, { acNull, acNull, acNull } },
	/* evRXJm */  { stNoChange, { acNull, acNull, acNull } },
	/* evRXR */   { stNoChange, { acNull, acNull, acNull } },
    },
    { /* stClosed */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stInitial, { acNull, acNull, acNull } },
	/* evOpen */  { stReqSent, { acIrc, acScr, acNull } },
	/* evClose */ { stClosed, { acNull, acNull, acNull } },
	/* evTOp */   { stNoChange, { acNull, acNull, acNull } },
	/* evTOm */   { stNoChange, { acNull, acNull, acNull } },
	/* evRCRp */  { stClosed, { acSta, acNull, acNull } },
	/* evRCRm */  { stClosed, { acSta, acNull, acNull } },
	/* evRCA */   { stClosed, { acSta, acNull, acNull } },
	/* evRCN */   { stClosed, { acSta, acNull, acNull } },
	/* evRTR */   { stClosed, { acSta, acNull, acNull } },
	/* evRTA */   { stClosed, { acNull, acNull, acNull } },
	/* evRUC */   { stClosed, { acScj, acNull, acNull } },
	/* evRXJp */  { stClosed, { acNull, acNull, acNull } },
	/* evRXJm */  { stClosed, { acTlf, acNull, acNull } },
	/* evRXR */   { stClosed, { acNull, acNull, acNull } },
    },
    { /* stStopped */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stStarting, { acTls, acNull, acNull } },
	/* evOpen */  { stStopped, { acNull, acNull, acNull } },
	/* evClose */ { stClosed, { acNull, acNull, acNull } },
	/* evTOp */   { stNoChange, { acNull, acNull, acNull } },
	/* evTOm */   { stNoChange, { acNull, acNull, acNull } },
	/* evRCRp */  { stAckSent, { acIrc, acScr, acSca } },
	/* evRCRm */  { stReqSent, { acIrc, acScr, acScn } },
	/* evRCA */   { stStopped, { acSta, acNull, acNull } },
	/* evRCN */   { stStopped, { acSta, acNull, acNull } },
	/* evRTR */   { stStopped, { acSta, acNull, acNull } },
	/* evRTA */   { stStopped, { acNull, acNull, acNull } },
	/* evRUC */   { stStopped, { acScj, acNull, acNull } },
	/* evRXJp */  { stStopped, { acNull, acNull, acNull } },
	/* evRXJm */  { stStopped, { acTlf, acNull, acNull } },
	/* evRXR */   { stStopped, { acNull, acNull, acNull } },
    },
    { /* stClosing */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stInitial, { acNull, acNull, acNull } },
	/* evOpen */  { stStopping, { acNull, acNull, acNull } },
	/* evClose */ { stClosing, { acNull, acNull, acNull } },
	/* evTOp */   { stClosing, { acStr, acNull, acNull } },
	/* evTOm */   { stClosed, { acTlf, acNull, acNull } },
	/* evRCRp */  { stClosing, { acNull, acNull, acNull } },
	/* evRCRm */  { stClosing, { acNull, acNull, acNull } },
	/* evRCA */   { stClosing, { acNull, acNull, acNull } },
	/* evRCN */   { stClosing, { acNull, acNull, acNull } },
	/* evRTR */   { stClosing, { acSta, acNull, acNull } },
	/* evRTA */   { stClosed, { acTlf, acNull, acNull } },
	/* evRUC */   { stClosing, { acScj, acNull, acNull } },
	/* evRXJp */  { stClosing, { acNull, acNull, acNull } },
	/* evRXJm */  { stClosed, { acTlf, acNull, acNull } },
	/* evRXR */   { stClosing, { acNull, acNull, acNull } },
    },
    { /* stStopping */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stInitial, { acNull, acNull, acNull } },
	/* evOpen */  { stStopping, { acNull, acNull, acNull } },
	/* evClose */ { stClosing, { acNull, acNull, acNull } },
	/* evTOp */   { stStopping, { acStr, acNull, acNull } },
	/* evTOm */   { stStopped, { acTlf, acNull, acNull } },
	/* evRCRp */  { stStopping, { acNull, acNull, acNull } },
	/* evRCRm */  { stStopping, { acNull, acNull, acNull } },
	/* evRCA */   { stStopping, { acNull, acNull, acNull } },
	/* evRCN */   { stStopping, { acNull, acNull, acNull } },
	/* evRTR */   { stStopping, { acSta, acNull, acNull } },
	/* evRTA */   { stStopped, { acTlf, acNull, acNull } },
	/* evRUC */   { stStopping, { acScj, acNull, acNull } },
	/* evRXJp */  { stStopping, { acNull, acNull, acNull } },
	/* evRXJm */  { stStopped, { acTlf, acNull, acNull } },
	/* evRXR */   { stStopping, { acNull, acNull, acNull } },
    },
    { /* stReqSent */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stStarting, { acNull, acNull, acNull } },
	/* evOpen */  { stReqSent, { acNull, acNull, acNull } },
	/* evClose */ { stClosing, { acIrc, acStr, acNull } },
	/* evTOp */   { stReqSent, { acScr, acNull, acNull } },
	/* evTOm */   { stStopped, { acTlf, acNull, acNull } },
	/* evRCRp */  { stAckSent, { acSca, acNull, acNull } },
	/* evRCRm */  { stReqSent, { acScn, acNull, acNull } },
	/* evRCA */   { stAckRcvd, { acIrc, acNull, acNull } },
	/* evRCN */   { stReqSent, { acIrc, acScr, acNull } },
	/* evRTR */   { stReqSent, { acSta, acNull, acNull } },
	/* evRTA */   { stReqSent, { acNull, acNull, acNull } },
	/* evRUC */   { stReqSent, { acScj, acNull, acNull } },
	/* evRXJp */  { stReqSent, { acNull, acNull, acNull } },
	/* evRXJm */  { stStopped, { acTlf, acNull, acNull } },
	/* evRXR */   { stReqSent, { acNull, acNull, acNull } },
    },
    { /* stAckRcvd */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stStarting, { acNull, acNull, acNull } },
	/* evOpen */  { stAckRcvd, { acNull, acNull, acNull } },
	/* evClose */ { stClosing, { acIrc, acStr, acNull } },
	/* evTOp */   { stReqSent, { acScr, acNull, acNull } },
	/* evTOm */   { stStopped, { acTlf, acNull, acNull } },
	/* evRCRp */  { stOpened, { acSca, acTlu, acNull } },
	/* evRCRm */  { stAckRcvd, { acScn, acNull, acNull } },
	/* evRCA */   { stReqSent, { acScr, acNull, acNull } },
	/* evRCN */   { stReqSent, { acScr, acNull, acNull } },
	/* evRTR */   { stReqSent, { acSta, acNull, acNull } },
	/* evRTA */   { stReqSent, { acNull, acNull, acNull } },
	/* evRUC */   { stAckRcvd, { acScj, acNull, acNull } },
	/* evRXJp */  { stReqSent, { acNull, acNull, acNull } },
	/* evRXJm */  { stStopped, { acTlf, acNull, acNull } },
	/* evRXR */   { stAckRcvd, { acNull, acNull, acNull } },
    },
    { /* stAckSent */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stStarting, { acNull, acNull, acNull } },
	/* evOpen */  { stAckSent, { acNull, acNull, acNull } },
	/* evClose */ { stClosing, { acIrc, acStr, acNull } },
	/* evTOp */   { stAckSent, { acScr, acNull, acNull } },
	/* evTOm */   { stStopped, { acTlf, acNull, acNull } },
	/* evRCRp */  { stAckSent, { acSca, acNull, acNull } },
	/* evRCRm */  { stReqSent, { acScn, acNull, acNull } },
	/* evRCA */   { stOpened, { acIrc, acTlu, acNull } },
	/* evRCN */   { stAckSent, { acIrc, acScr, acNull } },
	/* evRTR */   { stReqSent, { acSta, acNull, acNull } },
	/* evRTA */   { stAckSent, { acNull, acNull, acNull } },
	/* evRUC */   { stAckSent, { acScj, acNull, acNull } },
	/* evRXJp */  { stAckSent, { acNull, acNull, acNull } },
	/* evRXJm */  { stStopped, { acTlf, acNull, acNull } },
	/* evRXR */   { stAckSent, { acNull, acNull, acNull } },
    },
    { /* stOpened */
	/* evUp */    { stNoChange, { acNull, acNull, acNull } },
	/* evDown */  { stStarting, { acTld, acNull, acNull } },
	/* evOpen */  { stOpened, { acNull, acNull, acNull } },
	/* evClose */ { stClosing, { acTld, acIrc, acStr } },
	/* evTOp */   { stNoChange, { acNull, acNull, acNull } },
	/* evTOm */   { stNoChange, { acNull, acNull, acNull } },
	/* evRCRp */  { stAckSent, { acTld, acScr, acSca } },
	/* evRCRm */  { stReqSent, { acTld, acScr, acScn } },
	/* evRCA */   { stReqSent, { acTld, acScr, acNull } },
	/* evRCN */   { stReqSent, { acTld, acScr, acNull } },
	/* evRTR */   { stStopping, { acTld, acZrc, acSta } },
	/* evRTA */   { stReqSent, { acTld, acScr, acNull } },
	/* evRUC */   { stOpened, { acScj, acNull, acNull } },
	/* evRXJp */  { stOpened, { acNull, acNull, acNull } },
	/* evRXJm */  { stStopping, { acTld, acIrc, acStr } },
	/* evRXR */   { stOpened, { acSer, acNull, acNull } },
    }
};

/* Standard message code numbers */
#define CODE_CONF_REQ	1
#define CODE_CONF_ACK	2
#define CODE_CONF_NAK	3
#define CODE_CONF_REJ	4
#define CODE_TERM_REQ	5
#define CODE_TERM_ACK	6
#define CODE_CODE_REJ	7
#define CODE_PROTO_REJ	8
#define CODE_ECHO_REQ	9
#define CODE_ECHO_REP	10
#define CODE_DISCARD_REQ	11
const char *code_str[] = {
    "Vendor", "Configure-Request", "Configure-Ack", "Configure-Nak",
    "Configure-Reject", "Terminate-Request", "Terminate-Ack", "Code-Reject",
    "Protocol-Reject", "Echo-Request", "Echo-Reply", "Discard-Request"
};

#define PROT_LCP	0xC021
#define PROT_IPCP	0x8021

struct ppp_xcp;
struct ppp_state;

/* Basic information about an option. */
struct xcp_type {
    const char *name;		/* Printable name */
    short type;			/* option number (-1 to end) */
    short flag;			/* set to ignore default value */
    unsigned char minlen;	/* minimum overall length */
    unsigned char maxlen;	/* maximum overall length */
    int default_value;		/* default */
    void (*validate_req)(struct ppp_state *state,
			 struct ppp_xcp *xcp,
			 const struct xcp_type *tp,
			 const unsigned char *buf,
			 int len);
    void (*validate_nak)(struct ppp_state *state,
			 struct ppp_xcp *xcp,
			 const struct xcp_type *tp,
			 const unsigned char *buf,
			 int len);
    void (*show)(const struct ppp_state *state,
		 const struct ppp_xcp *xcp,
		 const struct xcp_type *tp,
		 const unsigned char *buf,
		 int len);
};

const struct xcp_type lcp_types[] = {
    { NULL, -1, 0, 0, 0, 0, NULL, NULL, NULL }
};

void ipcp_addr_req(struct ppp_state *state,
		   struct ppp_xcp *xcp,
		   const struct xcp_type *tp,
		   const unsigned char *buf,
		   int len);
void ipcp_addr_nak(struct ppp_state *state,
		   struct ppp_xcp *xcp,
		   const struct xcp_type *tp,
		   const unsigned char *buf,
		   int len);
void ipcp_addr_show(const struct ppp_state *state,
		    const struct ppp_xcp *xcp,
		    const struct xcp_type *tp,
		    const unsigned char *buf,
		    int len);
const struct xcp_type ipcp_types[] = {
    { "IP-Address", 3, 1, 6, 6, 0, ipcp_addr_req, ipcp_addr_nak,
      ipcp_addr_show },
    { NULL, -1, 0, 0, 0, 0, NULL, NULL, NULL }
};

struct option_state {
    int my_value;			/* sent in Configure-Request */
    int peer_value;			/* last received */
    enum { osUsable, osUnusable } state;	/* flag for rejects */
};

struct ppp_xcp {
    const char *name;			/* name of control protocol */
    enum xcp_state state;		/* state machine */
    int restart;			/* standard restart count */
    time_t restart_point;		/* standard restart timer */
    int naks_sent;			/* consecutive naks sent */
    void (*deliver)(struct ppp_state *state,	/* handler */
		    struct ppp_xcp *xcp);
    const struct xcp_type *types;	/* option types supported here */
    struct option_state *opts;		/* current negotiation state */
    unsigned short proto;		/* PPP protocol ID */
    unsigned char ident;		/* current ID number */
};

enum parse_state { psOK, psNak, psRej, psBad };

struct ppp_state {
    enum ppp_phase phase;		/* link phase */
    enum parse_state parse_state;	/* request parsing state */
    int sock;				/* connection to physical layer */
    int timeout_period;			/* value for restart timer */
    int mlen;				/* packet length */
    unsigned long mymagic,hismagic;	/* magic numbers (for echo) */
    unsigned char *bp,*up;		/* pointers to packet buffers */
    struct ppp_xcp xcps[2];		/* installed XCPs */
    unsigned char inbuffer[1600],upbuf[1500];
};

#define XCP_LCP 0
#define XCP_IPCP 1

void send_event(struct ppp_state *state, struct ppp_xcp *xcp,
		enum ppp_event event);
void change_phase(struct ppp_state *state, enum ppp_phase phase);

/* Display contents of buffer */
void
buffer_print(const char *verb, const unsigned char *buf, int len)
{
    int i,j;
    struct tm *tm;
    time_t now;

    now = time(NULL);
    tm = localtime(&now);
    printf("%02d:%02d %s %d bytes:\n",tm->tm_min,tm->tm_sec,verb,len);
    for (i = 0; i < len; i += 16) {
	printf("  %04X: ",i);
	for (j = i; j < len && j < i+16; j++)
	    printf(" %02X",buf[j]);
	putchar('\n');
    }
}

/* Print text string safely. */
void
safe_string(const unsigned char *bp, int len)
{
    char chr;

    putchar('"');
    while (--len >= 0) {
	chr = *bp++;
	if (isascii(chr) && isprint(chr))
	    putchar(chr);
	else
	    printf("\\%03o",chr);
    }
    putchar('"');
}

/* Show all options in negotiation message. */
void
option_show(const struct ppp_state *state,
	    const struct ppp_xcp *xcp,
	    const unsigned char *bp,
	    int rlen)
{
    int i;
    const struct xcp_type *tp;

    while (rlen > 0) {
	putchar(' ');
	if (rlen < 2) {
	    printf("[trail %02X]\n",bp[0]);
	    break;
	}
	if (bp[1] > rlen) {
	    printf("[trunc %02X %d>%d]\n",bp[0],bp[1],rlen);
	    break;
	}
	for (tp = xcp->types; tp->type != -1; tp++)
	    if (tp->type == bp[0])
		break;
	if (tp->show != NULL) {
	    /* Valid option; use defined printing routine */
	    (*tp->show)(state,xcp,tp,bp+2,bp[1]);
	} else {
	    /* Undefined option; just dump contents. */
	    if (tp->name == NULL)
		printf("%02X:",bp[0]);
	    else
		printf("%s:",tp->name);
	    for (i = 2; i < bp[1]; i++)
		printf("%02X",bp[i]);
	}
	if ((i = bp[1]) < 2)
	    i = 2;
	rlen -= i;
	bp += i;
    }
}

/*
 * Show a negotiation packet.
 * Assumes 'bp' points to the code number (after PPP Protocol ID).
 */
void
show_neg_packet(const char *inout, const struct ppp_state *state,
		const struct ppp_xcp *xcp,
		const unsigned char *bp, int len)
{
    int code, id, length;

    code = *bp++;
    id = *bp++;
    length = (bp[0] << 8) + bp[1];
    bp += 2;
    if (len > length)
	len = length;
    len -= 4;

    printf("%s %s ",inout,xcp->name);
    if (code < Dim(code_str) && code_str[code] != NULL)
	printf("%s",code_str[code]);
    else
	printf("code:%d",code);
    printf(" ID:%d",id);
    if ((code == CODE_CONF_ACK || code == CODE_CONF_NAK ||
	 code == CODE_CONF_REJ || code == CODE_TERM_ACK ||
	 code == CODE_ECHO_REP) && id != xcp->ident)
	printf(" **ERR**");
    printf(" len:%d",length);
    switch (code) {
    case CODE_CONF_REQ: case CODE_CONF_ACK:
    case CODE_CONF_NAK: case CODE_CONF_REJ:
	option_show(state,xcp,bp,len);
	break;
    case CODE_TERM_REQ: case CODE_TERM_ACK:
	if (len > 0) {
	    putchar(' ');
	    safe_string(bp,len);
	}
	break;
    case CODE_CODE_REJ:
	printf(" code %d",*bp);
	break;
    case CODE_PROTO_REJ:
	printf(" protocol %02X%02X",bp[0],bp[1]);
	break;
    case CODE_ECHO_REQ: case CODE_ECHO_REP:
    case CODE_DISCARD_REQ:
	if (len >= 4)
	    printf(" magic %02X%02X%02X%02X",bp[0],bp[1],bp[2],bp[3]);
	if (len > 4) {
	    putchar(' ');
	    safe_string(bp+4,len-4);
	}
	break;
    }
    putchar('\n');
}

/*
 * Write packet to tunnel.  Display contents if debugging.
 * (Wrapper around recalcitrant system call interface.)
 */
void
ppp_write(const struct ppp_state *state, const struct ppp_xcp *xcp,
	  const unsigned char *buf, int len)
{
    int retv,sock;

    if (showraw)
	buffer_print("Transmitting",buf,len);
    if (showpackets) {
	retv = buf[0] == 0xFF ? 2 : 0;
	retv += buf[retv] & 1 ? 1 : 2;
	show_neg_packet("SENT",state,xcp,buf+retv,len-retv);
    }
    sock = state->sock;
    for (;;) {
	retv = write(sock,buf,len);
	if (retv < 0) {
	    if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
		continue;
	    perror("write");
	    exit(1);
	}
	break;
    }
}

/*
 * Insert HDLC Address/Control and PPP protocol fields.
 */
unsigned char *
set_up_acpf(unsigned char *buf, int proto)
{
    buf[0] = 0xFF;
    buf[1] = 0x03;
    buf[2] = proto>>8;
    buf[3] = proto&0xFF;
    return buf+4;
}

/*
 * Set up buffer for a new message (Configure-Request, Protocol-Reject,
 * Echo-Request, or Discard-Request).
 */
unsigned char *
code_id(struct ppp_state *state, struct ppp_xcp *xcp, int code)
{
    unsigned char *buf;

    buf = set_up_acpf(state->upbuf,xcp->proto);
    *buf++ = code;
    *buf++ = ++xcp->ident;
    *buf++ = 0;
    *buf++ = 4;
    return buf;
}

/*
 * Set up buffer for a reply to a previous message (Configure-Ack,
 * Configure-Nak, Configure-Reject, Echo-Reply).
 */
unsigned char *
code_reply(struct ppp_state *state, struct ppp_xcp *xcp, int code)
{
    unsigned char *buf;

    buf = set_up_acpf(state->upbuf,xcp->proto);
    *buf++ = code;
    *buf++ = state->inbuffer[5];
    *buf++ = 0;
    *buf++ = 4;
    return buf;
}

/*
 * Find a given option in the list for an XCP.
 */
struct option_state *
find_option(const struct ppp_xcp *xcp, int type)
{
    const struct xcp_type *tp;

    for (tp = xcp->types; tp->type != -1; tp++)
	if (tp->type == type)
	    return xcp->opts+(tp-xcp->types);
    return NULL;
}

/*
 * Loop over all known options and insert into a Configure-Request
 * being built.
 */
void
create_request(struct ppp_state *state,
	       struct ppp_xcp *xcp)
{
    unsigned char *bp,*obp;
    const struct xcp_type *tp;
    struct option_state *os;

    obp = bp = code_id(state,xcp,CODE_CONF_REQ);
    for (tp = xcp->types, os = xcp->opts; tp->type != -1; tp++, os++) {
	if (os->state == osUnusable)
	    continue;
	if (!tp->flag && os->my_value == tp->default_value)
	    continue;
	bp[0] = tp->type;
	bp[1] = tp->minlen;
	if (tp->minlen > 2)
	    bp[2] = (os->my_value >> (8 * (tp->minlen-3))) & 0xFF;
	if (tp->minlen > 3)
	    bp[3] = (os->my_value >> (8 * (tp->minlen-4))) & 0xFF;
	if (tp->minlen > 4)
	    bp[4] = (os->my_value >> (8 * (tp->minlen-5))) & 0xFF;
	if (tp->minlen > 5)
	    bp[5] = os->my_value & 0xFF;
	bp += bp[1];
    }
    *(unsigned short *)(obp - 2) = htons((bp-obp)+4);
    state->up = bp;
}

/*
 * We've gotten a Configure-Request we like (RCR+), so we're agreeing
 * with the peer.  Set up to send Configure-Ack.
 */
void
copy_peer_values(const struct ppp_state *state,
		 struct ppp_xcp *xcp)
{
    const unsigned char *bp;
    const struct xcp_type *tp;
    struct option_state *os;
    int rlen,val;

    for (tp = xcp->types, os = xcp->opts; tp->type != -1; tp++, os++)
	os->peer_value = tp->default_value;
    bp = state->bp;
    rlen = state->mlen;
    while (rlen > 0) {
	for (tp = xcp->types; tp->type != -1; tp++)
	    if (tp->type == bp[0])
		break;
	os = xcp->opts + (tp-xcp->types);
	val = bp[2];
	if (bp[1] > 3)
	    val = (val << 8) + bp[3];
	if (bp[1] > 4)
	    val = (val << 8) + bp[4];
	if (bp[1] > 5)
	    val = (val << 8) + bp[5];
	os->peer_value = val;
	rlen -= bp[1];
	bp += bp[1];
    }
}

/*
 * Perform RFC 1661 actions as indicated by state machine.
 */
void
dispatch_action(struct ppp_state *state,
		struct ppp_xcp *xcp,
		enum xcp_action act)
{
    unsigned char *bp;

    if (act == acNull)
	return;
    if (debugactions)
	printf("%s action %s (%d)\n",xcp->name,ac_str[(int)act],(int)act);
    switch (act) {
    case acNull:
	break;

    case acIrc:
	xcp->restart = state->phase == phTerminate ? MAX_TERMINATE :
	    MAX_CONFIGURE;
	state->timeout_period = INITIAL_TIMEOUT;
	break;

    case acScr:
	if (xcp->restart > 0) {
	    xcp->restart--;
	    create_request(state,xcp);
	    ppp_write(state,xcp,state->upbuf,state->up-state->upbuf);
	}
	xcp->restart_point = time(NULL)+state->timeout_period;
	break;

    case acTls:
	if (xcp == &state->xcps[XCP_IPCP])
	    send_event(state,&state->xcps[XCP_LCP],evOpen);
	else
	    change_phase(state,phEstablish);
	break;

    case acTlf:
	if (xcp == &state->xcps[XCP_IPCP])
	    send_event(state,&state->xcps[XCP_LCP],evClose);
	else
	    change_phase(state,phTerminate);
	break;

    case acStr:
	if (xcp->restart > 0) {
	    xcp->restart--;
	    bp = code_id(state,xcp,CODE_TERM_REQ);
	    ppp_write(state,xcp,state->upbuf,bp-state->upbuf);
	}
	xcp->restart_point = time(NULL)+state->timeout_period;
	break;

    case acSta:
	bp = code_reply(state,xcp,CODE_TERM_ACK);
	ppp_write(state,xcp,state->upbuf,bp-state->upbuf);
	break;

    case acSca:
	copy_peer_values(state,xcp);
	state->inbuffer[4] = CODE_CONF_ACK;
	ppp_write(state,xcp,state->inbuffer,
		  state->mlen+(state->bp-state->inbuffer));
	break;

    case acScn:
	if (xcp->naks_sent++ >= MAX_FAILURE)
	    state->upbuf[4] = CODE_CONF_REJ;
    case acScj:
	ppp_write(state,xcp,state->upbuf,state->up-state->upbuf);
	break;

    case acTld:
	if (xcp == &state->xcps[XCP_LCP])
	    change_phase(state,phTerminate);
	else
	    printf("IPCP is now down!\n");
	break;

    case acTlu:
	if (xcp == &state->xcps[XCP_LCP])
	    change_phase(state,phAuthenticate);
	else {
	    struct option_state *os = find_option(xcp,3);
	    struct in_addr addr;

	    addr.s_addr = htonl(os->my_value);
	    printf("IPCP is now up!  Local address %s, ",
		   inet_ntoa(addr));
	    addr.s_addr = htonl(os->peer_value);
	    printf("remote %s\n",inet_ntoa(addr));
	}
	xcp->restart = MAX_CONFIGURE;
	xcp->restart_point = 0;
	break;

    case acZrc:
	xcp->restart = 0;
	state->timeout_period = INITIAL_TIMEOUT;
	break;

    case acSer:
	state->inbuffer[4] = CODE_ECHO_REP;
	*(long *)(state->inbuffer+8) = htonl(state->mymagic);
	ppp_write(state,xcp,state->inbuffer,
		  state->mlen+(state->bp-state->inbuffer));
	break;
    }
}

/*
 * Issue event into XCP state machine -- go to next state and
 * invoke associated actions.
 */
void
send_event(struct ppp_state *state,
	   struct ppp_xcp *xcp,
	   enum ppp_event event)
{
    const struct ppp_dispatch *dp;

    dp = &ppp_dispatch[(int)xcp->state][(int)event];
    if (dp->next == stNoChange) {
	if (debugstates)
	    printf("%s got illegal %s event (%d) in %s state (%d)\n\
\t(RFC 1661 section 4.4)\n",
		   xcp->name,ev_str[(int)event],event,
		   st_str[(int)xcp->state],xcp->state);
    } else {
	if (debugstates)
	    printf("%s got %s event (%d) in %s state (%d), next is %s state (%d)\n",
		   xcp->name,ev_str[(int)event],event,
		   st_str[(int)xcp->state],xcp->state,
		   st_str[(int)dp->next],dp->next);
	xcp->state = dp->next;
    }
    dispatch_action(state,xcp,dp->act[0]);
    dispatch_action(state,xcp,dp->act[1]);
    dispatch_action(state,xcp,dp->act[2]);
}

/*
 * Change overall link phase.  Central routine helps with
 * debugging.
 */
void
change_phase(struct ppp_state *state,
	     enum ppp_phase phase)
{
    if (debugphases)
	printf("Current PPP phase is %s, switching to %s\n",
	       ph_str[(int)state->phase],ph_str[(int)phase]);
    switch (phase) {
    case phEstablish:
	if (state->phase == phDead)
	    send_event(state,&state->xcps[XCP_LCP],evUp);
	break;
    case phAuthenticate:
	break;
    case phNetwork:
	if (state->phase == phAuthenticate)
	    send_event(state,&state->xcps[XCP_IPCP],evUp);
	break;
    case phTerminate:
	send_event(state,&state->xcps[XCP_IPCP],evDown);
	break;
    case phDead:
	break;
    }
    state->phase = phase;
    if (phase == phAuthenticate)
	change_phase(state,phNetwork);		/* XXX - no auth yet */
}

/*
 * Main loop.  Handle timers and packet input.
 */
void
read_packets(struct ppp_state *state)
{
    unsigned char *bp;
    int retv,proto,i,rcvd_anything,alarm_running;
    struct timeval tv,*tvp;
    fd_set rfd;
    struct ppp_xcp *minsel;
    time_t now;

    rcvd_anything = 0;
    alarm_running = 0;
    for (;;) {
	/* Find earliest timer expiry. */
	tvp = NULL;
	tv.tv_sec = 1000;
	tv.tv_usec = 0;
	minsel = NULL;
	now = time(NULL);
	for (i = 0; i < Dim(state->xcps); i++)
	    if (state->xcps[i].restart_point != 0) {
		if (now > state->xcps[i].restart_point) {
		    tv.tv_sec = 0;
		} else if (now+tv.tv_sec > state->xcps[i].restart_point) {
		    tv.tv_sec = state->xcps[i].restart_point-now;
		} else
		    continue;
		minsel = state->xcps+i;
		tvp = &tv;
	    }

	/* If all NCPs up, then cancel main alarm. */
	if (minsel == NULL) {
	    alarm_running = 0;
	    alarm(0);
	} else if (!alarm_running) {
	    /*
	     * If NCP negotiation (re)started, then set alarm.  This
	     * acts as an overall time limit on negotiation.  If it
	     * takes longer than MAX_WAIT, then give up.
	     */
	    alarm_running = 1;
	    alarm(MAX_WAIT);
	}
	if (debugtimer) {
	    if (minsel == NULL)
		printf("No timers running.\n");
	    else
		printf("Timer set for %d seconds.\n",tv.tv_sec);
	}

	/* Wait for something. */
	FD_ZERO(&rfd);
	FD_SET(state->sock,&rfd);
	retv = select(state->sock+1,&rfd,NULL,NULL,tvp);

	/* Check for timer events. */
	if (retv >= 0 && minsel != NULL) {
	    if (retv == 0 && state->timeout_period < MAX_TIMEOUT)
		state->timeout_period <<= 1;
	    now = time(NULL);
	    for (i = 0; i < Dim(state->xcps); i++)
		if (state->xcps[i].restart_point == 0)
		    ;
		else if (now >= state->xcps[i].restart_point) {
		    if (retv == 0) {
			state->xcps[i].restart_point = 0;
			/* Hack -- send with same ID on timeout. */
			if (state->xcps[i].restart > 0)
			    state->xcps[i].ident--;
			if (debugtimer)
			    printf("Sending TO%c to %s\n",
				   state->xcps[i].restart > 0 ? '+' : '-',
				   state->xcps[i].name);
			send_event(state,state->xcps+i,
				   state->xcps[i].restart > 0 ? evTOp : evTOm);
		    } else /* Hack. */
			state->xcps[i].restart_point = now+1;
		}
	    /* If nothing waiting, then no need to read. */
	    if (retv == 0)
		continue;
	}

	/* Fetch input packet */
	if (retv > 0)
	    retv = read(state->sock,state->inbuffer,sizeof(state->inbuffer));
	if (retv <= 0) {
	    /* Wait for UDP peer to come up at least once. */
	    if (errno == ECONNREFUSED && !rcvd_anything)
		continue;
	    /* Ignore interrupt nonsense. */
	    if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
		continue;
	    if (retv < 0)
		perror("read");
	    break;
	}
	if (showraw)
	    buffer_print("Received",state->inbuffer,retv);

	rcvd_anything = 1;

	/* ACFC would go here. */
	if (state->inbuffer[0] != 0xFF || state->inbuffer[1] != 0x03) {
	    printf("Bad address and control field %02X %02X.\n",
		   state->inbuffer[0],state->inbuffer[1]);
	    continue;
	}

	/* PFC would go here. */
	if ((state->inbuffer[2] & 1) != 0 || (state->inbuffer[3] & 1) == 0) {
	    printf("Bad protocol field %02X %02X.\n",
		   state->inbuffer[2],state->inbuffer[3]);
	    continue;
	}

	/* Find XCP for indicated protocol */
	proto = ntohs(*(unsigned short *)(state->inbuffer+2));
	for (i = 0; i < Dim(state->xcps); i++)
	    if (state->xcps[i].proto == proto)
		break;
	if (i >= Dim(state->xcps)) {
	    /* Generate LCP Protocol-Reject for unknown things. */
	    printf("Unknown protocol %04X\n",proto);
	    if (state->xcps[XCP_LCP].state == stOpened) {
		bp = code_id(state,&state->xcps[XCP_LCP],
			     CODE_PROTO_REJ);
		i = sizeof(state->upbuf) - (bp-state->upbuf);
		retv -= 2;
		if (retv > i)
		    retv = i;
		memcpy(bp,state->inbuffer+2,retv);
		retv += bp-state->upbuf;
		*(unsigned short *)(state->upbuf+2) = htons(retv-4);
		ppp_write(state,&state->xcps[XCP_LCP],state->upbuf,retv);
	    }
	    continue;
	}

	/* Remove HDLC headers and PPP Protocol Field and deliver */
	state->bp = state->inbuffer+4;
	state->mlen = retv-4;
	(*state->xcps[i].deliver)(state,state->xcps+i);
    }
}

/*
 * Add current option to list of options to be sent in Configure-Reject.
 */
void
set_reject(struct ppp_state *state,
	   struct ppp_xcp *xcp,
	   const unsigned char *bp)
{
    int i;

    if (state->parse_state == psBad)
	return;
    /* If this is the first reject for this packet, then set up. */
    if (state->parse_state != psRej) {
	state->up = code_reply(state,xcp,CODE_CONF_REJ);
	state->parse_state = psRej;
    }
    /*
     * Handle malformed options; make sure we don't send anything illegal
     * to the peer (even if he's sending us junk).
     */
    if ((i = bp[1]) < 2)
	i = 2;
    memcpy(state->up,bp,i);
    state->up[1] = i;
    state->up += i;
}

/*
 * Add current option to list of options to be sent in Configure-Nak.
 */
void
set_nak(struct ppp_state *state,
	struct ppp_xcp *xcp,
	int type, int len,
	const unsigned char *bp)
{
    /* If we're rejecting, then no point in doing naks. */
    if (state->parse_state == psBad || state->parse_state == psRej)
	return;
    /* If this is the first nak for this packet, then set up. */
    if (state->parse_state != psNak) {
	state->up = code_reply(state,xcp,CODE_CONF_NAK);
	state->parse_state = psNak;
    }
    *state->up++ = type;
    *state->up++ = len;
    while (--len > 1)
	*state->up++ = *bp++;
}

/*
 * Check Configure-Request options from peer against list of
 * known, valid, and desired options.
 */
int
validate_request(struct ppp_state *state,
		 struct ppp_xcp *xcp)
{
    int rlen,i;
    const unsigned char *bp;
    const struct xcp_type *tp;

    state->parse_state = psOK;
    rlen = state->mlen;
    bp = state->bp;
    while (rlen > 0) {
	if (rlen < 2 || bp[1] > rlen) {
	    state->parse_state = psBad;
	    break;
	}
	for (tp = xcp->types; tp->type != -1; tp++)
	    if (tp->type == bp[0])
		break;
	if (tp->type == -1)
	    set_reject(state,xcp,bp);
	else if (bp[1] < tp->minlen)
	    set_nak(state,xcp,tp->type,tp->minlen,bp+2);
	else if (bp[1] > tp->maxlen)
	    set_nak(state,xcp,tp->type,tp->maxlen,bp+2);
	else if (tp->validate_req == NULL)
	    ;
	else
	    (*tp->validate_req)(state,xcp,tp,bp+2,bp[1]);
	if ((i = bp[1]) < 2)
	    i = 2;
	rlen -= i;
	bp += i;
    }
    if (state->parse_state == psNak || state->parse_state == psRej) {
	i = (state->up - state->upbuf) - 4;
	state->upbuf[6] = (i >> 8) & 0xFF;
	state->upbuf[7] = i & 0xFF;
    }
    return state->parse_state == psOK;
}

/*
 * Process options in a Configure-{Ack,Nak,Reject}.
 */
void
process_rcx(struct ppp_state *state,
	    struct ppp_xcp *xcp,
	    unsigned char code)
{
    int rlen,i,val;
    unsigned char *bp;
    const struct xcp_type *tp;
    struct option_state *os;

    rlen = state->mlen;
    bp = state->bp;
    while (rlen > 0) {
	if (rlen < 2 || bp[1] > rlen)
	    break;
	for (tp = xcp->types; tp->type != -1; tp++)
	    if (tp->type == bp[0])
		break;
	if (tp->type != -1) {
	    os = xcp->opts + (tp-xcp->types);
	    if (code == CODE_CONF_REJ)
		os->state = osUnusable;
	    else if (code == CODE_CONF_ACK || tp->validate_nak == NULL) {
		if (bp[1] > 6 || bp[1] <= 2)
		    os->my_value = tp->default_value;
		else {
		    val = bp[2];
		    if (bp[1] > 3)
			val = (val << 8) + bp[3];
		    if (bp[1] > 4)
			val = (val << 8) + bp[4];
		    if (bp[1] > 5)
			val = (val << 8) + bp[5];
		    os->my_value = val;
		}
	    } else
		(*tp->validate_nak)(state,xcp,tp,bp+2,bp[1]);
	}
	if ((i = bp[1]) < 2)
	    i = 2;
	rlen -= i;
	bp += i;
    }
}

/*
 * Standard negotiation entry point.  This is assigned as the
 * 'delivery' function for control protocols, like LCP and IPCP.
 */
void
std_negotiation(struct ppp_state *state,
		struct ppp_xcp *xcp)
{
    unsigned char code,id;
    unsigned short proto;
    int i,length;

    /* Validate overall message length */
    if (state->mlen < 4) {
	printf("Malformed negotiation message; %d < 4\n",
	       state->mlen);
	return;
    }
    code = *state->bp++;
    id = *state->bp++;
    length = (state->bp[0] << 8) + state->bp[1];
    if (length > state->mlen) {
	printf("Truncated negotiation message; %d > %d\n",
	       length,state->mlen);
	return;
    }
    if (length < state->mlen) {
	printf("Trimmed negotiation message; %d < %d\n",
	       length,state->mlen);
	state->mlen = length;
    }
    state->bp += 2;
    state->mlen -= 4;

    if (showpackets) {
	show_neg_packet("RCVD",state,xcp,state->bp-4,state->mlen+4);
    }

    /* Now switch out on received code number */
    switch (code) {
    case CODE_CONF_REQ:
	/* If request is good, then RCR+, if bad, then RCR- */
	if (validate_request(state,xcp))
	    send_event(state,xcp,evRCRp);
	else
	    send_event(state,xcp,evRCRm);
	break;
    case CODE_CONF_ACK:
	/* Configure-Ack ID number must match last sent. */
	if (id != xcp->ident)
	    break;
	/* Should validate contents against last req sent, but we don't. */
	process_rcx(state,xcp,code);
	send_event(state,xcp,evRCA);
	break;
    case CODE_CONF_NAK:
    case CODE_CONF_REJ:
	/* Configure-Nak/Reject ID number must match last sent. */
	if (id != xcp->ident)
	    break;
	process_rcx(state,xcp,code);
	send_event(state,xcp,evRCN);
	break;
    case CODE_TERM_REQ:
	send_event(state,xcp,evRTR);
	break;
    case CODE_TERM_ACK:
	if (id != xcp->ident)
	    break;
	send_event(state,xcp,evRTA);
	break;
    case CODE_CODE_REJ:
	code = *state->bp++;
	/* Peer cannot reject well-known code numbers. */
	if (code != 0 && code < CODE_ECHO_REQ) {
	    printf("Invalid code reject for %d\n",code);
	    send_event(state,xcp,evRXJm);
	} else
	    send_event(state,xcp,evRXJp);
	break;
    case CODE_PROTO_REJ:
	proto = (state->bp[0] << 8) + state->bp[1];
	/* Peer cannot reject LCP! */
	if (proto == state->xcps[XCP_LCP].proto) {
	    printf("Peer protocol-rejected LCP itself!\n");
	    send_event(state,&state->xcps[XCP_LCP],evRXJm);
	} else {
	    send_event(state,xcp,evRXJp);
	    for (i = 0; i < Dim(state->xcps); i++)
		if (state->xcps[i].proto == proto)
		    state->xcps[i].state = stInitial;
	}
	break;
    case CODE_ECHO_REQ:
	/* Should be sending a reply here. */
    case CODE_DISCARD_REQ:
	send_event(state,xcp,evRXR);
	break;
    case CODE_ECHO_REP:
	/* ID number in Echo-Reply must match last echo sent. */
	if (id != xcp->ident)
	    break;
	send_event(state,xcp,evRXR);
	break;
    default:
	state->bp -= 4;
	send_event(state,xcp,evRUC);
	break;
    }
}

/*
 * Initialize an XCP (LCP or NCP).
 */
void
init_xcp(const char *name, struct ppp_xcp *xcp,
	 void (*deliver)(struct ppp_state *state,
			 struct ppp_xcp *xcp),
	 const struct xcp_type *types,
	 int ntypes,
	 unsigned short proto)
{
    struct option_state *os;

    xcp->name = name;
    xcp->state = stInitial;
    xcp->restart = 0;
    xcp->restart_point = 0;
    xcp->deliver = deliver;
    xcp->types = types;
    xcp->proto = proto;
    /* If no options, then no vector to store negotiated values. */
    if (ntypes <= 0) {
	xcp->opts = NULL;
	return;
    }
    /* Otherwise, allocate vector and initialize options */
    os = xcp->opts = (struct option_state *)
	malloc(ntypes*sizeof(struct option_state));
    while (--ntypes >= 0) {
	os->my_value = os->peer_value = types->default_value;
	os->state = osUsable;
	os++;
	types++;
    }
}

/*
 * Initialize PPP state machine and add LCP and IPCP.
 */
void
set_up_ppp(struct ppp_state *state, int sock)
{
    state->phase = phDead;
    state->sock = sock;
    state->timeout_period = INITIAL_TIMEOUT;
    init_xcp("LCP",&state->xcps[XCP_LCP],std_negotiation,lcp_types,
	     Dim(lcp_types)-1,PROT_LCP);
    init_xcp("IPCP",&state->xcps[XCP_IPCP],std_negotiation,ipcp_types,
	     Dim(ipcp_types)-1,PROT_IPCP);
}

/*
 * Handle Configure-Request from peer.  If it's in the range we think
 * it should be, then do nothing (allow Configure-Ack).  Otherwise,
 * send Configure-Nak with something more appropriate.
 */
void
ipcp_addr_req(struct ppp_state *state,
	      struct ppp_xcp *xcp,
	      const struct xcp_type *tp,
	      const unsigned char *buf,
	      int len)
{
    int addr;
    unsigned char lbuf[4];
    struct option_state *os;

    addr = (buf[0]<<24) + (buf[1]<<16) + (buf[2]<<8) + buf[3];
    os = xcp->opts + (tp-xcp->types);
    if (addr != os->my_value &&
	(addr & remote_ip_mask) == remote_ip_base)
	return;
    addr = xcp->opts[tp-xcp->types].peer_value;
    lbuf[0] = (addr >> 24) & 0xFF;
    lbuf[1] = (addr >> 16) & 0xFF;
    lbuf[2] = (addr >> 8) & 0xFF;
    lbuf[3] = addr & 0xFF;
    set_nak(state,xcp,tp->type,tp->minlen,lbuf);
}

/*
 * Got a Configure-Nak of our address.  Just change; we're flexible.
 */
void
ipcp_addr_nak(struct ppp_state *state,
	      struct ppp_xcp *xcp,
	      const struct xcp_type *tp,
	      const unsigned char *buf,
	      int len)
{
    xcp->opts[tp-xcp->types].my_value =
	(buf[0]<<24) + (buf[1]<<16) + (buf[2]<<8) + buf[3];
}

/*
 * Show address.
 */
void
ipcp_addr_show(const struct ppp_state *state,
	       const struct ppp_xcp *xcp,
	       const struct xcp_type *tp,
	       const unsigned char *buf,
	       int len)
{
    struct in_addr addr;

    addr.s_addr = (buf[0]<<24) + (buf[1]<<16) + (buf[2]<<8) + buf[3];
    printf("%s",inet_ntoa(addr));
}

/*
 * Set local value (for Configure-Request).
 */
void
set_option_value_lcl(struct ppp_xcp *xcp, int type, int value)
{
    struct option_state *os;

    if ((os = find_option(xcp,type)) != NULL)
	os->my_value = value;
}

/*
 * Set desired value for peer (we'll Configure-Nak with this).
 */
void
set_option_value_rem(struct ppp_xcp *xcp, int type, int value)
{
    struct option_state *os;

    if ((os = find_option(xcp,type)) != NULL)
	os->peer_value = value;
}

int
main(argc,argv)
int argc;
char **argv;
{
    int sock,i;
    struct ppp_state mystate;

    myname = argv[0];

    while ((i=getopt(argc,argv,"adpstv")) != EOF)
	switch (i) {
	case 'a':
	    debugactions++;
	    break;
	case 'd':
	    showraw++;
	    break;
	case 'p':
	    debugphases++;
	    break;
	case 's':
	    debugstates++;
	    break;
	case 't':
	    debugtimer++;
	    break;
	case 'v':
	    showpackets++;
	    break;
	case '?':
	    usage();
	    return 1;
	}

    if ((sock = set_up_tunnel(argv+optind)) < 0) {
	usage();
	return 1;
    }

    /* Request that IPCP go open! */
    set_up_ppp(&mystate,sock);

    /* Set some random addresses to try */
    srand(getpid());
    set_option_value_lcl(&mystate.xcps[XCP_IPCP],3,0x0A000000+(rand()%1000));
    set_option_value_rem(&mystate.xcps[XCP_IPCP],3,0x0A00000A+(rand()%1000));

    /* Tell LCP to open */
    send_event(&mystate,&mystate.xcps[XCP_IPCP],evOpen);

    signal(SIGALRM,alarm_handle);
    read_packets(&mystate);

    return 0;
}
