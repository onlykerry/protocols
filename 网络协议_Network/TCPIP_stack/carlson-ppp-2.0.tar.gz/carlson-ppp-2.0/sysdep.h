/*
 * System interface used by example AHDLC and LAP-B code.
 *
 * This code may be used for any purpose as long as the author's
 * copyright is cited in any source code distributed.  This code
 * is also available electronically from the author's web site.
 *
 * http://people.ne.mediaone.net/carlson/ppp
 *
 * http://www.workingcode.com/ppp
 *
 * Copyright 1999 by James Carlson and Working Code.
 */

#ifndef JDC_SYSDEP_H
#define JDC_SYSDEP_H

#ifdef AIX
#include <memory.h>
#else
#include <string.h>
#endif

/* Allocate a buffer.  Pointer returned must point to start of data area. */
extern char *buffer_fetch(int size);

/* Free a buffer.  The pointer always points to the start of a buffer. */
extern void buffer_release(char *buffer);

/* Reenable transmit interrupts (flag a call into ahdlc_transmit()). */
extern void enable_transmit(void);

/*
 * Arrange a callback to the given function with the given argument.
 * (At most one timeout is active per LAP-B session.)
 */
extern void timeout(void (*func)(void *handle), void *handle, int millisec);

/* Delete any outstanding call to the given function. */
extern void untimeout(void (*func)(void *handle), void *handle);

/* These two are used in the util.c timeout implementation. */
extern int nextevent(void);
extern void timeelapsed(int millisec);

extern void interrupts_off(void);
extern void interrupts_on(void);
extern void wakeup(void *event);
extern void sleep(void *event, int level);

typedef unsigned char octet;
typedef unsigned short uint16;
typedef unsigned long uint32;
typedef int BOOLEAN;

#define MAXIMUM_MRU 2048

/* Just for testing. */
extern int buffers_allocated,buffers_freed;
extern void buffer_status(void);

#endif /* JDC_SYSDEP_H */
