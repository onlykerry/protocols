/*****************************************************************************
* net.c - Network Globals program file.
*
* portions Copyright (c) 1997 by Global Election Systems Inc.
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY
*
* 97-12-08 Guy Lancaster <lancasterg@acm.org>, Global Election Systems Inc.
*	Original.
*****************************************************************************/

#include "typedefs.h"
#include <string.h>
#include "stdio.h"
#include "netbuf.h"
#include "devio.h"

#include "net.h"
#include "netmagic.h"
#include "netppp.h"
#include "netip.h"
#include "nettcp.h"

#include "debug.h"


/******************************/
/*** PUBLIC DATA STRUCTURES ***/
/******************************/
u_short	idle_time_limit = 0;	/* Disconnect if idle for this many seconds */
int	maxconnect = 0;				/* Maximum connect time */
int	refuse_pap = 0;				/* Don't wanna auth. ourselves with PAP */
int	refuse_chap = 0;			/* Don't wanna auth. ourselves with CHAP */

char hostname[MAXNAMELEN + 1];	/* Our hostname */
char user[MAXNAMELEN + 1];		/* Username for PAP */
char passwd[MAXSECRETLEN + 1];	/* Password for PAP */
char our_name[MAXNAMELEN + 1];	/* Our name for authentication purposes */
char remote_name[MAXNAMELEN + 1]; /* Peer's name for authentication */
int	explicit_remote = 0;		/* remote_name specified with remotename opt */
int	usehostname = 0;			/* Use hostname for our_name */

u_int32_t	netMask;			/* IP netmask to set on interface */
u_int32_t	localHost;			/* Our IP address in */


/***********************************/
/*** PUBLIC FUNCTION DEFINITIONS ***/
/***********************************/
/*
 * netInit - Initialize the network communications subsystem.
 */
void netInit(void)
{
	strcpy(hostname, LOCALHOST);
	user[0] = '\0';
	passwd[0] = '\0';
	our_name[0] = '\0';
	remote_name[0] = '\0';
	explicit_remote = 0;
	magicInit();
	ipInit();
	pppInit();
	tcpInit();
}

/*
 * Set the login user name and password for login and authentication
 *	purposes.  Using globals this way is rather hokey but until we
 *	fix some other things (like implementing a 2 stop PPP open),
 *	this will do for now.
 */
void netSetLogin(const char *luser, const char *lpassword)
{
	strncpy(user, luser, MAXNAMELEN);
	user[MAXNAMELEN] = '\0';
	strncpy(passwd, lpassword, MAXNAMELEN);
	passwd[MAXNAMELEN] = '\0';
}

/*
 * gethostbyname - Look up host name.
 * Return host's netent if found, otherwise NULL.
 */
#pragma argsused
struct hostent	*gethostbyname (const char *hn)
{
	return NULL;
}


/* Convert a host long to a network long.  */
u_long htonl (u_long __arg)
{
	asm {
		mov  ax, word ptr [__arg];
		xchg ah, al;
		xchg ax, word ptr [__arg + 2];
		xchg ah, al;
		mov  word ptr [__arg], ax;
	}
	return __arg;
}

/* Convert a host short to a network short.  */
u_short htons (u_short __arg)
{
	asm {
		mov  ax, word ptr [__arg];
		xchg ah, al;
		mov  word ptr [__arg], ax;
	}
	return __arg;
}

/* Convert a network long to a host long.  */
u_long ntohl (u_long __arg)
{
	asm {
		mov  ax, word ptr [__arg];
		xchg ah, al;
		xchg ax, word ptr [__arg + 2];
		xchg ah, al;
		mov  word ptr [__arg], ax;
	}
	return __arg;
}

/* Convert a network short to a host short.  */
u_short ntohs (u_short __arg)
{
	asm {
		mov  ax, word ptr [__arg];
		xchg ah, al;
		mov  word ptr [__arg], ax;
	}
	return __arg;
}


/*
 * inChkSum - Compute the internet ones complement 16 bit checksum for a given
 * length of a network buffer chain starting at offset off0.
 * Return the checksum in network byte order.
 */
#define ADDCARRY(x)  (x > 65535 ? x -= 65535 : x)
#define REDUCE {l_util.l = sum; sum = (u_long)l_util.s[0] + (u_long)l_util.s[1]; ADDCARRY(sum);}
u_short inChkSum(NBuf *nb, int len, int off0)
{
	register u_short *w;
	register long sum = 0;
	register int bufLen = 0;
	register NBuf *n0 = nb;
	int byte_swapped = 0;

	union {
		char	c[2];
		u_short	s;
	} s_util;
	union {
		u_short s[2];
		long	l;
	} l_util;

	/* Ensure that there is enough data for the offset. */
	if (nb->len <= off0)
		return -1;
	
	/*
	 * Adjust buffer start for the offset.
	 */
	nb->len -= off0;
	nb->data += off0;
	for (;n0 && len; n0 = n0->nextBuf) {
		if (n0->len <= 0)
			continue;
		w = nBUFTOPTR(n0, u_short *);
		if (bufLen == -1) {
			/*
			 * The first byte of this nBuf is the continuation
			 * of a word spanning between this nBuf and the
			 * last nBuf.
			 *
			 * s_util.c[0] is already saved when scanning previous 
			 * nBuf.
			 */
			s_util.c[1] = *(char *)w;
			sum += s_util.s;
			w = (u_short *)((char *)w + 1);
			bufLen = n0->len - 1;
			len--;
		} else
			bufLen = n0->len;
		if (len < bufLen)
			bufLen = len;
		len -= bufLen;
		/*
		 * Force to even boundary.
		 */
		if ((1 & (int) w) && (bufLen > 0)) {
			REDUCE;
			sum <<= 8;
			s_util.c[0] = *(u_char *)w;
			w = (u_short *)((char *)w + 1);
			bufLen--;
			byte_swapped = 1;
		}
		/*
		 * Unroll the loop to make overhead from
		 * branches &c small.
		 */
		while ((bufLen -= 32) >= 0) {
			sum += w[0]; sum += w[1]; sum += w[2]; sum += w[3];
			sum += w[4]; sum += w[5]; sum += w[6]; sum += w[7];
			sum += w[8]; sum += w[9]; sum += w[10]; sum += w[11];
			sum += w[12]; sum += w[13]; sum += w[14]; sum += w[15];
			w += 16;
		}
		bufLen += 32;
		while ((bufLen -= 8) >= 0) {
			sum += w[0]; sum += w[1]; sum += w[2]; sum += w[3];
			w += 4;
		}
		bufLen += 8;
		if (bufLen == 0 && byte_swapped == 0)
			continue;
		REDUCE;
		while ((bufLen -= 2) >= 0) {
			sum += *w++;
		}
		if (byte_swapped) {
			REDUCE;
			sum <<= 8;
			byte_swapped = 0;
			if (bufLen == -1) {
				s_util.c[1] = *(char *)w;
				sum += s_util.s;
				bufLen = 0;
			} else
				bufLen = -1;
		} else if (bufLen == -1)
			s_util.c[0] = *(char *)w;
	}
	/*
	 * Reset buffer start for the offset.
	 */
	nb->len += off0;
	nb->data -= off0;
	
	if (len)
		IPDEBUG((LOG_ERR, TL_IP, "inChkSum: out of data"));
	if (bufLen == -1) {
		/* The last nBuf has odd # of bytes. Follow the
		   standard (the odd byte may be shifted left by 8 bits
		   or not as determined by endian-ness of the machine) */
		s_util.c[1] = 0;
		sum += s_util.s;
	}
	REDUCE;
	return ((u_short)(~sum) & 0xffff);
}


/*
 * print_string - print a readable representation of a string using
 * printer.
 */
void print_string(
	char *p,
	int len,
	void (*printer) __P((void *, char *, ...)),
	void *arg
)
{
	int c;
	
	printer(arg, "\"");
	for (; len > 0; --len) {
		c = *p++;
		if (' ' <= c && c <= '~') {
			if (c == '\\' || c == '"')
				printer(arg, "\\");
			printer(arg, "%c", c);
		} else {
			switch (c) {
			case '\n':
				printer(arg, "\\n");
				break;
			case '\r':
				printer(arg, "\\r");
				break;
			case '\t':
				printer(arg, "\\t");
				break;
			default:
				printer(arg, "\\%.3o", c);
			}
		}
	}
	printer(arg, "\"");
}


/*
 * bcmp - Compare a string of bytes and return non-zero if they differ.
 * Note: This differs from strncmp() in that nulls are not recognized
 *    as delimiters.
 */
int bcmp(u_char *s0, u_char *s1, int len)
{
	for (len--; len >= 0; len--)
		if (s0[len] != s1[len])
			return -1;
	return 0;
}

