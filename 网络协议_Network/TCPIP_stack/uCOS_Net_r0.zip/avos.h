/*****************************************************************************
* avos.h - Accu-Vote Operating System header file
*
* Copyright (c) 1997 Global Election Systems Inc.
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY
*
* 97-02-12 Guy Lancaster <glanca@gesn.com>, Global Election Systems Inc.
*	Original modified from startup.h.
*****************************************************************************/
/*
 * WARNING - Interrupt handler functions cannot have local variables.
 *		The OSIntCtxSw() code uses a fixed magic stack adjustment to take
 *		the interrupt as its own which does not account for local variables.
 */

#ifndef AVOS_H
#define AVOS_H

/* AVOS extends the ucos kernel so we include all exports of ucos here. */
#include "ucos.h"

/**************************/
/*** PUBLIC DEFINITIONS ***/
/**************************/
/* Minimum stack size to support interrupt handlers. */
#define OSMINSTACK 512

/*
 * Accu-Vote OS Jiffy clock constants.  We use a 125 Jiffy per second
 *	(15.625ms) tick rate.  Since we use milliseconds extensively, it's
 *	best to keep the result of 1000/HZ as base-2 to make most run-time 
 *	calculations simple shift operations.
 */
#define FCLK		7500000UL				/*	clock frequency */
#define HZ 			125U					/*	ticks per second */
#define TICKSPERSEC	HZ
#define MSPERTICK	(1000/HZ)				/*	milliseconds per tick */
#define MSPERJIFFY  (1000/HZ)				/*	Milliseconds per Jiffy */
#define JIFFYPERSEC	(HZ)					/*	Jiffies per second */
#define	FDIVCLK		(FCLK/128)				/*	timer frequency */
#define MSCNTDOWN	((INT)(FDIVCLK/1000))	/*	count down value for one millisecond */
#define HZCNTDOWN	((INT)(FDIVCLK/HZ))		/*	count down value for one tick */


/***********************
*** PUBLIC FUNCTIONS ***
***********************/
void avosInit(void (*shutdown)());

/*
 * These macros are used to disable interrupts in critical sections.
 */
#define  OS_ENTER_CRITICAL() asm CLI
#define  OS_EXIT_CRITICAL() asm STI

/*
 * This causes the highest priority ready task to run.  Normally
 * only used by uCOS functions. 
 */
#define  OS_TASK_SW()         asm  INT   uCOS


/*
 * Sleep for n seconds;
 */
void sleep(UINT n);

/*
 * Sleep ms milliseconds.  Note that this only has a (close to) 1 Jiffy 
 *	resolution.
 * Note: Since there may me less than a ms left before the next clock
 * 	tick, 1 tick is added to ensure we delay at least ms time.
 */
void msleep(UINT ms);

/*
 * Return the milliseconds since power up.  We base this on the number of 
 *	Jiffies that have passed plus the remaining time on the Jiffy timer.
 */
ULONG mtime(void);

/*
 * Return the difference between t and the current system elapsed
 *	time in milliseconds.
 */
LONG diffTime(ULONG t);

/*
 * Return the time in Jiffy timer ticks since power up.
 */
ULONG jiffyTime(void);

/*
 * Return the difference between t and the current system elapsed
 *	time in Jiffy timer ticks.  Positive values indicate that t
 *	is in the future, negative that t is in the past.
 */
LONG diffJTime(ULONG t);

/*
 * Halt the system.  Used by shutdown() which is in startup since 
 *	shutting down the system is in a way the reverse of starting
 *	up the system.  Note that this disables task switching but
 *	does not disable interrupt handling (thus the debugger will
 *	still function).
 */
void HALT(void);

/* Display a panic message and HALT the system. */
void panic(char *msg);

/*
 * Display the interrupt service routine number and the address at the time
 *	of interrupt and halt.  This is normally called for an unexpected interrupt.
 */
void isrDisplay(INT isrnum, INT PS, INT PC);

#endif

