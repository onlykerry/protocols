/*****************************************************************************
* Typedefs.h - Global Definitions.
*
* Copyright Global Election Systems Inc. 1996
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY
*
* 97-07-21 Guy Lancaster <glanca@gesn.com>, Global Election Systems Inc.
*	Original derived from earlier code.
*****************************************************************************/

#ifndef TYPEDEFS_H
#define TYPEDEFS_H

/* This extends Borland C compiler definitions. */
#include <limits.h>

/*************************
*** PUBLIC DEFINITIONS ***
*************************/
#ifndef NULL
#define NULL ((void *)0)
#endif

#define FALSE 	0
#define TRUE	!0


/* Standard ASCII definitions */
#define NUL 0X0
#define ACK 0X06
#define LF 0X0A
#define FF 0X0C
#define CR 0x0D
#define BS 0x08
#define XON 0x11
#define RTS 0X12
#define XOFF 0x13
#define NAK 0X15
#define CTRLY 0X19
#define EOD CTRLY
#define CTRLZ 0X1A
#define EOF CTRLZ

/*
 * General return codes.
 */
#define RET_SUCCESS 0
#define RET_ERROR	!0

#define KILOBYTE 1024L				/* Bytes in a kilobyte */


/************************
*** PUBLIC DATA TYPES ***
************************/

#define HUGE huge
#define FAR far
#define NEAR near
#define PUBLIC far

/*
 *	A short int is the same size as an int for Turbo 'C' but the compiler
 *	does not use registers for short int but does for int 
 */
#define INT int
#define LONG long int
#define UINT unsigned short
#define USHORT unsigned short
#define ULONG unsigned long int
#define UCHAR unsigned char 
#define CHAR char


/* Type definitions for BSD code. */
#define u_int32_t unsigned long
#define u_long unsigned long
#define u_short unsigned short
#define u_int unsigned short
typedef unsigned long n_long;			/* long as received from the net */
#define n_short unsigned short
#define n_time unsigned long

/* Type definitions for ka9q code. */
typedef long _off_t;
typedef long _ssize_t;
typedef long int32;
typedef short int16;
typedef unsigned char u_char;
typedef unsigned long u_int32;
typedef unsigned short u_int16;

/*
 * Diagnostic statistics record structure.
 * This structure is designed to allow direct addressing of the statistics
 * counter (to minimize run time overhead) while also allowing automated 
 * display of the table.
 * This record should be put in a structure composed of only these records
 * with the last record having a null statistic name.  Then the statistics
 * can be printed automatically by treating the structure as an array.
 */
typedef struct {
	char	*fmtStr;	/* printf format string to display value. */
	u_long	val;		/* The statistics value. */
} DiagStat;


/***********************
*** PUBLIC FUNCTIONS ***
***********************/
#define hiword(x)		((USHORT)((x) >> 16))
#define	loword(x)		((USHORT)(x))
#define	hibyte(x)		(((x) >> 8) & 0xff)
#define	lobyte(x)		((x) & 0xff)
#define	hinibble(x)		(((x) >> 4) & 0xf)
#define	lonibble(x)		((x) & 0xf)
#define	dim(x)			(sizeof(x) / sizeof(x[0]))


/*
 * Segment handling helpers
 */
#define SEGMENT(p)      (int)((long)p >> 16)
#define OFFSET(p)       (int)((long)p & 0x0FFFF)
#define	MK_FP(seg,ofs)	((void FAR *) (((ULONG)(seg) << 16) | (UINT)(ofs)))
#define MK_LP(p)	    ((((ULONG)p & 0xffff0000) >> 12) + ((ULONG)p & 0x0000ffff))

/* 
 * Return the minimum and maximum of two values.  Not recommended for function
 * expressions.
 */
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))

/* XXX These should be the function call equivalents. */
#define max(a,b)	(((a) > (b)) ? (a) : (b))
#define min(a,b)	(((a) < (b)) ? (a) : (b))

/*
 * Borland library functions for which we cannot include the Borland header.
 */
INT rand(void);						/* random number function */

/* Allow function prototyping in BSD code. */
#define __P(c) c

#endif

