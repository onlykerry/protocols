/*****************************************************************************
* RAND.c - Random number generator program file.
*
* Copyright (c) 1998 by Global Election Systems Inc.
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY
*
* 98-06-03 Guy Lancaster <lancasterg@acm.org>, Global Election Systems Inc.
*	Extracted from avos.
*****************************************************************************/

#include "typedefs.h"
#include <string.h>
#include "avconfig.h"
#include "stdio.h"
#include "v25.h"
#include "clckctrl.h"
#include "avos.h"

#include "rand.h"

#include "debug.h"


/*****************************/
/*** LOCAL DATA STRUCTURES ***/
/*****************************/
static int  avRandomized = 0;		// Set when truely randomized.
static ULONG avRandomSeed = 0;		// Seed used for random number generation.


/***********************************/
/*** PUBLIC FUNCTION DEFINITIONS ***/
/***********************************/
/*
 * Initialize the random number generator.
 *
 * Here we attempt to compute a random number seed but even if
 * it isn't random, we'll randomize it later.
 *
 * The current method uses the fields from the real time clock,
 * the idle process counter, the millisecond counter, and the
 * hardware timer tick counter.  When this is invoked
 * in startup(), then the idle counter and timer values may
 * repeat after each boot and the real time clock may not be
 * operational.  Thus we call it again on the first random
 * event.
 */
void avRandomInit()
{
	/* Get a pointer into the last 4 bytes of clockBuf. */
	ULONG *lptr1 = (ULONG *)((char *)&clockBuf[3]);

    /*
     * Initialize our seed using the real-time clock, the idle
     * counter, the millisecond timer, and the hardware timer
     * tick counter.  The real-time clock and the hardware
     * tick counter are the best sources of randomness but
     * since the tick counter is only 16 bit (and truncated
     * at that), the idle counter and millisecond timer
     * (which may be small values) are added to help
     * randomize the lower 16 bits of the seed.
     */
	readClk();
	avRandomSeed += *(ULONG *)clockBuf + *lptr1 + OSIdleCtr
			 + mtime() + ((ULONG)TM1 << 16) + TM1;
		
	/* Initialize the Borland random number generator. */
    srand((unsigned)avRandomSeed);
}

/*
 * Randomize our random seed value.  Here we use the fact that
 * this function is called at *truely random* times by the polling
 * and network functions.  Here we only get 16 bits of new random
 * value but we use the previous value to randomize the other 16
 * bits.
 */
void avRandomize(void)
{
	if (!avRandomized) {
		avRandomized = !0;
		avRandomInit();
		/* The initialization function also updates the seed. */
	} else
		avRandomSeed += (avRandomSeed << 16) + TM1;
}

/*
 * Return a new random number.
 * Here we use the Borland rand() function to supply a pseudo random
 * number which we make truely random by combining it with our own
 * seed which is randomized by truely random events. 
 * Thus the numbers will be truely random unless there have been no
 * operator or network events in which case it will be pseudo random
 * seeded by the real time clock.
 */
ULONG avRandom()
{
    return ((((ULONG)rand() << 16) + rand()) + avRandomSeed);
}


