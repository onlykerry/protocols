/*
 * webrom.c -- Compiled Web Pages
 *
 * Copyright (c) GoAhead Software Inc., 1995-2000. All Rights Reserved.
 *
 * See the file "license.txt" for usage and redistribution license requirements
 *
 * $Id: webrom.c,v 1.2 2001/12/06 16:28:24 bporter Exp $
 */

#include "wsIntrn.h"

websRomPageIndexType websRomPageIndex[] = {
  { 0, 0, 0 },
};
