/**
    @file os.h

    Operating system functions used by uCIP.

    Use this as a starting point to adapt uCIP
    to your own operating system.
*/

#ifndef _OS_H_
#define _OS_H_

#include <pthread.h>

/*####### LOCAL CONFIGURATION ################*/
#define HAVE_ANSI_TIME		1
#define HAVE_ANSI_STDIO		1

/*################## uC/OS ###################*/
#define OS_NO_ERR                 0

#ifndef UINT
#define UINT	unsigned int
#endif
#ifndef ULONG
#define ULONG	unsigned long int
#endif
#ifndef UBYTE
#define UBYTE	unsigned char
#endif
#ifndef UWORD
#define UWORD	unsigned long
#endif

ULONG	OSTimeGet(void);

/*------ semaphores ------*/
//#define	OS_EVENT long		    /* placeholder */
#define OS_EVENT sem_t
//extern OS_EVENT* OSSemCreate(int initval);
//extern void      OSSemPend(OS_EVENT * sem, UINT timeout);
//extern void      OSSemPost(OS_EVENT * sem);

extern OS_EVENT* OSSemCreate(UWORD value);
extern UWORD     OSSemAccept(OS_EVENT *pevent);
extern UBYTE     OSSemPost(OS_EVENT* pevent);
extern void      OSSemPend(OS_EVENT* pevent, UWORD timeout, UBYTE* err);
extern UBYTE     OSTaskCreate(void (OS_FAR *task)(void *pd), void *pdata, void *pstk, UBYTE prio);

extern void OSTaskDel(int id);

/*################## AVOS ###################*/

//extern int main(void);
void panic(char * msg);

/*-------- time management --------*/


/*-------- ANSI time.h ------------*/
#if HAVE_ANSI_TIME==0
#define _TIME_H_
struct tm
{
	int	tm_sec;
	int	tm_min;
	int	tm_hour;
	int	tm_mday;
	int	tm_mon;
	int	tm_year;
	int	tm_wday;
	int	tm_yday;
	int	tm_isdst;
	int tm_gmtoff;
	char *tm_zone;
};

ULONG time(ULONG *); 		// placeholder for standard ANSI C time
#endif


#if HAVE_ANSI_TIME==1

#include <time.h>
int gettime(struct tm * time);	// placeholder for standard ANSI C gettime

#endif


/*-------- random number generation --------*/
void magicInit(void);
ULONG magic(void);
void avRandomize(void);		/* maps to avChurnRand which depends on MD5_SUPPORT */


/*-------- device I/O --------*/
#if HAVE_ANSI_STDIO==0
#define FILE		void	/* placeholder */
#endif

#define	FILE_DESC	int		/* placeholder */

ULONG jiffyTime(void);
long diffJTime(ULONG a);

#define OS_NO_ERR               0         /* ERROR CODES                 */
#define OS_TIMEOUT              10
#define OS_MBOX_FULL            20
#define OS_Q_FULL               30
#define OS_PRIO_EXIST           (-3)
#define OS_PRIO_ERR             (-2)
#define OS_PRIO_SELF            (-1)
#define OS_SEM_ERR              50
#define OS_SEM_OVF              51
#define OS_TASK_DEL_ERR         60
#define OS_TASK_DEL_IDLE        61
#define OS_NO_MORE_TCB          70


//char * nameForDevice(FILE_DESC fd);
//void nPut(FILE_DESC fd, void /*NBuf*/ * buffer);
//void nGet(FILE_DESC fd, void /*NBuf*/ ** buffer, UINT killdelay);	 /* !!! check prototype */

// emulation of PC IO port access instructions (emulated via ls808 host port)
extern UI8 inb(UI32 addr);
extern void outb(UI32 addr,UI8 v);
extern UI16 inw(UI32 addr);
extern void outw(UI32 addr,UI16 v);


#endif /* _OS_H_ */
