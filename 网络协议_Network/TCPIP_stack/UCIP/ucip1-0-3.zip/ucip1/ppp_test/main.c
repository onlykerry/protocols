/*****************************************************************************
* main.c - UC/IP dialup PPP connection test sample program.
*
* Copyright (c) 2001 by Cognizant Pty Ltd.
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY (please don't use tabs!)
*
*(yyyy-mm-dd)
* 2002-01-01 Robert Dickenson <odin@pnc.com.au>, Cognizant Pty Ltd.
*            Original file.
*
******************************************************************************
*/
#define WIN32_LEAN_AND_MEAN     // Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <process.h>
#include <conio.h>
#include "main.h"
#include "netconf.h"
#include "netbuf.h"
#include "net.h"
#include "nettimer.h"
#include "netaddrs.h"
#include "netppp.h"
//#include "netsock.h"
#include "netip.h"
#include "netifdev.h"
#include "InetAddr.h"
//#include "if_dev\sio\if_sio.h"
#include "if_sio.h"
#include "os.h"

//#include "trace.h"
//#include "hardware.h"
#include "udpecho.h"
#include "tcpecho.h"


////////////////////////////////////////////////////////////////////////////////

#define LOCAL_ADDRS   "192.168.0.10"
#define NETWORK_MASK  "255.255.255.0"
#define DEFAULT_ROUTE "192.168.0.1"

////////////////////////////////////////////////////////////////////////////////

int repeat = 1;
Interface SIO_Port; // declare an instance of an Interface for the Serial Port.

extern int nBaudRate;
extern int nPortNum;

#define MY_HANDLE 0x34
int handle = MY_HANDLE;
int h_ppp = -1;

////////////////////////////////////////////////////////////////////////////////

int Startup(void)
{
    SIO_DriverEntry(&SIO_Port);
    if (SIO_Port.start() != 0) {
        printf("ERROR: Failed to start SIO_Port driver.\n");
        return -2;
    }
    printf("Initialising Network Subsystem...\n");

//    nBufInit();
    netInit();
//    timerInit();

//    ipSetDefault(inet_addr(LOCAL_ADDRS), 0, IFT_PPP, 0);
//    pppInit(/* &SIO_Port */);

//    tcpInit();

    OSInit();

/* Open a new PPP connection using the given I/O device.
 * This initializes the PPP control block but does not
 * attempt to negotiate the LCP session.  If this port
 * connects to a modem, the modem connection must be
 * established before calling this.
 * Return a new PPP connection descriptor on success or
 * an error code (negative) on failure. */

//    h_ppp = pppOpen(&SIO_Port);
    h_ppp = pppOpen(handle);
    if (h_ppp < 0) {
        printf("ERROR: Failed to open PPP sub-system.\n");
        return -1;
    }
/*
    printf("Starting Network Tasks...\n");
    OSTaskCreate(UdpEchoTask, NULL, NULL, 1);
    OSTaskCreate(TcpEchoTask, NULL, NULL, 2);
    printf("Starting System Tasks...\n");
    OSStart();
 */
    return 0;
}

int Shutdown(void)
{
    printf("Stopping System Tasks...\n");
    if (pppClose(h_ppp) != 0) {
        printf("ERROR: Failed to close PPP sub-system.\n");
        return -1;
    }
    printf("ShutdownPPP completed.\n");
    SIO_Port.stop();
    return 0;
}

////////////////////////////////////////////////////////////////////////////////

int main(int argc, char* argv[], char* envp[])
{
    printf("uC/IP Stack PPP test sample.\n");
    if (argc > 1) nPortNum = atoi(argv[1]);
    if (Startup() < 0) {
        printf("ERROR: Failed to start all tasks\n");
        return 1;
    }
    printf("running...\n");
#if 0  //server
        run_server();
#else
        run_client();
#endif
    while (!kbhit()) {
        Sleep(1000);
    }
    printf("signaling shutdown...\n");
    repeat = 0;
    Sleep(2500);
    Shutdown();
    printf("done.\n");
    return 0;
}

////////////////////////////////////////////////////////////////////////////////
/*
HANDLE sigFlag;

void ModemDial(void)
{
    int i;
    int temp = 13;
    char inbuffer[200];

    SerialWrite("AT", 2);
    SerialWrite(&temp, 1);
    Sleep(200);
    SerialWrite("AT", 2);
    SerialWrite(&temp, 1);
    Sleep(200);
    SerialWrite("AT", 2);
    SerialWrite(&temp, 1);
    Sleep(200);
    SerialReadALine(inbuffer, 200);
    while (StrFnd(inbuffer, "OK", 0) == -1) {
        Sleep(100);
        SerialRead(inbuffer, 200);
    }
    SerialWrite("ATD*99#", 7);
    SerialWrite(&temp, 1);
    Sleep(500);
    SerialReadALine(inbuffer, 200);
    while (StrFnd(inbuffer, "NNEC", 0) == -1) {
        Sleep(100);
        SerialReadALine(inbuffer, 200);
    }
    SetEvent(sigFlag);
//    while(strfnd(inbuffer,"CONNECT") == -1) {
//        SerialReadALine(inbuffer,200);
//    }
}

void StartupNet(void)
{
    int i;

//// pyxue add init system //////////////////////
    sigFlag = CreateEvent(NULL,TRUE,0,NULL);
    os_init_critical(); 
    i = SerialOpen(1, 57600);
    if (i < 0) {
        printf("can't open serial port1\n");
        exit(0);
    }
/////////////////////////////////////////////////
    nBufInit();
    netInit();
    timerInit();
/////////////////////////////////////////////////
    CreateThread(NULL, 0, (unsigned long(__stdcall*)(void*))ModemDial,0,0,&i);
    WaitForSingleObject(sigFlag, INFINITE);
    pppOpen(1);
//    ipSetDefault(htonl(setup.localAddr), 0, IFT_ETH, 0);
}
 */
 