/*****************************************************************************
* ppp_util.c - ppp test program utility functions.
*
* Copyright (c) 2001 by Cognizant Pty Ltd.
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY (please don't use tabs!)
*
*(yyyy-mm-dd)
* 2002-1-1   Robert Dickenson <odin@pnc.com.au>, Cognizant Pty Ltd.
*            Original file.
*
******************************************************************************
*/
#define WIN32_LEAN_AND_MEAN     // Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <process.h>
#include <conio.h>
#include "main.h"
#include "netconf.h"
#include "netbuf.h"
//#include "net.h"
//#include "nettimer.h"
//#include "netaddrs.h"
//#include "netppp.h"
//#include "netip.h"
#include "netifdev.h"
//#include "InetAddr.h"
//#include "if_sio.h"
//#include "os.h"
#include "sioport.h"
#include "ppp_util.h"

////////////////////////////////////////////////////////////////////////////////

#define LOCAL_ADDRS   "192.168.0.10"
#define NETWORK_MASK  "255.255.255.0"
#define DEFAULT_ROUTE "192.168.0.1"

////////////////////////////////////////////////////////////////////////////////

//extern int repeat = 1;
extern Interface SIO_Port; // declare an instance of an Interface for the Serial Port.
extern int handle;
//extern int h_ppp;


////////////////////////////////////////////////////////////////////////////////
// these should be implemented as a serial device driver...

// the ppp sub-system will call nPut with new nBuf chains for sending to the device.
//
int nPut(int fid, NBuf *nb)                      /* Put an nBuf packet to device. */
{
    int retval = 0;
    if (fid == handle) {
        if (SIO_Port.transmit_ready()) {
            retval = SIO_Port.transmit(nb);
        }
    }
    if (nb != NULL) nFreeChain(nb);
    return retval;
}

// the main ppp task will poll nGet for new nBuf chains from the device.
//
int nGet(int fid, NBuf **nb, int timeout)        /* Get an nBuf packet from device. */
{
    int loops = 25;
    int loop_wait = timeout / loops;
    if (nb == NULL || fid != handle) return 0;
    *nb = NULL;
    do {
        if (SIO_Port.receive_ready()) {
            *nb = SIO_Port.receive();
            break;
        }
        Sleep(max(loop_wait, 1000));
    } while (loops--);
    return 0;
}

////////////////////////////////////////////////////////////////////////////////
//int read(int fd, char* buffer, int buflen);
//int write(int fd, char* buffer, int len);

int read(int fd, char* buffer, int buflen)
{
    int bytes = 0;
    bytes = ReadDataWaiting();
    if (bytes > 0) {
        int count = ReadData(buffer, min(bytes, buflen));
        buffer[count] = '\0';
    }
    return bytes;
}

int write(int fd, char* buffer, int len)
{
    int count = 0;
    if (IsOpened()) {
        count = SendData(buffer, len);
//        AddTxLogEntry(buffer);
        TRACE("write(...) - sent %u of %u bytes\n", count, len);
    }
    return count;
}

////////////////////////////////////////////////////////////////////////////////
