
void ModemDial(void)
{
	int i;
	int temp = 13;
	char inbuffer[200];

	SerialWrite("AT", 2);
	SerialWrite(&temp, 1);
	Sleep(200);
	SerialWrite("AT", 2);
	SerialWrite(&temp, 1);
	Sleep(200);
	SerialWrite("AT", 2);
	SerialWrite(&temp, 1);
	Sleep(200);
	SerialReadALine(inbuffer, 200);
	while (StrFnd(inbuffer, "OK", 0) == -1) {
		Sleep(100);
		SerialRead(inbuffer, 200);
	}
	SerialWrite("ATD*99#", 7);
	SerialWrite(&temp, 1);
	Sleep(500);
	SerialReadALine(inbuffer, 200);
	while (StrFnd(inbuffer, "NNEC", 0) == -1) {
		Sleep(100);
		SerialReadALine(inbuffer, 200);
	}
	SetEvent(sigFlag);
//    while(strfnd(inbuffer,"CONNECT") == -1) {
//		  SerialReadALine(inbuffer,200);
//	  }
}

#if 0  //server
int run_server(void)
{
	int i = 0;
    int socket, newsocket, new_socket;
    struct sockaddr_in sockAddr;
	struct sockaddr_in remoteadd;
    char buffer[512];

	printf("wait for connect\n");
	sockAddr.ipAddr = ntohl(INADDR_ANY);
    sockAddr.sin_port = htons(3000);
    sockAddr.sin_family = AF_INET;
	newsocket = tcpOpen();
	if (newsocket < 0) {
		printf("socket open error\n");
		return 0;
	}
	i = tcpBind(newsocket, &sockAddr);
	if (i != 0) {
		printf("socket bind error\n");
		return 0;
	}
	tcpListen(newsocket, 3);
    new_socket = tcpAcceptJiffy(newsocket, &sockAddr, 6000);
    if (new_socket > 0) {
	   printf("the client is %s connected\n", ip_ntoa(sockAddr.sin_addr));
    }
    i = tcpRead(new_socket, buffer, 200);
    if (i > 0) {
		printf("the content received:%s\n", buffer);
    }
   	while (1) {
		Sleep(100);
	}
    return 1;
}
#else
int run_client(void)
{
	int i = 0;
    int socket, newsocket, new_socket;
    struct sockaddr_in sockAddr;
	struct sockaddr_in remoteadd;
    char buffer[512];

    printf("begin tcp connect\n");
    sockAddr.sin_addr.s_addr = INADDR_ANY;
    sockAddr.sin_port = htons(3000);
    sockAddr.sin_family = AF_INET;
	remoteadd.sin_port = htons(3000);
	remoteadd.sin_family = AF_INET;
	remoteadd.sin_addr.s_addr = ntohl(inet_addr("10.101.65.13"));
//	remoteadd.sin_addr.s_addr = inet_addr("10.101.65.39");
    socket = tcpOpen();
	if (socket < 0) {
		printf("socket open error\n");
		return 0;
	}
	i = tcpBind(socket, &sockAddr);
	if (i != 0) {
		printf("socket bind error\n");
		return 0;
	}
	i = tcpConnectJiffy(socket, &remoteadd, 0, 2);
	if (i != 0) {
		printf("connect  error\n");
		return 0;
	}
	i = tcpWrite(socket, "hello", 5);
	if (i < 0) {
		printf("send  error\n");
		return 0;
	}
	while (1);
    tcpClose(socket);
	printf("send the content\n");
}
#endif

void StartupNet(void)
{
	int i;
	char inbuffer[1024];
//    etherSetup setup;
//    setup.arpExpire = 600;
//    memcpy(&setup.hardwareAddr, &myMAC, sizeof(setup.hardwareAddr));
//    memcpy(&setup.localAddr, &myIP, sizeof(setup.localAddr));
//    setup.localAddr = ntohl(inet_addr("192.168.0.166"));
//    setup.subnetMask = ntohl(inet_addr("255.255.255.0"));
//    setup.gatewayAddr = ntohl(inet_addr("192.168.0.1"));

//// pyxue add init system //////////////////////
	sigFlag = CreateEvent(NULL,TRUE,0,NULL);
	os_init_critical(); 
	i = SerialOpen(1, 57600);
	if (i < 0) {
		printf("can't open serial port1\n");
		exit(0);
	}
/////////////////////////////////////////////////
    nBufInit();
    netInit();
	timerInit();
/////////////////////////////////////////////////
	CreateThread(NULL, 0, (unsigned long(__stdcall*)(void*))ModemDial,0,0,&i);
	WaitForSingleObject(sigFlag, INFINITE);
	pppOpen(1);
//    ipSetDefault(htonl(setup.localAddr), 0, IFT_ETH, 0);
//    arpInit();
//    socketInit();
}

int	main()
{
    printf("################## test gprs ###################\n");
    StartupNet();
	Sleep(1000);
#if 0  //server
    run_server();
#else
    run_client();
#endif
}


