/*****************************************************************************
* server.c - UC/IP dialup PPP connection test sample program.
*
* Copyright (c) 2001 by Cognizant Pty Ltd.
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY (please don't use tabs!)
*
*(yyyy-mm-dd)
* 2002-01-01 Robert Dickenson <odin@pnc.com.au>, Cognizant Pty Ltd.
*            Original file.
*            Function 'run_server' submitted by mailtoyeli (name TBA)
*
******************************************************************************
*/
//#include <stdlib.h>
#include <stdio.h>
//#include <string.h>
#include "netconf.h"
#include "net.h"
#include "netbuf.h"
#include "nettcp.h"
#include "os.h"
#include "main.h"


int run_server(void)
{
    int i = 0;
//    int socket;
    int newsocket, new_socket;
    struct sockaddr_in sockAddr;
//    struct sockaddr_in remoteadd;
    char buffer[512];

    printf("wait for connect\n");
    sockAddr.ipAddr = ntohl(INADDR_ANY);
    sockAddr.sin_port = htons(3000);
    sockAddr.sin_family = AF_INET;
    newsocket = tcpOpen();
    if (newsocket < 0) {
        printf("socket open error\n");
        return 0;
    }
    i = tcpBind(newsocket, &sockAddr);
    if (i != 0) {
        printf("socket bind error\n");
        return 0;
    }
    tcpListen(newsocket, 3);
    new_socket = tcpAcceptJiffy(newsocket, &sockAddr, 6000);
    if (new_socket > 0) {
//        printf("the client is %s connected\n", ip_ntoa(sockAddr.sin_addr));
    }
    i = tcpRead(new_socket, buffer, 200);
    if (i > 0) {
        printf("the content received:%s\n", buffer);
    }
    while (1) {
        delay(100);
    }
    return 1;
}
