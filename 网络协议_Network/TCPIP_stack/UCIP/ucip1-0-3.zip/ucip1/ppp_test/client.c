/*****************************************************************************
* client.c - UC/IP dialup PPP connection test sample program.
*
* Copyright (c) 2001 by Cognizant Pty Ltd.
*
* The authors hereby grant permission to use, copy, modify, distribute,
* and license this software and its documentation for any purpose, provided
* that existing copyright notices are retained in all copies and that this
* notice and the following disclaimer are included verbatim in any 
* distributions. No written agreement, license, or royalty fee is required
* for any of the authorized uses.
*
* THIS SOFTWARE IS PROVIDED BY THE CONTRIBUTORS *AS IS* AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
* IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
* REVISION HISTORY (please don't use tabs!)
*
*(yyyy-mm-dd)
* 2002-01-01 Robert Dickenson <odin@pnc.com.au>, Cognizant Pty Ltd.
*            Original file.
*            Function 'run_client' submitted by mailtoyeli (name TBA)
*
******************************************************************************
*/
//#include <stdlib.h>
#include <stdio.h>
//#include <string.h>
#include "netconf.h"
#include "net.h"
#include "netbuf.h"
#include "nettcp.h"
#include "os.h"
#include "InetAddr.h"
#include "main.h"

void print_error(int code)
{
    char* desc = NULL;
    switch (code) {
    case TCPERR_EOF:
        desc = "End of data.";
        break;
    case TCPERR_ALLOC:
        desc = "Unable to allocate a control block.";
        break;
    case TCPERR_PARAM:
        desc = "Invalid parameters.";
        break;
    case TCPERR_INVADDR:
        desc = "Invalid address.";
        break;
    case TCPERR_CONFIG:
        desc = "Invalid configuration.";
        break;
    case TCPERR_CONNECT:
        desc = "No connection.";
        break;
    case TCPERR_RESET:
        desc = "Connection reset received.";
        break;
    case TCPERR_TIMEOUT:
        desc = "Timeout on transmission.";
        break;
    case TCPERR_NETWORK:
        desc = "Network error:  unreachable?";
        break;
    case TCPERR_PREC:
        desc = "IP Precedence error.";
        break;
    case TCPERR_PROTOCOL:
        desc = "Protocol error.";
        break;
    }
    printf("%s\n", desc);
}

int run_client(void)
{
	int result = 0;
    int i = 0;
    int socket;
    struct sockaddr_in sockAddr;
	struct sockaddr_in remoteadd;

    delay(5000);

    printf("begin tcp connect\n");
    sockAddr.sin_addr.s_addr = INADDR_ANY;
    sockAddr.sin_port = htons(80);
    sockAddr.sin_family = AF_INET;
	remoteadd.sin_port = htons(80);
	remoteadd.sin_family = AF_INET;
	remoteadd.sin_addr.s_addr = inet_addr("192.168.0.2");
//	remoteadd.sin_addr.s_addr = ntohl(inet_addr("192.168.0.101"));
//	remoteadd.sin_addr.s_addr = inet_addr("10.101.65.39");

    socket = tcpOpen();
	if (socket < 0) {
        printf("socket open error: %d\n", socket);
        i = socket;
        goto abort;
	}
	i = tcpBind(socket, &sockAddr);
	if (i != 0) {
		printf("socket bind error: %d\n", i);
        goto abort;
	}
	i = tcpConnectJiffy(socket, &remoteadd, 0, 2);
	if (i != 0) {
        printf("connect error: %d\n", i);
        goto abort;
	}
	i = tcpWrite(socket, "hello", 5);
	if (i < 0) {
		printf("send  error: %d\n", i);
        goto abort;
	}
	while (1);
	printf("send the content\n");
abort:
    print_error(i);
    tcpClose(socket);
    return result;
}
